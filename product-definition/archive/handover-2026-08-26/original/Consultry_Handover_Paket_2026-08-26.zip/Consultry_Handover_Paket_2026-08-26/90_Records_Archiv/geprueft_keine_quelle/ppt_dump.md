<!-- Slide number: 1 -->

![/tmp/beautiful_ai_exports/369cf14b-da73-4b23-b5ca-ec118890c366.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 2 -->

![/tmp/beautiful_ai_exports/8a7505b0-02a6-496e-9964-720a1c89245f.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 3 -->

![/tmp/beautiful_ai_exports/c6fe82d5-7d01-469d-9882-9060cbbebc13.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 4 -->

![/tmp/beautiful_ai_exports/f9b686ee-ff1d-45dc-82fe-5a39ce187115.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 5 -->

![/tmp/beautiful_ai_exports/d8269fc5-ddd2-4fee-8cbf-db3407ba4ee5.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 6 -->

![/tmp/beautiful_ai_exports/868b6f74-5332-477a-9a04-5d638fd49d88.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 7 -->

![/tmp/beautiful_ai_exports/96d0a18c-f8ff-44bf-99f2-a2c3c64982b1.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 8 -->

![/tmp/beautiful_ai_exports/044da166-9c17-471f-87f2-48077ea0496a.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 9 -->

![/tmp/beautiful_ai_exports/f19410e8-a53f-4e71-9dde-72ec29beb2d2.jpg](Object1.jpg)

### Notes:
Video URL: https://videos.pexels.com/video-files/853889/853889-hd_1920_1080_25fps.mp4

<!-- Slide number: 10 -->

![/tmp/beautiful_ai_exports/ad33bf7a-692d-4643-9d5b-b0d2d4dd807d.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 11 -->

![/tmp/beautiful_ai_exports/94618eba-766f-415b-9cfc-1bd82ff8c409.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 12 -->

![/tmp/beautiful_ai_exports/8b9df389-3f9e-4f27-b583-f661873c5c0e.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 13 -->

![/tmp/beautiful_ai_exports/164b9e0f-be15-4015-8b2a-06afd2bb1135.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 14 -->

![/tmp/beautiful_ai_exports/67ebb6e2-a21e-4f73-b43f-8542d88d1db9.jpg](Object1.jpg)

### Notes:

<!-- Slide number: 15 -->

![/tmp/beautiful_ai_exports/1f2cfea3-83c5-4b57-b02b-e7f20007ec2f.jpg](Object1.jpg)

### Notes:
