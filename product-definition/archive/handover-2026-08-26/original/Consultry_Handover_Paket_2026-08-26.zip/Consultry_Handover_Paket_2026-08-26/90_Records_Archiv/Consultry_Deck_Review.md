# Consultry Pitch-Deck-Review

**Verglichene Varianten:** `pitchdeck_v9_fun` (Sketch-Stil, 15 Folien) und `Consultry_Investor_Deck_v8_2_9` (Investor-Version mit Speaker Notes, 15 Folien inkl. Backup)
**Zielpublikum laut Briefing:** Pre-Seed- und Micro-VCs
**Stand:** 9. August 2026

---

## 1. Gesamturteil

Beide Decks sind handwerklich deutlich über dem Durchschnitt dessen, was Pre-Seed-Fonds auf den Tisch bekommen. Die Story hat einen echten Bogen (Marktwandel → Problem → Loop → Ask), das Why-now ist mit aktuellen Belegen unterfüttert, und die Planwerte sind erfrischend ehrlich ausgewiesen. Das ist die gute Nachricht.

Die schlechte: Die größten Lücken liegen nicht im Design, sondern in genau den vier Punkten, an denen ein Micro-VC eine Pre-Seed-Entscheidung festmacht. Erstens gibt es **keine sichtbare Validierung** — kein LOI, keine Warteliste, kein Design-Partner wird auf einer Folie gezeigt, obwohl ihr mit H&W und Krallmann zwei quasi gesicherte Erstnutzer habt. Zweitens **deckelt das Deck seine eigene Ambition**: Jahr 3 endet bei €3 Mio. ARR und 0,8 % eines €360-Mio.-SAM — das ist als Plan glaubwürdig, aber als *Endbild* zu klein für einen Fonds, der Fund-Returner sucht. Drittens ist der **Teilzeit-CEO** ein rotes Tuch, das nirgends offensiv adressiert wird. Viertens verspricht der Titel ein „KI-Betriebssystem", während die erste Version ein (guter!) Angebots-Loop ist — diese **Spannung zwischen OS-Anspruch und Wedge-Realität** wird ein VC im ersten Meeting aufmachen.

Kurz: Das Deck verkauft aktuell einen soliden Mittelstands-Softwareplan. Für Micro-VCs muss es eine Venture-Story verkaufen, die *mit* einem soliden Plan beginnt.

---

## 2. Was stark ist — unbedingt behalten

**Die Wandel-Folie ist die beste Folie im Deck.** Accenture-Kurssturz, KI-Bookings, Outcome-Pricing: drei unabhängige Belege, dass sich Consulting genau jetzt umpreist. Das ist ein echtes, datiertes Why-now — die seltenste Zutat in Pre-Seed-Decks. (Details zur Zahlengenauigkeit in Abschnitt 4.)

**Der Produkt-Loop erzählt statt zu behaupten.** „Bei uns steht bald eine Cloud-Migration an" als Nebensatz, der heute wochenlang im Protokoll liegt — das ist konkret, jeder Beratungs-Erfahrene nickt sofort. Dass die Geschichte aus Caspars echtem Vertriebsalltag stammt, macht sie doppelt stark. Sagt das explizit dazu.

**Die Vorher/Nachher-Folie** übersetzt Features in Betriebsveränderung. Gute Disziplin.

**EU-Hosting + EU-KI-Verordnung als Verkaufsargument** ist ein real verteidigbarer Winkel gegen US-Tools — seit August 2026 ist der AI Act allgemein anwendbar, das Timing stimmt. Dieses Argument ist im Deck aber in Nebensätzen und Speaker Notes versteckt. Es verdient mehr Gewicht.

**Kapitaleffizienz:** 18 Monate Runway aus €250k, Gründung selbst finanziert, erste Version entsteht ohne Fremdkapital. Das ist in 2026 ein Pluspunkt — ausspielen.

---

## 3. Die fünf kritischen Schwächen (und wie ihr sie behebt)

### 3.1 Es gibt keine Traction-Folie — obwohl ihr Traction habt

Für einen Pre-Seed-Fonds in 2026 ist „Idee + Team, Produkt kommt nach Funding" bei einem KI-Thema die schwächste denkbare Position, weil gerade jeder ein KI-Deck pitcht. Ihr habt aber verstecktes Material: H&W als Nutzer #0, Krallmann als Zielpartner #1, Caspars täglicher Zugriff auf echte Angebotsprozesse im Zielprofil. Das steht in den Speaker Notes von v8 — sichtbar ist davon fast nichts.

**Fix:** Baut vor dem Fundraise 3–7 unterschriebene LOIs oder Pilot-Absichtserklärungen aus eurem Netzwerk und macht daraus eine eigene Folie: „Nutzer #0 gesichert · Zielpartner #1 committed · X LOIs über Y Seats · Pipeline Z Beratungen". Selbst nicht-bindende LOIs verwandeln das Deck von „glaubt uns" in „prüft nach". Zusätzlich: ein klickbarer Prototyp oder ein 90-Sekunden-Demo-Video des Signal-→-Entwurf-Loops vor dem ersten VC-Termin. €250k ohne Produktbeweis funktioniert bei Angels; bei Fonds selten.

### 3.2 Die Venture-Scale-Story fehlt — das Deck deckelt sich selbst

„Wir brauchen 200 davon, um bei €3 Mio. zu stehen" (v9, Marktfolie) ist als Bescheidenheit gemeint, liest sich für einen VC aber als Obergrenze. Ein Micro-VC rechnet ab Folie 1: Kann das ein €100-Mio.-ARR-Unternehmen werden? Das Deck beantwortet die Frage nirgends — SAM €360 Mio., Ziel 0,8 %, Ende.

**Fix:** Behaltet den konservativen 3-Jahres-Plan (der ist glaubwürdig und gut), aber setzt *eine* Folie oder einen Folienabschnitt dahinter, der die Expansionslogik zeigt: DACH → EU (der SAM vervielfacht sich), 5–200 Berater → größere Häuser, Seat-Expansion pro Kunde (Seats wachsen mit dem Beraterteam — euer eigenes Argument!), Preispfad €50 → €69 → Tiers, und perspektivisch angrenzende Professional Services (Agenturen, Ingenieurbüros, Steuer/Legal), die denselben Loop haben. Die Botschaft: „Der Plan ist konservativ. Der Markt ist es nicht." Das ist kein Widerspruch zur Ehrlichkeit — es ist die zweite Hälfte der Wahrheit, die aktuell fehlt.

### 3.3 Team: Die drei Fragen, die jeder VC stellen wird, beantwortet das Deck nicht

Erstens: **CEO Teilzeit** („Vollzeit ab Pilotstart") — für Fonds ein Commitment-Signal, und zwar das falsche. Zweitens: Julian führt parallel eine eigene Security-Beratung *und* ist Vollzeit-CTO — wie geht das auf? Drittens: Caspar ist angestellt bei Krallmann, das gleichzeitig Zielpartner #1 ist — ein VC sieht hier einen möglichen Interessenkonflikt (wem gehören Learnings und Kontakte?).

**Fix:** Adressiert alle drei offensiv, statt sie in Fußnoten zu verstecken. Die Caspar-Story lässt sich sogar drehen: „Unser CEO verhandelt bis Pilotstart jede Woche echte Angebote im exakten Zielprofil — er ist unser lebendes Product Discovery." Aber dann braucht es ein Datum für den Vollzeit-Wechsel und einen Satz zur sauberen Trennung gegenüber Krallmann. Für Julian: klare Aussage, dass H&W in den Nutzer-#0-Modus geht und keine Delivery-Verpflichtungen den CTO binden.

### 3.4 „Unser Vorsprung: das Gründerteam" ist kein Moat-Argument

Teams sind kopierbar, und „Warum das kaum jemand baut" ist faktisch angreifbar — es bauen bereits mindestens zwei finanzierte Startups genau das (siehe 4.4). Wenn ein VC das googelt, bevor ihr es sagt, verliert ihr Glaubwürdigkeit auf der ganzen Folie.

**Fix:** Dreht die Folie von „Warum kaum jemand" auf „Warum wir gewinnen" und stellt das eigentliche Moat-Argument nach vorn, das im Deck schon existiert, aber nie als solches benannt wird: **der geprüfte, versionierte Wissens-Korpus pro Kunde, der mit jedem Mandat wächst.** Das ist ein Daten-Flywheel mit steigenden Wechselkosten — kein Copilot und kein Foundation Model kann ihn nachladen (euer eigenes, starkes Argument aus der Microsoft-Backup-Folie von v8). Founder-Market-Fit ist dann Beschleuniger, nicht Moat.

### 3.5 OS-Anspruch vs. Wedge-Realität

„Das KI-Betriebssystem für Consulting-Firmen" verspricht Signal, Angebot, Delivery, Steuerung (Auslastung/Marge/Forecast) und Wissensmanagement — mit €250k und zwei Vollzeit-Buildern. Die Problem-Folie mit sechs Pain-Clustern verstärkt die Breite noch. VCs mögen große Visionen, aber sie finanzieren fokussierte erste Schnitte.

**Fix:** Erzählt explizit Wedge → Flywheel → OS. „Wir starten mit dem messbarsten Loch: zwei bis vier unbezahlte Senior-Tage pro Angebot. Dieser Loop füttert den Wissens-Korpus. Der Korpus trägt jedes weitere Modul." Reduziert die Problem-Folie auf drei Pains (Senior-Zeit, verteiltes Wissen, Start bei null) oder haltet das Sechser-Raster, aber löst es schneller in die eine Ursache auf. Die Steuerungs-Zeile („Auslastung, Marge und Forecast in einem Bild") würde ich aus der Vorher/Nachher-Folie streichen oder als „später" markieren — sie gehört nicht zur ersten Version und lädt zur Scope-Frage ein.

---

## 4. Faktencheck der Kernclaims

Das Deck wird von Leuten geprüft werden, die diese Zahlen nachschlagen. Aktueller Stand:

### 4.1 Accenture-Kurssturz: „−20 %" → tatsächlich ~18 %
Der Absturz am 18. Juni 2026 nach den Q3-FY26-Zahlen lag bei rund 18 %, nicht 20 % — mehrere Quellen sprechen vom schlechtesten Tag seit Jahren, TD Cowen hat mit KI-Begründung abgestuft. Die Richtung eures Arguments stimmt voll; schreibt „rund −18 %" und ihr seid unangreifbar.

### 4.2 „$2,2 Mrd. KI-Bookings in einem Quartal" → bestätigt, mit Fußnote
Die Advanced-AI-Bookings von $2,2 Mrd. im Quartal sind belegt. Pikantes Detail: Accenture hat im selben Atemzug angekündigt, die Metrik künftig nicht mehr separat auszuweisen, weil KI „so pervasiv" sei. Das ist sogar ein zusätzliches Argument für eure These — nutzt es.

### 4.3 „McKinsey ~30 % ergebnisbasierte Honorare" → Presse sagt ~25 %
Die aktuelle Berichterstattung (u. a. TheStreet/Yahoo Finance) nennt rund 25 % der Fees mit Outcome-Bindung. Eure ~30 % sind möglicherweise aus einer anderen Quelle — prüft das und nehmt die Zahl, die ihr im Datenraum belegen könnt. Bei einer Folie, die von Präzision lebt, tut eine angreifbare Zahl doppelt weh.

### 4.4 Wettbewerb: Der Fall Riplo — kein direkter Konkurrent, aber eine Pflicht-Antwort

v8/v9 nennen nur Experio (US) als Kategorie-Validierung „ohne EU-Fokus". Es gibt aber einen zweiten Namen, den ein VC bei einer Stunde Desk Research findet: **Riplo (UK) hat im März 2026 £2,3 Mio. geraised, und die Presse-Headline war wörtlich „AI operating system for consulting"** (Tech.eu) — als SaaS-Workspace für Beratungsfirmen beschrieben. Die heutige Website erzählt allerdings eine andere Geschichte: Riplo positioniert sich als **„AI impact diligence for private equity"** — eine KI-native Advisory (Ex-MBB-Berater plus AI-Engineers), die Due-Diligence-Mandate an PE-Fonds verkauft, nicht Software an Beratungen.

Das heißt zweierlei für euer Deck:

**Erstens:** Riplo ist heute kein direkter Wettbewerber um euren Slot — sie verkaufen Beratung, ihr verkauft Software an Beratungen. Auf die Wettbewerbsfolie muss Riplo deshalb nicht zwingend. Aber die Funding-Headline existiert, und ein VC, der sie findet, wird fragen. Die Antwort gehört in die Speaker Notes: „Riplo hat auf dieselbe Headline geraised und liefert heute KI-Diligence als Dienstleistung für PE — der Software-Slot für DACH-Beratungen ist weiter offen."

**Zweitens — und das ist die härtere Frage, auf die ihr vorbereitet sein müsst:** Riplos Weg (raisen als „OS for consulting", operieren als KI-native Beratung) deutet an, dass „Software an Beratungen verkaufen" ein zäher Markt sein kann — lange Zyklen, kleine ACVs — und „die Arbeit selbst verkaufen" schneller monetarisiert. Ein scharfer VC wird fragen: *„Warum werdet ihr nicht selbst die KI-native Beratung, statt den Incumbents Werkzeuge zu verkaufen?"* Eure Antwort liegt im Deck bereits angelegt, muss aber explizit werden: Die 14.500 DACH-Beratungen haben die Kundenbeziehungen und das Vertrauen — genau das, was laut eurer eigenen Wandel-These den Deal entscheidet. Ihr bewaffnet die Incumbents, statt gegen ihre Beziehungen anzukämpfen, und eure Distribution läuft durch dieselben Vertrauensnetzwerke (Krallmann, H&W). Plus: KI-native Challenger wie Riplo sind sogar *Beweismaterial für eure Wandel-Folie* — sie sind der Angriff, gegen den sich eure Kunden rüsten müssen.

### 4.5 EU-KI-Verordnung „allgemein anwendbar seit August 2026" → korrekt
Die allgemeine Anwendbarkeit seit 2. August 2026 stimmt. Compliance-by-Design als Verkaufsargument ist zeitlich perfekt — mehr davon ins sichtbare Deck statt in die Notes.

### 4.6 Marktzahlen: NACE J62 ist IT-Beratung, nicht „Consulting"
Eurostat NACE **J62** umfasst „Computer programming and consultancy" — also IT-Dienstleister. Management-/Strategieberatung wäre M70.22. Euer Deck sagt durchgehend „Consulting-Firmen", rechnet aber den IT-Beratungsmarkt. Inhaltlich ist das vermutlich sogar richtig (Krallmann und H&W sind IT-/Security-Beratungen — das ist euer ICP), aber dann benennt die Zielgruppe präzise: „IT- und Technologieberatungen in DACH". Sonst wirkt die Marktfolie bei der ersten Rückfrage schlampig — und ein VC, der M70.22 kennt, stellt die Rückfrage.

---

## 5. Empfohlener Fokus: die Story in drei Sätzen

Wenn ihr nur eine Sache aus diesem Review umsetzt, dann diese Neuausrichtung des roten Fadens:

> **„Consulting wird gerade umgepreist — Stunden verlieren, Ergebnisse gewinnen (Accenture −18 %, McKinsey 25 % Outcome-Fees, EU AI Act verlangt Nachvollziehbarkeit). Für die 14.500 IT-Beratungen in DACH heißt das: Wer Angebote in Stunden statt Tagen liefert und sein Projektwissen wiederverwendet, gewinnt die Mandate der anderen. Wir bauen das System dafür — beginnend beim teuersten Loch (2–4 unbezahlte Senior-Tage pro Angebot), gebaut beim Erstnutzer, und jedes Mandat macht den Wissens-Korpus wertvoller, den kein Wettbewerber nachladen kann."**

Daraus ergibt sich die Rangfolge der Selling Arguments für Pre-Seed-VCs:

1. **Why now mit Datum:** Die Umpreisung des Consulting-Markts passiert *dieses Jahr*, plus AI-Act-Pflichten seit August 2026. Zeitfenster-Argumente schlagen Effizienz-Argumente.
2. **Founder-Market-Fit als Beweis, nicht Behauptung:** Gebaut beim Nutzer #0 (eigene Beratung), getestet im echten Vertriebsalltag beim Zielprofil, Einkäufer-Perspektive im Team. Das ist euer stärkstes Asset — führt damit früher.
3. **Daten-Flywheel als Moat:** Geprüfter, versionierter Korpus pro Kunde, wächst pro Mandat, EU-gehostet, mandantengetrennt. Wechselkosten steigen mit jedem Projekt.
4. **Messbarer ROI im Wedge:** 2–4 Senior-Tage pro Angebot bei ~€1.200–1.800 Tagessatz gegen €50/Seat/Monat — rechnet die Amortisation *vor* (ein gerettetes Angebot zahlt Jahre an Lizenz). Diese Rechnung fehlt im Deck komplett.
5. **Kategorie validiert, DACH offen:** Experio (US) validiert die Kategorie; Riplos £2,3-Mio.-Raise auf die Schlagzeile „AI-OS for Consulting" zeigt Investoren-Appetit — und ihr Schwenk zu PE-Diligence-Services lässt den DACH-Software-Slot offen. First-Mover im relevanten Markt statt „macht sonst niemand".
6. **Kapitaleffizienz:** Selbstfinanzierter Start, 18 Monate Runway, klare Seed-Metriken (€150k ARR, 2 Vertragswechsel, Sean-Ellis > 40 %) — die fünf messbaren Ergebnisse aus den v8-Notes gehören sichtbar auf die Ask-Folie.

---

## 6. Vergleich der beiden Varianten

**v9 „fun" (Sketch-Stil)** ist das bessere Pitch-Deck. Die Dramaturgie ist sauberer (zwei Atem-Folien, klarer Rhythmus), die Folien sind schlanker, der Stil differenziert euch und passt zur Botschaft „menschliche Beziehung + System im Hintergrund". Risiken: Ohne Traction kann verspielt schnell als unseriös lesen — der Stil funktioniert nur, wenn die Zahlen darunter hart sind (siehe Abschnitt 4). Die Ask-Folie mit „Einsteigen?" plus Konfetti ist für Angels charmant, für Fonds eine Spur zu niedlich. Und als Send-ahead funktioniert das animierte HTML auf dem Handy schlecht.

**v8.2.9 (Investor-Version)** hat die bessere Substanz: Speaker Notes mit exzellentem Objection-Handling (die Microsoft-Backup-Folie ist richtig gut), Archetypen auf der Marktfolie, Boutique/Wachstums-Split. Aber sie hat zwei **peinliche Bugs, die vor jedem Versand raus müssen**: Auf der Problem-Folie stehen sichtbar ungefüllte Template-Platzhalter (`{{painTitle}}`, `{{painSub}}`, `{{painB1}}`, `{{painB2}}`), und auf den Folien 3 und 7 prangt „Erstellt mit Higgsfield AI". Ein VC, der das sieht, zieht Rückschlüsse auf euer Qualitätsniveau — unfair, aber real. Außerdem ist die Datei 5 MB groß.

**Empfehlung:** v9 als Basis für den Live-Pitch nehmen. Aus v8 übernehmen: Speaker Notes, Microsoft-Backup-Folie (als Backup behalten — sie ist stark), Markt-Archetypen. Dazu neu: Traction-Folie (3.1), Expansions-Folie (3.2), ROI-Rechnung (5.4), Riplo im Wettbewerb (4.4). Und eine statische PDF-Version für den Versand bauen — animierte HTML-Decks kann kein Fonds intern weiterleiten.

---

## 7. Slide-für-Slide-Kurznotizen (v9-Reihenfolge)

**1 Cover:** Gut. „Pre-Seed €250k" schon auf dem Cover ist mutig, aber okay. Untertitel ggf. auf „für IT-Beratungen" schärfen (siehe 4.6).
**2 Wandel:** Beste Folie. Zahlen korrigieren (−18 %, 25 %), Quellenangaben datieren.
**3 Statement:** Gut als Atempause. In v8 Higgsfield-Branding entfernen.
**4 Problem:** Sechs Pains sind zwei zu viele — oder schneller zur „einen Ursache" auflösen. In v8: Platzhalter-Bug fixen.
**5 Produkt-Loop:** Herzstück, funktioniert. Ergänzt einen echten Produkt-Screenshot oder Mock daneben — aktuell existiert das Produkt visuell nirgends im Deck.
**6 Antworten:** Gut. Steuerungs-Zeile (Forecast) streichen oder als Ausbaustufe markieren.
**7 Leitsatz:** Behalten.
**8 Markt:** Zielgruppe präzise benennen, Expansionslogik ergänzen, Selbst-Deckelung („200 davon") umformulieren.
**9 Wettbewerb:** Framing auf „Kategorie validiert, DACH frei" drehen; die Riplo-Antwort gehört in die Speaker Notes (siehe 4.4 — kein direkter Wettbewerber mehr, aber eine Pflicht-Antwort).
**10 Lücke/Microsoft:** Von „Warum kaum jemand" auf „Warum wir gewinnen" drehen, Flywheel als Moat nach vorn.
**11 Team:** Die drei Fragen aus 3.3 proaktiv beantworten. Vollzeit-Datum für Caspar nennen.
**12 Geschäftsmodell:** ROI-Rechnung pro Kunde ergänzen. GTM fehlt: Wie kommen 200 Kunden zustande mit €50k Marketing und einem Vertriebsgründer? Trust-Netzwerk → Piloten → Referenzen ist eure Antwort — zeigt sie.
**13 Roadmap:** Gut und messbar. Sean-Ellis-Kriterium sichtbar machen.
**14 Ask:** Die fünf messbaren Ergebnisse aus den v8-Notes auf die Folie. Cap-Table-Detail kann in den Datenraum; „Bewertung offen" ist okay, 10 % für €250k (≈ €2,5 Mio. post) ist marktüblich.
**15 Close:** „Projektwissen wird skalierbarer Firmenwert" ist ein starker Schlusssatz. Behalten.

---

## 8. Quellen

- [The Motley Fool: Accenture Just Had Its Worst Day in Years. Is AI Coming for the Consulting Business?](https://www.fool.com/investing/2026/06/18/accenture-just-had-its-worst-day-in-years-is-ai-co/)
- [StocksTracker: Accenture (ACN) Craters ~18%, Worst Large-Cap Loser](https://www.stockstracker.com/market/articles/1414)
- [Investing.com: Accenture downgraded by TD Cowen on AI concerns](https://www.investing.com/news/stock-market-news/accenture-downgraded-by-td-cowen-on-ai-concerns-4752728)
- [ts2.tech: Accenture Earnings Beat as Advanced AI Bookings Hit $2.2 Billion](https://ts2.tech/en/accenture-earnings-beat-as-advanced-ai-bookings-hit-2-2-billion-but-2026-outlook-keeps-wall-street-cautious/)
- [Constellation Research: Accenture says advanced AI is so pervasive it won't break it out anymore](https://www.constellationr.com/insights/news/accenture-says-advanced-ai-so-pervasive-it-wont-break-it-out-anymore)
- [AI Weekly: McKinsey Ties 25% of Fees to Outcomes as AI Erodes Billable Hours](https://aiweekly.co/node/4358)
- [TheStreet: AI is forcing McKinsey, BCG, Bain to rethink consulting fees](https://www.thestreet.com/markets/ai-is-forcing-mckinsey-bcg-bain-to-rethink-consulting-fees)
- [Tech.eu: Riplo raises £2.3M to build an AI operating system for consulting](https://tech.eu/2026/03/31/riplo-raises-ps23m-to-build-an-ai-operating-system-for-consulting/)
- [Microsoft Marketplace: Experio AI](https://marketplace.microsoft.com/en-us/product/saas/experio-ai.experio-ai?tab=overview)
