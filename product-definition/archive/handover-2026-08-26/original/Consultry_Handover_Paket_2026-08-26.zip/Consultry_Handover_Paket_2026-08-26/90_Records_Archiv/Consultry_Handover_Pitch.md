# Handover · Pitch und Investor-Track

Stand 17. August 2026. Dieses Dokument macht jeden (Mitgründer, neue Session, Berater) ohne Vorwissen arbeitsfähig am Investoren-Pitch. Zielgruppe der Runde: Business Angels, DACH, Pre-Seed. Das kundenspezifische Krallmann-Deck ist ein separates Vorhaben und hier bewusst ausgeklammert.

---

## 1. Artefakt-Inventar (aktuelle Fassungen)

| Datei | Inhalt | Status |
|---|---|---|
| `Consultry_Pitchdeck_v10.html` | Das Deck, 15 Folien, animiert, Klickstufen, Sprechernotizen je Folie | aktuell, 28 Fixes vom 17.08. eingearbeitet |
| `Consultry_Deck_Grill_Website.html` | Review-Report als Website: 4 Treffer, 15-Folien-Ampel, 19 Formulierungs-Fixes, Einbauliste | Referenz für Restarbeiten |
| `Consultry_Kernsaetze_Zahlenkarte.pdf` | Einseiter für jeden Termin: Kernsätze wörtlich, Zahlen-Merkkarte, Disziplin-Regeln | aktuell, druckbar |
| `Consultry_Pitch_Transkript.pdf` / `Consultry_Pitch_Rohtranskript.txt` | Pitch-Übung vom 15.08. mit Zeitstempeln; Folien 1 bis 3 wurden nicht aufgenommen | Archiv |
| `Consultry_Pitch_Highlight_Report.pdf` / `Consultry_Pitch_Deep_Report.pdf` | Auswertung plus Red-Team-Analyse B1 bis B12 gegen Consultry | Referenz |
| `Consultry_Vision_geschaerft.md` | Vision mit zwei Grenzen und Leitplanke, Kurzformen, Folienvarianten, Quellen | aktuell |

## 2. Deck-Stand: Was am 17.08. eingebaut wurde

**Folie 9 (wichtigster Fix):** Headline sagt „freigegebener KI" (statt kontrollierter), das Diagramm-Label heißt „IM TENANT DES KUNDEN · WIR HOSTEN NICHTS" (statt EU-Perimeter), unten die Statzeile „77 % nennen Datenschutz als KI-Hemmnis · Bitkom 2026", Punch: „Es rechnet dort, wo eure Verträge schon sind. **Die Daten überschreiten keine weitere Grenze.**" In den Notizen: die Formel (KI zum Wissen), der Dreisatz (Wir hosten nicht / niemand Neues hostet / es rechnet, wo Verträge sind), der Souveränitätssatz (Modell wechseln, nicht Datenraum).

**Folie 14:** Headline „Der Ask ist durchgerechnet, nicht gewünscht", neuer Block „Warum das Risiko klein ist": Infrastruktur trägt sich ab dem zweiten Kunden, jeder Kunde rechnet sich ab dem ersten Monat, Break-even = 0,14 % des Einstiegsmarkts (20 bis 27 Kunden). Als Zielannahmen gekennzeichnet.

**Folie 11:** „Wiederkehrende Sitze, eine feste Plattformgebühr. Ein Preis, alles drin.", Labels „JE SITZ", Fußzeile „Software-Marge über 80 % · Preise im Datenraum".

**Folie 4:** Headline „…reißt der Faden", Karte 1 „Chancen werden zu spät erkannt", Statbox jetzt 77 % (Bitkom 2026, ersetzt die alte 54 % von 2025), neue Zeile „Zwei Drittel verschieben sogar Copilot wegen Datenschutzrisiken" (CoreView), Schatten-KI 42,7 % in den Notizen.

**Folie 6:** Kernstück heißt einheitlich „Verifiziertes Firmengedächtnis"; Satz neu: „Einzeln wäre jeder nur ein weiteres Werkzeug. Zusammen sind sie das Gedächtnis des Hauses."

**Folie 8:** Headline „…lösen je ein Teil", Zeile „Eine Freigabe fürs ganze Haus kennt keinen einzelnen Kundenvertrag", Punch „Ein Werkzeug je Prozess entlastet niemanden. **Es verschiebt nur.**"; in den Notizen DIY-Antwort (Faktor zwanzig) und „Microsoft verdient an der Lizenz, wir am gelungenen Projekt."

**Wording-Sweep:** Cover mit Kategorie-Zeile („KI-Plattform für IT- und SAP-Beratungen · betrieben im Tenant des Kunden"), Folie 2 Punch „Die zehn internen Stunden sind jetzt dran.", Folie 3 („Qualität je Aufgabe", „mehr Zeit beim Kunden", „Die freie Woche fließt zurück…"), Folie 7 („Jede Aussage hat eine Quelle…"), Folie 15 („Jede Freigabe macht den nächsten Agenten klüger.").

**Bewusst NICHT geändert:** Folie 12 (LOI, siehe unten) und Folie 13 (Team-Bios gehören den Gründern; offen ist dort der objektive Begriffsbruch „Modul 1" → „Kreislauf 1").

## 3. Offene Punkte, priorisiert

1. **LOI-Status fixieren (vor JEDEM Termin).** Folie 12 sagt „LOI unterschrieben". Im Pitch-Training klang es nach „eventuell, wenn alles gut läuft". Ein Angel prüft das mit einem Anruf bei Krallmann. Regel: einheitlich sprechen, notfalls ehrlich „in finaler Abstimmung". Das ist Red-Team-Punkt B6, der gefährlichste.
2. **Folie 13:** „Modul 1" → „Kreislauf 1" (Begriffsbruch); die identische Zeile bei CTO und CPO („2+ Jahre AI-getriebene Workflows") differenzieren. Erledigt 18.08.: H&W bleibt auf Beschluss vorerst draußen, die Zeile heißt jetzt „Baut die Plattform: Agenten, Datengrenze, Modellbetrieb".
3. **Markt-Fußnote entscheiden:** 14.500 basiert auf dem NACE-J62-Schnitt; der saubere Schnitt wäre eher 18 bis 19 Tausend. Vor Investorenterminen festlegen und in der Fußnote herleiten (Red-Team B5). Ziel Jahr 3 heißt 13 Mio. ARR, nicht 12.
4. **Personalannahme angleichen:** Break-even-Rechnung nimmt 2 Gründer an, das Deck zeigt 3. Mit 3 Gehältern: Burn ≈ 28 bis 29 T€, X ≈ 20 bis 27 Kunden. Folie 14 nutzt bereits die 20-bis-27-Spanne; Finanzplan entsprechend ziehen.
5. **Anhang bauen:** Betriebswege-Folie, das Datengrenze-Visual als Datenraum-Artefakt, Quellenblatt (Bitkom, CoreView, Lünendonk, BDU, Dell'Acqua, KPMG). Angels blättern selten hin, deren Anwälte immer.
6. **Source-Global-70 % verifizieren** (bisher nur Presse-Sekundärquelle; im Deck nicht mehr tragend, in Vision-Quellen vermerkt).

## 4. Sprachregeln (gelten für jede neue Folie und jeden Text)

Ein Ding, ein Name: Firmengedächtnis, Kreislauf, Sitz, Haus. Verben statt Substantiven auf -ung. Ein Fettwort je Satz. „Zeitalter" nur einmal im Deck. Höchstens ein „im Datenraum". Jeder Punch muss ohne Tonspur lesbar sein, Angels lesen das Deck vorab allein. Keine Gedankenstriche im sichtbaren Text. Zielannahmen immer als solche kennzeichnen.

## 5. Zahlen, die immer identisch gesprochen werden

Die Woche: 40 h = 30 fakturierbar + 10 intern · Ø 162,50 €/h · Agent: 3,5 von 10 h ≈ 2.275 € je Berater und Monat (Zielannahme) · +40 % Qualität je Aufgabe (Harvard/BCG 2023, 758 Berater). Markt: 14.500 × ≈ 25 T€ ≈ 360 Mio. DACH · Europa ≈ 1,6 Mrd. · Jahr 3: 13 Mio. ARR. ACV dreifach trennen: 25 T€ SAM-Annahme, blended 15 T€ im Plan, Krallmann sind Design-Partner-Konditionen. Ask: 500 T€ für 17,5 % (2,86 Mio. post). Neu dazu: 77 % Bitkom, 66 % CoreView, 42,7 % Schatten-KI, 43 % Lünendonk (keine Preiswirkung, Ersparnis bleibt Marge im Haus), 32,4 % wählen EU preisunabhängig, Break-even 20 bis 27 Kunden = 0,14 % des Einstiegsmarkts.

## 6. Q&A-Kurzantworten (Details in den Sprechernotizen der Folien)

**Ersetzt ihr Berater?** „Wir ersetzen keine Berater. Wir geben ihnen ihre Arbeit zurück." Der Agent übernimmt die Arbeit, die den Berater vom Beraten abhält. **Kann das die Beratung selbst bauen?** Prototyp ja, Produkt nein: zwei bis drei Engineers dauerhaft gegen ~27 T€ ACV, Faktor zwanzig, und deren Stunden wären fakturierbar. „Selber machen heißt, ein zweites Produkt neben dem eigenen Geschäft zu betreiben." **Macht das nicht Copilot?** 66 % verschieben Copilot wegen Datenschutz; das Problem ist Governance, genau die verkaufen wir. **Fressen Token die Marge?** Nein, gedeckelter Durchlaufposten im All-in-Sitz, separat ausgewiesen; Software-Marge über 80 %. **Was, wenn Microsoft sperrt oder zurückfällt?** „Fällt ein Anbieter aus, wechseln wir das Modell, nicht den Datenraum." **Compliance-Wording:** nie „maximal compliant", immer „dokumentierter, kundenspezifisch freigegebener Daten- und Modellweg". **Stellenabbau-Frage:** Sprachregel „Kapazität freilegen, nie Personal einsparen".

## 7. Nächste Schritte

LOI-Status klären und Folie 12 entsprechend formulieren. Folie-13-Entscheidungen treffen. Markt-Fußnote festlegen. Anhang bauen. Danach: Probelauf des neuen Decks als Tonspur-Durchgang (die Notizen sind auf Stand), und das separate Krallmann-Deck starten (Basis: Datengrenze-Handover plus Visual).
