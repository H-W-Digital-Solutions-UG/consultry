# LinkedIn-Masterplan · Grill des Handovers und die geformte Fassung

Stand 17. August 2026. Teil A grillt das eigene Content-Handover, Teil B ist der daraus geformte Plan. Teil B ersetzt Abschnitt 3 des Handovers; die 13 Postideen bleiben der Rohstoff-Fundus.

---

## Teil A · Der Grill: Zehn Befunde gegen das eigene Handover

**1. Es fehlt der stärkste Founder-Post überhaupt: der Origin-Post.** Die Liste ist rein thesengetrieben. Founder-led lebt aber zuerst von der Person: Warum baut ein Mann, der heute IT-Beratung verkauft, mit einem Security-Consultant und einem Konzern-IT-Mann dieses Produkt? Ohne Origin-Post fehlt der Ankerpunkt, auf den jedes Profil, jede DM und jeder Angel klickt.

**2. Zwei Zielgruppen, ein Kalender, keine Phase.** Zielkunden-GF und Angels wurden in eine Rotation gemischt, dabei läuft die Runde JETZT. Der Plan braucht zwei Spuren mit Phasenlogik: eine Autoritäts-Spur für Zielkunden und eine dezente Journey-Spur, die Angels Traction-Signale gibt. P7 (das Zeitfenster, der beste Angel-Köder) stand in Woche 3 statt in Woche 1.

**3. Drei Gründer ab Woche 1 posten zu lassen ist eine Ops-Illusion.** So stirbt jede Content-Routine. Realistisch: ein Speerspitzen-Account trägt, die anderen zwei starten als Kommentatoren und steigen versetzt ein. **Speerspitze ist Julian (Entscheidung 17.08.), positioniert auf drei Säulen, nicht nur Security:** Säule 1 Datengrenze und Security (P1, P2, P3, P8, P11, P12), Säule 2 agentisches Bauen (A1 bis A8 im Handover, plus P4), Säule 3 Mensch und Agent, also echte Einsichten in die Zusammenarbeit und das Arbeiten im KI-Zeitalter (H1 bis H7, plus P5, P9, A6). Säule 3 ist die Differenzierungs-Säule: Security-Stimmen gibt es viele, Bau-Stimmen einige, aber kaum jemand schreibt mit Substanz über Freigabe-Momente, deklarierte Agenten-Grenzen und die Frage, wo die Entscheidungsgrenze wirklich verläuft. Rhythmus-Regel: Nach der Launch-Woche nie zwei Security-Posts in derselben Woche, jede Woche mindestens ein Post aus Säule 2 oder 3, sonst wird Julian zum Datenschutz-Account statt zur Autorität für das Arbeiten mit Agenten. Caspar teilt mit Vertriebs-Einordnung (nie nackt reposten), sein Netzwerk bleibt der Verteiler; Paul kommentiert.

**4. Der Cold-Start wurde ignoriert.** Bei kleiner Follower-Basis entscheidet nicht der Hook über Reichweite, sondern die Verteilung: tägliche Kommentare unter Posts, die Zielkunden ohnehin lesen, und das eigene Netzwerk. Das Handover hatte null Kommentar-Strategie, dabei ist sie in den ersten Wochen wichtiger als das Posten selbst.

**5. Kein Anschluss an die Pipeline.** Posts ohne DM-Playbook sind Reichweite ohne Richtung. Es fehlte: Was passiert, wenn ein Beratungs-GF kommentiert? (Antwort: danken, eine Frage stellen, nie pitchen.) Die Discovery-Frage „Wo liegen eure Projektdokumente wirklich?" ist der geborene DM-Einstieg und kam nicht vor.

**6. Ehrlichkeits-Framing vor Traction.** P3 sagt „in unseren Kundengesprächen", P10 spricht Beratungen an, als gäbe es dutzende Cases. Vor dem ersten zahlenden Kunden gilt auf LinkedIn dieselbe Disziplin wie beim LOI: aus Beobachtung, Studienlage und eigener Beratungserfahrung sprechen, nicht aus behaupteter Kundenbasis. Ein Angel, der mitliest, gleicht das mit dem Deck ab.

**7. Hooks, die den Falz reißen.** LinkedIn schneidet nach gut einer Zeile („mehr anzeigen"). P5 und P9 tragen Zwei-Satz-Hooks, deren Pointe unter dem Falz liegt. Regel: Die erste Zeile muss allein neugierig machen, unter etwa 60 Zeichen.

**8. P13 ist ein Insider-Post.** „Das wichtigste Pixel unseres Decks" interessiert niemanden außer uns, und über das eigene Pitchdeck zu posten, während die Runde läuft, ist zusätzlich heikel. Die Idee (der Agent sitzt nicht am Tisch) ist stark, der Rahmen muss weg vom Deck. Dazu ein Konsistenz-Fund: Die 70-Prozent-Zahl darin ist nur sekundär verifiziert, nach eigener Regel gehört dort die KPMG-46-Prozent hin oder gar keine Zahl.

**9. Der Serienplan verbrennt den Fundus.** 13 Ideen in 6 Wochen, danach Leere. Es fehlten: Republishing (starke Posts nach 6 bis 8 Wochen neu angeschnitten), Kommentar-Mining (die besten Einwände werden der nächste Post) und die Serien-Klammer mit Wiedererkennung.

**10. Kein Messkonzept.** Likes sind Deko. Erfolg heißt hier: DMs und Kommentare aus dem ICP, Profilbesuche, die zu Gesprächen werden, Angel-Intros. Ohne Wochen-Review fliegt der Plan blind.

---

## Teil B · Der geformte Plan

### Phase 0 · Diese Woche, vor dem ersten Post

1. **Profile schärfen:** Caspars Headline wird die Kategorie-Zeile („KI-Plattform für IT- und SAP-Beratungen · betrieben im Tenant des Kunden"), Julian ergänzt die Security-Herkunft, alle drei verlinken consultry.de. Der Feature-Bereich bekommt später den Origin-Post.
2. **Origin-Posts schreiben (P0):** P0-Julian eröffnet (Woche 1): „Fünf Jahre habe ich Finanzsysteme geschützt. Jetzt baue ich KI, die Verschwiegenheit ernst nimmt." P0-Caspar folgt, sobald er selbst postet (Wochenrechnung als Beleg), P0-Paul danach (Produkt-Perspektive). Ausformuliert in `Consultry_LinkedIn_Woche1_Julian.md`.
3. **Kommentar-Routine starten (alle drei, täglich 15 Minuten):** je 3 substanzielle Kommentare unter Posts, die die Zielgruppe liest (BDU- und Lünendonk-Umfeld, Consulting-Stimmen, M365-Governance-Szene für Julian). Kommentare sind in den ersten Wochen das Reichweiten-Werkzeug, nicht die eigenen Posts.
4. **Ehrlichkeits-Reframe fixieren:** Vor Traction wird aus Marktbeobachtung und Studienlage gesprochen. „In unseren Kundengesprächen" erst, wenn es sie in Serie gibt.

### Die zwei Spuren

**Spur Autorität (Zielkunden-GF):** P1 Schatten-KI, P6 Zehn-Stunden-Rechnung, P4 Zwei Lesarten, P2 Copilot-Governance, P8 Hochsensibel-aber-richtig, P5 Berater-Empowerment, P9 Junior-Frage, P10 Selber-bauen.
**Spur Journey (Angels, dezent):** P0-Origins, P7 Zeitfenster, ab LOI-Fix und Freigabe die Meilenstein-Posts (Designpartner, Pilot, erste Messwerte). Kein Fundraising-Theater, Signale statt Ankündigungen.

### Der 6-Wochen-Kalender (Speerspitzen-Modell)

| Woche | Post 1 (Julian) | Post 2 (Julian) | Säulen | Pflicht daneben |
|---|---|---|---|---|
| 1 | P0 Origin (Security-Wurzel, Teaser für alle drei Säulen) | P1 Schatten-KI | 1+1 (Launch-Ausnahme) | Caspar teilt EINEN der beiden mit Vertriebs-Einordnung; Caspar + Paul kommentieren binnen 1 h |
| 2 | A1 Prozess statt Prompt | P6 Zehn-Stunden-Carousel („Ich bin Techniker, ich rechne öffentlich") | 2+3 | Kommentar-Routine läuft bei allen dreien |
| 3 | H1 Das wichtigste Interface ist die Freigabe (Flaggschiff Säule 3) | P2 Copilot-Governance | 3+1 | erste DM-Runde an ICP-Kommentatoren |
| 4 | A2 Kleine Modelle, große Arbeit | H3 Wo die Entscheidungsgrenze verläuft | 2+3 | Wochen-Review: Top-Thema bestimmen |
| 5 | P8 Hochsensibel, aber richtig | H2 Ein Agent muss seine Lücken nennen (Paar-Logik: Schleuse trifft Bilanz) | 1+3 | Kommentar-Mining: bester Einwand wird Post-Entwurf |
| 6 | H4 Der Mensch trainiert das Gedächtnis, nicht das Modell | P3 Wir-hosten-nichts (der eine Produkt-Post) | 3+1 | Review: Doppel-Down auf die zwei stärksten Themen |

Nachschub ab Woche 7: P4 Zwei Lesarten, P9 Junior-Frage, P5, P7 Zeitfenster, A3 bis A7, H5 bis H7 (H7 als wiederkehrende Build-in-public-Serie), P11, P12, dazu Republishing der zwei besten. Caspars eigener Origin, sobald er selbst einsteigt.

Danach: Rotation nach Resonanz, Republishing der zwei besten Posts mit neuem Anschnitt, P10/P11/P12 als Nachschub, P14-Backlog bleibt gesperrt bis Partner-Validierung bzw. LOI-Fix.

### Hook-Fixes (falztauglich, erste Zeile allein)

| Post | Neue erste Zeile |
|---|---|
| P3 | „Der Satz, der jedes Datenschutz-Gespräch dreht:" |
| P5 | „Ersetzt ihr damit Berater?" |
| P9 | „Woran lernen Juniors, wenn die KI die Zuarbeit macht?" |
| P10 | „Natürlich können Sie das selbst bauen." |
| P13 → neu gerahmt | „Unsere KI sitzt nicht mit am Tisch. Absichtlich." (ohne Deck-Bezug, Zahl: 46 % KPMG statt 70 %) |

### Das DM- und Kommentar-Playbook

ICP-Kommentar auf eigenem Post → binnen Stunden antworten, danken, EINE Frage stellen (Standard: „Wo liegen eure Projektdokumente heute wirklich, M365, Fileserver oder beim Mandanten?"). Antwortet er → zweiter Kontakt mit einem Einseiter oder kurzen Loom, kein Pitch-Deck. Erst beim dritten Kontakt Terminvorschlag. Angels, die reagieren → Caspar übernimmt persönlich, Verweis auf Datenraum erst nach Gespräch.

### Messung (freitags, 15 Minuten)

Drei Zahlen je Woche: ICP-Kommentare und -DMs (Ziel: ab Woche 3 mehr als drei je Woche), Profilbesuche auf Caspar (Trend), daraus entstandene Gespräche (die einzige Zahl, die am Ende zählt). Nach Woche 4: die zwei Themen mit den meisten ICP-Reaktionen bekommen Serien-Status, der Rest rotiert. Likes werden bewusst nicht bewertet.

### Kill- und Sperrliste

P13 in Deck-Rahmung: gekillt (neu gerahmt siehe oben). P11 erst nach Julians Origin und zwei Security-Posts (Autorität vor Architektur-Vokabular). P12: vor jedem Posten Stichtag prüfen. P14: gesperrt bis Partner-Validierung. Generell gesperrt: LOI, Krallmann-Name, Kundenzitate ohne Freigabe, jede Zahl ohne Quelle im ersten Kommentar.
