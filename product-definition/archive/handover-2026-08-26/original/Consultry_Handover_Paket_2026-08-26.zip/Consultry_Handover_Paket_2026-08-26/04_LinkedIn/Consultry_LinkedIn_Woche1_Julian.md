# Woche 1 · Julian postet, Caspar teilt

Stand 17. August 2026. Ersetzt die Caspar-Fassung der Woche-1-Posts. Beide Texte sind fertig zum Einstellen und in deiner Stimme gehalten: Security-Herkunft, nüchtern, Ich-Form, Zahlen mit Quelle im ersten Kommentar. Wenn du mir zwei, drei deiner bisherigen Posts oder Mails gibst, schleife ich den Ton noch näher an dich heran.

---

## Post 1 (Dienstag oder Mittwoch Vormittag) · P0 Origin Security

**Bild:** echtes Foto von dir, kein Logo, kein Stock. Alternativ ein Whiteboard-Foto mit der Zeile „Die KI zum Wissen, nicht das Wissen zur KI."

**Falz-Zeile (44 Zeichen, geprüft):**

Fünf Jahre habe ich Finanzsysteme geschützt.

**Post-Text:**

Fünf Jahre habe ich Finanzsysteme geschützt.

Cybersecurity-Consulting, systemrelevante Banken. Mein Job in einem Satz: dafür sorgen, dass Daten das Haus niemals auf einem Weg verlassen, den niemand kennt und niemand freigegeben hat.

Dann kam KI in die Beratungsbranche. Und mit ihr ein Widerspruch, der mich nicht losgelassen hat.

Berater brauchen KI dringender als fast jede andere Berufsgruppe. Zehn Stunden jeder Woche gehen für Zuarbeit drauf, die kein Kunde bezahlt: Protokolle, Folien, Angebotsbausteine, Reisekosten.

Aber Beratungen leben von Verschwiegenheit. Und praktisch jedes KI-Werkzeug am Markt sagt: Schick uns deine Daten, dann helfen wir dir.

Als Security-Mensch war meine Antwort darauf immer dieselbe: Nein.

Also bauen wir es jetzt andersherum. Wir bringen die KI zum Wissen, nicht das Wissen zur KI. Die Agenten rechnen im eigenen Microsoft-Tenant der Beratung, unter den Verträgen, die es dort schon gibt. Wir hosten nichts.

Das baue ich mit Caspar, der seit Jahren IT-Beratung verkauft und die zehn Stunden aus jedem Termin kennt, und mit Paul, der neun Jahre Konzern-IT-Projekte gestemmt hat.

Eine Regel steht dabei über allem: Wir ersetzen keine Berater. Wir geben ihnen ihre Arbeit zurück.

An die IT- und Security-Verantwortlichen in Beratungen: Was ist bei euch heute die Regel für KI-Werkzeuge? Verbot, Duldung oder ein geregelter Weg?

**Erster Kommentar (direkt nach Publish):** „In den nächsten Wochen schreibe ich hier über drei Dinge: wie KI in Beratungen funktioniert, ohne dass Mandantendaten das Haus verlassen; wie agentische Systeme wirklich gebaut werden (Prozesse statt Prompts, Evals statt Bauchgefühl, kleine Modelle für große Arbeit); und was Zusammenarbeit zwischen Mensch und Agent tatsächlich ausmacht, vom Freigabe-Moment über Agenten, die ihre Lücken nennen, bis zur Frage, welche Entscheidungen ein Agent nie treffen sollte. Erste Zahl kommt Donnerstag. Mehr zu uns: consultry.de"

**Caspars Teil-Text (Repost mit Einordnung, am Folgetag):** „Ich verhandle jede Woche Angebote mit Geschäftsführern von Beratungen. Die Frage nach dem Datenweg kommt inzwischen vor der Frage nach dem Preis. Deshalb bauen wir Consultry genau so herum, wie Julian es hier beschreibt."

---

## Post 2 (Donnerstag Vormittag) · P1 Schatten-KI

**Format:** reiner Textpost. Kein Bild nötig, die Zahl trägt.

**Falz-Zeile (52 Zeichen, geprüft):**

In Ihrer Beratung arbeitet längst KI. Ohne Freigabe.

**Post-Text:**

In Ihrer Beratung arbeitet längst KI. Ohne Freigabe.

Eine aktuelle Erhebung beziffert es: 42,7 Prozent der Mitarbeitenden nutzen KI-Werkzeuge ohne Genehmigung. Rund 13 Prozent geben dabei Kundendaten ein.

Für ein Geschäft, das von Verschwiegenheit lebt, ist das der stille Ernstfall. Nicht irgendwann, sondern heute, in privaten Browser-Tabs.

Die unbequeme Wahrheit dahinter: Nicht die KI ist das Risiko. Der unkontrollierte Kanal ist es.

Und Verbote lösen das nicht. Sie verschieben die Nutzung nur tiefer in den Privatmodus, wo niemand mehr hinsieht.

Was aus meiner Security-Erfahrung tatsächlich funktioniert, sind drei Dinge:

1. Einen sanktionierten Weg anbieten, der besser ist als der Schattenweg. Sonst gewinnt der Schattenweg.

2. Datenklassen statt Pauschalregeln. Nicht „KI ja oder nein", sondern: Welche Daten dürfen auf welchen Weg? Manche auf keinen, und auch das muss das System durchsetzen können.

3. Jeden Lauf protokollieren. Damit die Beratung ihrem Mandanten zeigen kann, was mit seinen Daten geschah, statt es zu beteuern.

Der Maßstab, an dem ich jede Lösung messe, passt in einen Satz: Kein Datum verlässt das Haus auf einem Weg, den der Kunde nicht kennt und nicht freigegeben hat.

Wie handhabt ihr es heute: Verbot, Duldung oder Regelung?

**Erster Kommentar:** „Quelle: ESCRIBA-Studie, Juni 2026 (42,7 % Nutzung ohne Freigabe, ~13 % mit Kundendaten). Transparenz dazu: Herstellerstudie, Stichprobe nicht offengelegt; die Größenordnung deckt sich aber mit dem, was Bitkom 2026 zur KI-Verbreitung misst (Nutzung verdoppelt auf 41 %). Ich kennzeichne solche Einschränkungen immer mit, das gehört zum Handwerk."

**Caspars Rolle:** Diesmal nur substanzieller Kommentar binnen 60 Minuten (zum Beispiel: welcher GF-Einwand ihm dazu diese Woche begegnet ist), kein Repost, damit nicht beide Posts der Woche identisch verstärkt werden.

---

## Checkliste Woche 1

Beide Posts ohne Links im Text, Links nur in den ersten Kommentar. Caspar und Paul kommentieren binnen 60 Minuten mit Substanz (drei echte Kommentare in der ersten Stunde verstärken die Reichweite rund fünffach). Du beantwortest jeden Kommentar am selben Tag; bei ICP-Kommentaren (GF, IT-Leiter von Beratungen) greift das DM-Playbook: danken, eine Frage („Wo liegen eure Projektdokumente heute wirklich: M365, Fileserver oder beim Mandanten?"), kein Pitch. Firmenseite repostet frühestens am Folgetag. Freitag 15 Minuten: ICP-Reaktionen, Profilbesuche, entstandene Gespräche notieren.

**Ausblick Woche 2 (auf Zuruf ausformuliert):** P2 Copilot-Governance und P6 als Carousel in deinem Rahmen („Ich bin Techniker, ich rechne öffentlich").
