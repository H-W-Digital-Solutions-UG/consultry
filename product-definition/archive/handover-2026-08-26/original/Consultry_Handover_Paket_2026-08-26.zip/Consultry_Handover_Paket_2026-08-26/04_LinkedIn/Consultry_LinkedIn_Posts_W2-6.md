# Posts Woche 2 bis 6 · Julian, einstellfertig

Stand 17. August 2026. Zehn Texte in Reihenfolge des Masterplan-Kalenders. Regeln überall: kein Link im Post (Links in den ersten Kommentar), Falz-Zeile trägt allein, Zahlen mit Quelle, Zielannahmen gekennzeichnet, keine Gedankenstriche. Vor dem Einstellen einmal laut lesen; wo dein Ton härter oder trockener ist, sag es mir mit zwei Beispielen und ich schleife nach.

---

## Woche 2, Post 1 · A1 Prozess statt Prompt

**Falz (58):** Der beste Prompt eures Hauses gehört nicht in ein Textfeld.

Der beste Prompt eures Hauses gehört nicht in ein Textfeld.

Ich sehe in Beratungen gerade überall dasselbe Muster: Ein Kollege findet einen Prompt, der wirklich funktioniert. Er landet in einem Slack-Kanal. Drei Wochen später existieren vier Varianten, zwei davon schlechter, und der Neue im Team kennt keine.

Prompting skaliert nicht über eine Firma. Es skaliert nicht einmal über einen Monat.

Was skaliert, sind Abläufe: Der gute Prompt wird zum definierten Arbeitsschritt. Mit festem Kontext, mit Prüfschritten, mit einem klaren Ergebnisformat. Wer ihn nutzt, muss nicht prompten können. Er muss nur seine Arbeit kennen.

Der Unterschied klingt klein und ist fundamental: Ein Prompt ist Wissen im Kopf einer Person. Ein Ablauf ist Wissen, das der Firma gehört.

Deshalb haben wir bei uns eine harte Regel: Kein Agent wird über Freitext gesteuert, wenn die Aufgabe wiederkehrt. Wiederkehrend heißt Ablauf, mit Failsafes und Selbstprüfung.

Wir haben Prompts nicht verbessert. Wir haben sie abgeschafft und durch Abläufe ersetzt.

Wie ist das bei euch: Leben eure besten Prompts noch in Köpfen und Chats, oder schon in Prozessen?

**Erster Kommentar:** „Für die, die tiefer wollen: Der Fachbegriff hinter dem Muster ist Workflow-Engineering statt Prompt-Engineering. Mehr dazu in den nächsten Wochen, unter anderem, warum unsere Abläufe einen eigenen Eval-Harness haben. consultry.de"

---

## Woche 2, Post 2 · P6 Zehn-Stunden-Carousel (Julian-Rahmen)

**Format:** Dokument-Post, die 9 Folien aus `Consultry_LinkedIn_Woche1.md` Abschnitt 3 (Copy unverändert gültig).

**Falz (42):** Ich bin Techniker. Ich rechne öffentlich.

**Caption:**

Ich bin Techniker. Ich rechne öffentlich.

Zehn Stunden jeder Beraterwoche bezahlt kein Kunde. Wir haben diese Rechnung für unser eigenes Produkt aufgemacht, und ich lege sie hier komplett offen: jede Annahme, jede Quelle, auf den Folien.

Das ist eine Zielannahme, kein Messwert. Genau deshalb zeige ich sie: Wer KI-Werte verkauft, ohne die Rechnung zu zeigen, verkauft Hoffnung.

Rechnet nach. Sagt mir, wo ihr anders landet. Die Kommentare sind offen für Widerspruch.

**Erster Kommentar:** „Quellen: BDU Honorare im Consulting 2025 (Ø-Tagessatz 1.300 €), Lünendonk-Liste 2026 via consulting.de (43 % sehen keine KI-Preiswirkung), Feldversuch Dell'Acqua et al. mit Harvard und BCG 2023 zur Qualität je Aufgabe. Die zehn internen Stunden sind eine Annahme aus Gesprächen, oft eher mehr."

---

## Woche 3, Post 1 · H1 Das wichtigste Interface ist die Freigabe

**Falz (56):** Das wichtigste Interface der Agenten-Ära ist kein Chat.

Das wichtigste Interface der Agenten-Ära ist kein Chat.

Es ist der Freigabe-Moment. Der Augenblick, in dem ein Mensch entscheidet: Das geht raus. Das gilt. Dafür stehe ich.

Der Chat ist nur die Anweisung. Die Freigabe ist die Beziehung.

Und dieser Moment ist erstaunlich schlecht gebaut, fast überall. Meist ist er ein OK-Button unter einem langen Text. Der Mensch klickt, weil er dem Agenten vertraut oder weil er keine Zeit hat. Beides ist gefährlich, nur unterschiedlich schnell.

Ein guter Freigabe-Moment zeigt drei Dinge: Worauf stützt sich das Ergebnis? Wo war der Agent unsicher? Was passiert, wenn ich freigebe?

Grundlage, Unsicherheit, Auswirkung. Fehlt eines davon, ist die Freigabe keine Entscheidung, sondern ein Reflex.

Bei uns ist der Freigabe-Moment das meistdesignte Element des Produkts. Nicht der Prompt, nicht der Chat, nicht das Dashboard.

Denn wer die Freigabe gut baut, bekommt Vertrauen. Wer sie wegautomatisiert, bekommt irgendwann ein Audit.

Der Agent bereitet vor. Der Mensch unterschreibt.

Wie sieht der Freigabe-Moment in euren KI-Werkzeugen aus: Entscheidung oder Reflex?

**Erster Kommentar:** „Das ist Teil 1 einer Reihe über Mensch-Agent-Zusammenarbeit. Als Nächstes: warum ein Agent seine Lücken nennen muss, und wo die Entscheidungsgrenze wirklich verläuft."

---

## Woche 3, Post 2 · P2 Copilot scheitert nicht am Modell

**Falz (59):** 66 Prozent verschieben Copilot. Das Modell ist unschuldig.

66 Prozent verschieben Copilot. Das Modell ist unschuldig.

Zwei Drittel der Organisationen verschieben oder stoppen ihre Copilot-Einführung wegen Datenschutzrisiken. Auf Vorstandsebene sind es sogar drei Viertel.

Der Reflex ist, das der KI anzukreiden. Aus fünf Jahren Security-Arbeit sage ich: Das Problem sitzt woanders.

Copilot sieht alles, was der Nutzer sehen darf. Das klingt harmlos, bis man weiß, wie Berechtigungen in gewachsenen Umgebungen wirklich aussehen: Jahre alte Freigaben, vererbte Zugriffe, SharePoint-Seiten, die nie aufgeräumt wurden.

Die KI erfindet das Datenleck nicht. Sie findet es. Zuverlässiger als jeder Praktikant.

Deshalb ist die richtige Reihenfolge unbequem: erst Rollen und Freigaben, dann Datenklassen (welche Inhalte dürfen überhaupt auf welchen Weg), dann KI.

Wer sie umdreht, bekommt entweder einen gestoppten Rollout oder einen stillen Vorfall.

Das Modell ist austauschbar. Die Governance ist das Produkt.

An die IT-Verantwortlichen: Was war bei euch der Punkt, an dem der Copilot-Rollout ins Stocken kam?

**Erster Kommentar:** „Quelle: CoreView, State of Microsoft 365 Security and Governance 2026 (66 % beziehungsweise 75 % auf Vorstandsebene). Transparenz: Herstellerstudie, entsprechend einordnen. Passend dazu Bitkom 2026: 77 % nennen Datenschutzanforderungen als KI-Hemmnis, bei verdoppelter Nutzung."

---

## Woche 4, Post 1 · A2 Kleine Modelle, große Arbeit

**Falz (54):** Unser wichtigstes Modell hat 27 Milliarden Parameter.

Unser wichtigstes Modell hat 27 Milliarden Parameter.

Nicht zwei Billionen. Kein Frontier-Modell. Und das ist eine der bewusstesten Entscheidungen in unserer Architektur.

Der Grund ist unspektakulär: Der größte Teil echter Arbeit mit Dokumenten ist kein Denksport. Extrahieren, strukturieren, zusammenfassen, Vorlagen füllen. Was dafür fehlt, ist fast nie Intelligenz. Es ist Kontext.

Ein mittelgroßes Modell mit dem vollständigen Dokument schlägt ein Riesenmodell mit einem Schnipsel. Ziemlich oft sogar deutlich.

Dazu kommt, was das kleine Modell kann, was das große nicht kann: im eigenen Tenant laufen. Auf einer einzelnen GPU. Ohne dass ein Dritter je den Klartext sieht.

Die großen Modelle haben ihren Platz, dort, wo wirklich Denktiefe gebraucht wird. Dann aber pseudonymisiert, und die Zuordnung bleibt im Haus.

Wer das Routing entscheidet? Nicht das Marketing der Modellanbieter. Unser Eval-Harness aus echten Aufgaben. Besteht das kleine Modell die Aufgabe, bekommt es sie.

Modellwahl ist Konfiguration, nicht Religion.

Welches ist das kleinste Modell, das bei euch produktiv echte Arbeit trägt?

**Erster Kommentar:** „Für die Techniker: 27B-Klasse, offene Gewichte, FP8 auf einer einzelnen GPU, 262k Kontext. Warum der lange Kontext die Architektur mehr verändert als die Parameterzahl, ist einen eigenen Post wert."

---

## Woche 4, Post 2 · H3 Wo die Entscheidungsgrenze verläuft

**Falz (46):** Welche Entscheidungen darf ein Agent treffen?

Welche Entscheidungen darf ein Agent treffen?

Fast alle ziehen die Grenze intuitiv bei der Schwierigkeit: Leichtes macht die Maschine, Schweres der Mensch.

Ich halte das für die falsche Achse. Nach zwei Jahren Arbeit mit agentischen Systemen bin ich sicher: Die Grenze verläuft nicht bei schwierig. Sie verläuft bei bindend.

Ein Agent darf beliebig schwere Arbeit VORBEREITEN: die komplexe Analyse, den 60-Seiten-Entwurf, die Recherche über hundert Projekte. Je schwerer, desto wertvoller.

Aber er trifft keine BINDENDEN Entscheidungen: keine Zusage an einen Kunden, keinen Preis, nichts, was Menschen betrifft, keine Auflösung von Widersprüchen im Firmenwissen. Das geht als Vorlage an den Menschen, mit Grundlage und Unsicherheit sichtbar.

Das Schöne an dieser Achse: Sie macht Eskalation zum Designprinzip statt zum Versagen. Ein Agent, der vorlegt statt entscheidet, ist nicht schwach. Er ist richtig gebaut.

Und sie gibt eine Antwort auf die Angst vor Autonomie: Autonomie in der Vorbereitung, null Autonomie in der Bindung.

Wo zieht ihr die Grenze, und nach welcher Achse?

**Erster Kommentar:** „Teil 2 der Reihe über Mensch-Agent-Zusammenarbeit. Teil 1 (der Freigabe-Moment) hängt im Profil. Als Nächstes: warum ein Agent seine Lücken nennen muss."

---

## Woche 5, Post 1 · P8 Hochsensibel, aber richtig

**Falz (40):** Dürfen Mandantendaten in ein KI-Modell?

Dürfen Mandantendaten in ein KI-Modell?

Falsche Frage. Die richtige lautet: auf welchem Weg.

Pauschal Ja ist fahrlässig, pauschal Nein treibt die Nutzung in private Browser-Tabs. Was funktioniert, ist dieselbe Denkweise, mit der wir früher Finanzsysteme geschützt haben: Datenklassen.

Öffentliches Material darf viel. Internes einiges. Kundenprojekte weniger. Und für das wirklich Sensible gilt bei uns eine dreiteilige Regel:

Klartext rechnet klein und nah: auf einem offenen Modell im eigenen Tenant, nichts wird gespeichert, kein Dritter sieht es.

Denken läuft groß und pseudonymisiert: Wenn ein starkes Modell gebraucht wird, gehen Namen, Beträge und Kennungen vorher raus, und der Schlüssel für die Rückübersetzung verlässt nie das Haus.

Und manches darf gar nicht: Es gibt eine Sperrklasse, die kein Modellaufruf je erreicht. Egal, was ein Klassifikator meint. Die Quelle schlägt den Inhalt.

Ein System, das auch Nein sagen kann, ist das glaubwürdigste Argument für alles, wozu es Ja sagt.

Arbeitet ihr mit Datenklassen für KI, oder mit einer Regel für alles?

**Erster Kommentar:** „Wortdisziplin, die ich jedem mitgebe: Das ist Pseudonymisierung mit Rückübersetzung im Haus, keine Anonymisierung im Rechtssinn. Wer im Vertrieb anonymisiert sagt, verliert die Due Diligence."

---

## Woche 5, Post 2 · H2 Ein Agent muss seine Lücken nennen

**Falz (49):** Ich traue keinem Agenten, der alles beantwortet.

Ich traue keinem Agenten, der alles beantwortet.

Der gefährlichste Fehler in Mensch-Agent-Systemen ist nicht die Halluzination. Es ist der still halbierte Kontext.

Das passiert schneller, als man denkt: Ein Filter entfernt sensible Passagen, bevor das Modell sie sieht. Gut gemeint, oft sogar Pflicht. Aber wenn der Agent danach antwortet, als hätte er alles gelesen, arbeitet der Mensch mit einem Partner, der lückenhaft informiert ist und es verschweigt.

Das Ergebnis: falsche Sicherheit mit gutem Gewissen. Schlimmer als eine erkennbare Wissenslücke.

Deshalb gilt bei uns: Jeder Lauf legt offen, was der Agent NICHT gesehen hat. Wie viele Stellen entfernt wurden, wie viele ersetzt, was gesperrt war. Eine Bilanz, kein Beichtstuhl, drei Zeilen reichen.

Und wenn das Weggefilterte für die Aufgabe wesentlich ist? Dann wird nicht still weitergearbeitet, sondern eskaliert: auf einen sichereren Verarbeitungsweg oder an den Menschen.

Vertrauen zwischen Mensch und Agent entsteht nicht durch Allwissenheits-Theater. Es entsteht durch deklarierte Grenzen.

Ein Agent, der seine Lücken nennt, ist mehr wert als einer, der alles beantwortet.

Sagt euch euer KI-Werkzeug, was es nicht gesehen hat?

**Erster Kommentar:** „Teil 3 der Reihe. Teil 1: der Freigabe-Moment. Teil 2: die Entscheidungsgrenze verläuft bei bindend, nicht bei schwierig. Beide im Profil."

---

## Woche 6, Post 1 · H4 Der Mensch trainiert das Gedächtnis, nicht das Modell

**Falz (59):** Jede Freigabe macht unseren Agenten klüger. Kein Training.

Jede Freigabe macht unseren Agenten klüger. Kein Training.

Das klingt wie ein Widerspruch, ist aber eine Architekturentscheidung, und ich halte sie für die wichtigste im ganzen System.

Wenn ein Berater bei uns ein Ergebnis freigibt oder korrigiert, lernt kein Modell. Kein Fine-Tuning, keine Gewichte, die sich ändern. Stattdessen wandert die Entscheidung ins Firmengedächtnis: als geprüfter Eintrag, mit Quelle, Datum und Verantwortlichem.

Der nächste Agentenlauf liest dieses Gedächtnis. Deshalb wird er besser.

Warum der Umweg? Drei Gründe.

Nachlesbar: Man kann jederzeit prüfen, WAS gelernt wurde. Bei Gewichten glaubt man, bei Einträgen liest man.

Löschbar: Kunde weg, Projekt sensibel, Fehler drin? Ein Eintrag lässt sich entfernen. Aus einem Modell bekommt man nichts mehr heraus.

Besitzbar: Das Gedächtnis gehört dem Haus. Ein feingetuntes Modell gehört faktisch dem, der es hostet.

Der Mensch trainiert nicht das Modell. Er trainiert das Gedächtnis.

Wissen, das man nachlesen kann, schlägt Gewichte, die man glauben muss.

Wo landet bei euch das, was eure Leute an der KI korrigieren: im Gedächtnis oder im Nirwana?

**Erster Kommentar:** „Nebeneffekt, der in Beratungen den Ausschlag gibt: Dieser Lernkreislauf ist der einzige, der mit Mandanten-Verschwiegenheit sauber zusammengeht. Nichts davon berührt Modellgewichte, alles bleibt im Haus."

---

## Woche 6, Post 2 · P3 Wir hosten Ihre Daten nicht (der eine Produkt-Post)

**Falz (48):** Der Satz, der jedes Datenschutz-Gespräch dreht:

Der Satz, der jedes Datenschutz-Gespräch dreht:

„Wir hosten Ihre Daten nicht."

Wenn ich erkläre, wie Consultry gebaut ist, kommt an dieser Stelle fast immer eine Rückfrage, weil es dem Standard widerspricht: Niemand Neues hostet die Daten. Es rechnet dort, wo die Verträge der Beratung schon sind, im eigenen Microsoft-Tenant. Wir liefern die Software und den Betrieb.

Drei Fragen beantwortet dieser eine Satz auf einmal:

Die AVV-Frage: Für die Inhalte gilt weiter der Vertrag, den das Haus mit Microsoft ohnehin hat. Neu ist nur eine Metadaten-Vereinbarung mit uns.

Die US-Frage: Wer keinen US-Anbieter für die Verarbeitung will, bekommt denselben Aufbau auf europäischer Infrastruktur, im eigenen Vertrag.

Die Exit-Frage: Bei Kündigung bleibt alles, wo es immer war. Index, Protokolle, Wissen. Es gab nie einen fremden Ort.

Und ein Detail, auf das ich stolz bin: Jeder Agentenlauf hinterlässt ein Protokoll, das die Beratung ihrem Mandanten vorlegen kann. Welcher Weg, welches Modell, welcher Rechenort.

Kein Datum verlässt das Haus auf einem Weg, den der Kunde nicht kennt und nicht freigegeben hat.

Das ist der Maßstab. An dem dürft ihr uns messen.

**Erster Kommentar:** „Wie das technisch aussieht (Datenklassen, Freigabewege, tenant-lokales Arbeitsmodell), zeige ich Interessierten gern im Detail: consultry.de. Und ja, das ist der eine Produkt-Post in sechs Wochen, der Rest bleibt Einsicht ohne Pitch."
