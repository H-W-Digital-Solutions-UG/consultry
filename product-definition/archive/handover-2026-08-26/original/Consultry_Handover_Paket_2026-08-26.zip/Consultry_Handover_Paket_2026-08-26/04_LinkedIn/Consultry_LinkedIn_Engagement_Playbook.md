# Engagement-Playbook · Kommentare und ICP-Aufbau

Stand 17. August 2026. Der Teil des Plans, der beim Cold-Start die Reichweite macht: Wo kommentieren, wie kommentieren, wie daraus eine ICP-Liste und Gespräche werden. Aufwand: Julian 15 Minuten täglich, Caspar und Paul je 10.

---

## 1. Warum Kommentare zuerst

Mit kleiner Follower-Basis entscheidet nicht der eigene Post über Sichtbarkeit, sondern wo man in fremden Diskussionen auftaucht. Ein substanzieller Kommentar unter einem Post, den 200 Beratungs-GF lesen, erreicht mehr ICP als der eigene Post in Woche 1. Zusätzlich: Wer regelmäßig klug kommentiert, dessen eigene Posts werden denselben Lesern bevorzugt angezeigt. Kommentieren ist keine Nebentätigkeit, es ist die Verteilstrategie.

## 2. Die Jagdgründe (wo kommentiert wird)

**T1 · Verbands- und Studien-Accounts (Julians Pflichtrevier, Mo/Mi/Fr):** BDU (Bundesverband Deutscher Unternehmensberatungen), Lünendonk, Bitkom, consulting.de. Jeder Studien-Post dort ist ein ICP-Sammelbecken: In den Kommentarspalten und Reaktionslisten stehen genau die Geschäftsführer und Partner, die ihr sucht. Regel: nicht nur den Post kommentieren, sondern die Kommentatoren ansehen und die passenden in die ICP-Liste übernehmen (Abschnitt 4).

**T2 · SAP- und IT-Beratungs-Ökosystem:** DSAG (Deutschsprachige SAP-Anwendergruppe), SAP-Partner-Diskussionen, Posts rund um S/4HANA-Transformationen. Hier sitzt der Einstiegsmarkt wörtlich. Caspar kennt die Häuser, er liefert wöchentlich zwei, drei Posts aus diesem Umfeld an Julian zum Kommentieren.

**T3 · M365-Governance- und Security-Szene (Julians Autoritätsrevier, Di/Do):** Die Leute, die über Copilot-Rollouts, Purview, Oversharing und Berechtigungskonzepte schreiben (Microsoft-MVP-Umfeld, Security-Berater). Suchbegriffe für den Feed: „Copilot Governance", „Oversharing", „Purview", „Copilot Rollout". Hier zahlt jeder Kommentar direkt auf Säule 1 ein, und diese Szene wird vom sicherheitssensiblen Kundensegment gelesen.

**T4 · Agentic- und KI-Engineering-Diskurs (Säule 2 und 3, deutsch und englisch):** Diskussionen zu Agenten, Evals, RAG, Human-in-the-Loop. Suchbegriffe: „AI Agents", „Evals", „Human in the Loop", „Agentic". Hier positionieren sich H1 bis H4 im Kommentarformat, bevor die Posts erscheinen: Der Freigabe-Moment-Gedanke als Kommentar unter einem Agenten-Hype-Post ist ein Testballon mit Rücklaufkanal.

**T5 · Direkte ICP-Personen:** GF, Partner und IT-Leiter von IT-, SAP- und Prozessberatungen mit 20 bis 200 Beschäftigten, die selbst posten. Die posten seltener, aber ein Kommentar dort ist Gold, weil er vom Entscheider selbst gelesen wird. Aufbau über Abschnitt 4. Gesperrt bis auf Weiteres: alles im Krallmann-Umfeld (erst LOI-Status und Freigabe).

## 3. Die Kommentar-Anatomie (vier Sätze, nie mehr als sechs)

1. **Anknüpfen am Detail**, nicht am Thema: eine konkrete Zahl, Formulierung oder These aus dem Post aufgreifen. Zeigt: gelesen, nicht gescannt.
2. **Eigene Substanz dazugeben:** eine Erfahrung aus fünf Jahren Security beziehungsweise zwei Jahren Agentenbau, eine Zahl mit Quelle, ein Muster aus Gesprächen.
3. **Einen Gedanken weiterdrehen oder respektvoll widersprechen.** Der höfliche, belegte Einwand ist der stärkste Kommentar-Typ auf LinkedIn; Zustimmung mit Mehrwert die zweitbeste. Reiner Applaus ist verboten.
4. **Optional eine echte Frage** an den Autor, keine rhetorische.

Harte Regeln: kein Link, kein Consultry-Pitch, keine Emojis-Batterie, Firmenbezug höchstens implizit („wir bauen gerade genau an dieser Grenze"). Wenn ein Kommentar länger gerät als der halbe Ursprungspost, ist er ein eigener Post, dann aufheben und einplanen.

## 4. Vom Kommentar zur ICP-Liste (das Rezept)

Wöchentlich 10 neue Accounts in eine simple Tabelle, Ziel nach 4 Wochen: 50 Einträge, davon grob 30 ICP-Entscheider, 10 Multiplikatoren (Verbände, Medien, Community-Stimmen), 10 Fach-Peers. Spalten: Name, Rolle, Firma, Größe, Quelle (welcher Post), letzter Kontakt, Status (beobachtet, kommentiert, vernetzt, DM, Gespräch).

Quellen fürs Befüllen, in dieser Reihenfolge: (a) Kommentatoren und Reagierende unter T1- und T2-Posts, (b) LinkedIn-Suche mit Rollen-Filtern: „Geschäftsführer" oder „Partner" oder „IT-Leiter" kombiniert mit „SAP-Beratung", „IT-Beratung", „Prozessberatung", Region DACH, (c) Aussteller- und Sprecherlisten von DSAG-Jahreskongress und BDU-Veranstaltungen, (d) die eigenen Vernetzungen von Caspar (sein Adressbuch ist die Startliste, er markiert die 20 wärmsten).

**Vernetzungsanfragen immer mit Bezugszeile,** zwei Vorlagen: An ICP nach Interaktion: „Ihr Kommentar zur [Thema] bei [Quelle] hat mich abgeholt, ich schreibe gerade regelmäßig zu KI in Beratungen ohne Datenabfluss. Würde mich über den Austausch freuen." An Fach-Peer: „Ihre Sicht auf [Thema] deckt sich mit dem, was wir beim Bauen sehen, ich vernetze mich gern für den fachlichen Austausch." Nie eine Anfrage ohne vorherige Interaktion oder gemeinsamen Kontext.

## 5. Die Wochenstruktur

| Tag | Julian (15 min) | Caspar (10 min) | Paul (10 min) |
|---|---|---|---|
| Mo | T1 Verbände: 3 Kommentare, 3 Accounts in die Liste | T2-Posts an Julian liefern, 2 eigene Kommentare | T4: 2 Kommentare |
| Di | T3 Governance-Szene: 3 Kommentare | ICP-Liste pflegen, 5 Vernetzungen mit Bezugszeile | T4: 2 Kommentare |
| Mi | eigener Post + 60-Minuten-Fenster (alle drei) | Kommentar oder Teilen mit Einordnung binnen 1 h | Kommentar binnen 1 h |
| Do | eigener Post + 60-Minuten-Fenster (alle drei) | Kommentar binnen 1 h | Kommentar binnen 1 h |
| Fr | T1/T5: 3 Kommentare, DM-Runde an Reagierende | 5 Vernetzungen, wärmste Kontakte markieren | T4: 2 Kommentare |

Das 60-Minuten-Fenster nach eigenen Posts ist heilig: drei substanzielle Kommentare in der ersten Stunde verstärken die Reichweite rund fünffach; danach beantwortet Julian jeden Kommentar am selben Tag.

## 6. Kommentar-Bausteine je Anlass (adaptieren, nie kopieren)

**Unter Copilot-Erfolgsposts:** „Spannend, und die unbequeme Frage dahinter: Wie alt sind die Berechtigungen, auf denen das läuft? Wir sehen, dass zwei Drittel der Rollouts genau daran hängen, nicht am Modell."
**Unter KI-Verbotsposts:** „Verbote verschieben die Nutzung nur in private Tabs. Aktuelle Erhebungen sehen über 40 Prozent Nutzung ohne Freigabe. Die wirksamere Frage ist, welcher sanktionierte Weg besser ist als der Schattenweg."
**Unter Agenten-Autonomie-Hype:** „Die interessantere Achse als schwierig/leicht ist bindend/vorbereitend: beliebig schwere Vorbereitung ja, bindende Entscheidungen nein. Dann wird Eskalation zum Designprinzip statt zum Versagen."
**Unter RAG-Architektur-Posts:** „Mit 262k Kontext lohnt die Gegenfrage, ob man für sensible Bestände überhaupt persistent einbetten will. Manchmal ist der beste Vektorindex keiner, ephemer verarbeiten reicht."
**Unter „KI ersetzt Berater"-Posts:** „Gekauft wird im Consulting menschliches Urteil, und die Vertrauenszahlen dazu sind eindeutig. Die realistische Rolle der KI ist die Zuarbeit, die den Berater vom Beraten abhält. Das ist kein kleinerer Markt, es ist der größere Hebel."
**Unter Doku-/Wissensmanagement-Posts:** „Seit Agenten mitlesen, gibt es faktisch zwei Leserschaften. Wer beide Fassungen von Hand pflegt, hat nach drei Monaten zwei Wahrheiten. Die Maschinenfassung muss kompiliert werden, nie gepflegt."

## 7. Messung und Übergabe an den Vertrieb

Freitags, dieselben 15 Minuten wie im Masterplan: Antwortquote auf Kommentare, neue ICP-Verbindungen, DMs, entstandene Gespräche. Jeder Status „Gespräch" wandert sofort an Caspar mit Kontextzeile (welcher Post, welcher Kommentar, welche Frage kam). Ab drei Gesprächen aus einem Thema bekommt das Thema Serien-Status im Kalender.
