# Founder-led LinkedIn · Evidenz und die Woche-1-Posts, fertig zum Einstellen

Stand 17. August 2026. Ergänzt den Masterplan: erst die Wirkmechanik mit Zahlen, dann P0a und P6 komplett ausformuliert.

---

## 1. Warum Founder-led, in fünf belegten Sätzen

1. **Personenprofile schlagen Unternehmensseiten um Längen:** median ≈ 4,7 % Engagement gegen 1 bis 2 %, bis zu 8-fach; Personenposts bekommen rund 65 % des Feed-Raums, Firmenseiten etwa 5 %. Die Consultry-Seite ist Archiv, die Gründer sind der Kanal.
2. **Die erste Stunde entscheidet:** Posts mit drei oder mehr substanziellen Kommentaren in den ersten 60 Minuten erhalten rund 5,2-fache Reichweiten-Verstärkung. Genau dafür existiert die Pflicht im Kalender: Die beiden Nicht-Poster kommentieren binnen einer Stunde, mit Substanz, nicht mit „Stark!".
3. **Der Algorithmus bewertet inzwischen Kontext und Expertise,** nicht nur Klicksignale. Fachliche Tiefe aus der Ich-Perspektive ist also kein Stilmittel, sondern Verteilungslogik. Unser Substanz-Fundus ist dafür gebaut.
4. **Kadenz: zwei bis drei Posts je Woche,** konstant, nicht mehr. Deckt sich mit dem Masterplan (2 je Woche über alle drei Profile).
5. **Firmenseiten-Reichweite fällt weiter** (rund 60 bis 66 % organischer Rückgang seit 2024). Konsequenz: Kein Post zuerst auf der Firmenseite; sie repostet die Gründer, nie umgekehrt.

---

## 2. P0a · Der Origin-Post (Caspar, Woche 1, Post 1)

**Bild:** echtes Foto (Caspar im Gespräch oder am Whiteboard mit der 40-Stunden-Rechnung), kein Stock, kein Logo.

**Post-Text:**

Zehn unbezahlte Stunden pro Woche machten mich zum Gründer.

Ich verkaufe seit Jahren IT-Beratung. Ich verhandle die Angebote, sitze in den Terminen, sehe die Wochen der Berater aus nächster Nähe.

Und jede Woche dieselbe Rechnung:

40 Stunden. 30 davon fakturierbar. 10 gehen intern drauf. Angebote zusammensuchen, Protokolle nachziehen, Folien bauen, Reisekosten.

Diese zehn Stunden bezahlt kein Kunde. Bei einem durchschnittlichen Stundensatz von 162,50 Euro ist das jede Woche ein vierstelliger Betrag. Pro Berater.

Lange dachte ich: Das ist eben der Preis des Geschäfts.

In vielen Gesprächen mit Geschäftsführern von Beratungen habe ich verstanden: Alle zahlen ihn. Kaum jemand rechnet ihn aus. Und die, die ihn ausrechnen, finden kein Werkzeug, das ihn senkt, ohne dass Kundendaten das Haus verlassen.

Deshalb baue ich jetzt Consultry. Mit Julian, der fünf Jahre Finanzsysteme geschützt hat. Und mit Paul, der neun Jahre Konzern-IT-Projekte gestemmt hat.

KI-Agenten, die die interne Zuarbeit übernehmen. Im eigenen Microsoft-Tenant der Beratung. Wir hosten nichts.

Und damit das klar ist: Wir ersetzen keine Berater. Wir geben ihnen ihre Arbeit zurück.

An die Geschäftsführer hier: Wie viele eurer 40 Stunden bezahlt am Ende wirklich ein Kunde?

**Erster Kommentar (Caspar, direkt nach Publish):** „Zahlenbasis: Ø-Tagessatz 1.300 € laut BDU, Honorare im Consulting 2025; die zehn internen Stunden sind eine Annahme aus unseren Gesprächen, oft eher mehr. Wir rechnen solche Werte immer als Zielannahmen, nie als Messwerte. Mehr: consultry.de"

---

## 3. P6 · Das Zehn-Stunden-Carousel (Caspar, Woche 1, Post 2)

**Format:** Dokument-Post, 9 Folien, Design aus der Folie-2-Optik schneiden (Palette, Range-Balken), erste Folie muss allein funktionieren.

| Folie | Copy |
|---|---|
| 1 | **Zehn Stunden jeder Beraterwoche bezahlt kein Kunde.** Die Rechnung. |
| 2 | Die Woche eines Beraters: **40 Stunden.** 30 fakturierbar. 10 intern. |
| 3 | Die zehn internen: Angebote, Recherche, Protokolle, Folien, Reisekosten. **Jede Woche dieselben Schleifen.** |
| 4 | Was die Stunde wert wäre: **Ø 162,50 €.** (BDU 2025, Ø-Tagessatz 1.300 €) |
| 5 | Repetitiv heißt: **automatisierbar.** Zielannahme: 3,5 der 10 Stunden übernimmt ein Agent. |
| 6 | 3,5 h × 162,50 € × 4 Wochen ≈ **2.275 € je Berater und Monat.** |
| 7 | Ehrlich: Das ist eine **Zielannahme, kein Messwert.** Wir rechnen sie öffentlich, damit Sie nachrechnen können. |
| 8 | Der Bonus: Kunden fordern die KI-Rendite bisher nicht ein. **Die Ersparnis bleibt als Marge im Haus.** (Lünendonk 2026: 43 % sehen keine Preiswirkung) |
| 9 | **Die zehn internen Stunden sind jetzt dran.** Consultry · KI im Tenant der Beratung · consultry.de |

**Caption:**

Zehn Stunden jeder Beraterwoche bezahlt kein Kunde.

Wir haben die Rechnung aufgemacht, mit allen Annahmen offen auf den Folien. Kein Messwert, eine Zielannahme, absichtlich konservativ erklärt.

Rechnet gern nach: Wo landet ihr bei euch im Haus?

**Erster Kommentar:** Quellen gebündelt: BDU Honorare 2025 (Tagessatz), Lünendonk-Liste 2026 via consulting.de (Preiswirkung), Feldversuch Harvard/BCG 2023 zur Qualität je Aufgabe. Links einzeln, damit der Post selbst linkfrei bleibt.

---

## 4. Publishing-Checkliste Woche 1

Dienstag oder Mittwoch Vormittag posten (P0a), Donnerstag Vormittag P6. Kein Link im Post, Links in den ersten Kommentar. Julian und Paul kommentieren binnen 60 Minuten mit Substanz (je eine eigene Beobachtung, kein Applaus), denn drei echte Kommentare in der ersten Stunde verfünffachen die Reichweite. Caspar beantwortet jeden Kommentar am selben Tag; bei ICP-Kommentaren greift das DM-Playbook (danken, eine Frage: „Wo liegen eure Projektdokumente heute wirklich?"). Firmenseite repostet frühestens am Folgetag. Freitag: die drei Messzahlen notieren (ICP-Reaktionen, Profilbesuche, entstandene Gespräche).
