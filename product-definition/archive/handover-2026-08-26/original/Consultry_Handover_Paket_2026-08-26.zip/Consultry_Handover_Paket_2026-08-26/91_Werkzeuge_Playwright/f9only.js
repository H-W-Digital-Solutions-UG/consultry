const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#9'); await p.reload();
  await p.waitForTimeout(700);
  for (let i = 0; i < 2; i++) { await p.keyboard.press('ArrowRight'); await p.waitForTimeout(300); }
  await p.waitForTimeout(900);
  await p.screenshot({ path: '/home/claude/fix_f9.png' });
  await b.close();
})();
