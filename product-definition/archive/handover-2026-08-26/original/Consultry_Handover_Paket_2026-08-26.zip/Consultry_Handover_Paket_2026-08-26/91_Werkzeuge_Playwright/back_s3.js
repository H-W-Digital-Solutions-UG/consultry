const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
  await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
  await p.waitForTimeout(2000);
  const seq = [];
  const read = () => p.evaluate(() => {
    const sec = document.querySelector('section[aria-label="Statement"]');
    const vis = [...sec.querySelectorAll('.pd')].filter(x => getComputedStyle(x).opacity > .9).map(x => x.getAttribute('data-st'));
    return sec.getAttribute('data-stage') + '|vis:' + vis.join(',');
  });
  seq.push('start ' + await read());
  for (const k of ['ArrowRight','ArrowRight','ArrowLeft','ArrowRight','ArrowRight','ArrowLeft']) {
    await p.keyboard.press(k); await p.waitForTimeout(650);
    seq.push(k.replace('Arrow','') + ' -> ' + await read());
  }
  console.log(seq.join('\n'));
  await b.close();
})();
