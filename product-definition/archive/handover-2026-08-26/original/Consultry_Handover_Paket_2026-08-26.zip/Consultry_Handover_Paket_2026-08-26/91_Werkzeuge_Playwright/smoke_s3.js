const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  const errs = [];
  p.on('pageerror', e => errs.push('pageerror: ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
  await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
  for (const h of [2, 4]) {
    await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#' + h);
    await p.waitForTimeout(1800);
    const ok = await p.evaluate(() => {
      const de = document.documentElement;
      return de.scrollWidth <= innerWidth + 1 && de.scrollHeight <= innerHeight + 1;
    });
    console.log('slide #' + h + ' overflow-free:', ok);
  }
  // back-stepping on slide 3
  await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
  await p.waitForTimeout(1500);
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(500);
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(500);
  await p.keyboard.press('ArrowLeft'); await p.waitForTimeout(700);
  const r = await p.evaluate(() => {
    const sec = document.querySelector('section[aria-label="Statement"]');
    const pd2 = sec.querySelector('.pd[data-st="2"]'), pd3 = sec.querySelector('.pd[data-st="3"]');
    return { stage: sec.getAttribute('data-stage'),
      pd2: getComputedStyle(pd2).opacity, pd3: getComputedStyle(pd3).opacity,
      card2cur: sec.querySelector('.vcard[data-st="2"]').classList.contains('cur') };
  });
  console.log('after fwd,fwd,back:', JSON.stringify(r));
  console.log(errs.length ? 'JS ERRORS:\n' + errs.join('\n') : 'no JS errors');
  await b.close();
})();
