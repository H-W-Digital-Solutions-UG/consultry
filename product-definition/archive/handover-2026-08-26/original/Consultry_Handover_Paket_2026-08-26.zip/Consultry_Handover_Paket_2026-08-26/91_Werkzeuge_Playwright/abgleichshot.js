const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  await pg.goto('file:///home/claude/Consultry_PPT_Investor_Abgleich.html', { waitUntil: 'domcontentloaded' });
  await pg.waitForTimeout(700);
  await pg.evaluate(() => { document.documentElement.style.scrollBehavior = 'auto'; });
  const over = await pg.evaluate(() => {
    const bad = [];
    document.querySelectorAll('body *').forEach(el => {
      if (el instanceof SVGElement) return;
      if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX !== 'auto' && getComputedStyle(el).overflowX !== 'scroll')
        bad.push(el.tagName + '.' + (el.className || '').toString().slice(0, 30));
    });
    return bad.slice(0, 8);
  });
  console.log('Overflow:', JSON.stringify(over));
  await pg.screenshot({ path: '/home/claude/shots/abgleich_top.png', clip: { x: 0, y: 0, width: 1280, height: 900 } });
  await pg.evaluate(() => document.querySelector('#s6').scrollIntoView({ behavior: 'instant' }));
  await pg.waitForTimeout(300);
  await pg.screenshot({ path: '/home/claude/shots/abgleich_s6a.png' });
  await pg.evaluate(() => window.scrollBy(0, 850));
  await pg.waitForTimeout(300);
  await pg.screenshot({ path: '/home/claude/shots/abgleich_s6b.png' });
  await b.close();
  console.log('done');
})();
