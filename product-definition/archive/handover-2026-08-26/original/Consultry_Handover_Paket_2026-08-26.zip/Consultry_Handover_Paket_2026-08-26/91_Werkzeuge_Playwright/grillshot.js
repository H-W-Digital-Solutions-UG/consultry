const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1400, height: 1000 } });
  await p.goto('file:///home/claude/Consultry_Deck_Grill_Website.html');
  await p.waitForTimeout(300);
  await p.screenshot({ path: '/home/claude/grill_full.png', fullPage: true });
  const issues = await p.evaluate(() => {
    const out = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX !== 'hidden')
        out.push(el.className + ' sw=' + el.scrollWidth + ' cw=' + el.clientWidth);
    });
    return out.slice(0, 6);
  });
  console.log('overflow:', issues.length ? issues : 'none');
  await b.close();
})();
