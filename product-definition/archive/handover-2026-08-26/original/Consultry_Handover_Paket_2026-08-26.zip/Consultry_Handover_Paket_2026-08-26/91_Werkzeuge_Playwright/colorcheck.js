const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
  await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
  await p.waitForTimeout(2000);
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(1800);
  console.log(await p.evaluate(() => {
    const sec = document.querySelector('section[aria-label="Statement"]');
    return {
      num: getComputedStyle(sec.querySelector('.sblock .num')).color,
      lnb: getComputedStyle(sec.querySelector('.sblock .ln b')).color,
    };
  }));
  await p.screenshot({ path: '/home/claude/shots/final_st2.png' });
  await b.close();
})();
