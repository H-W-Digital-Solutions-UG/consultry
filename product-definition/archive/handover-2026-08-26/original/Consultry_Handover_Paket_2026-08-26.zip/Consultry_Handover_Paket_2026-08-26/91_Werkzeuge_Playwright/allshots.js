const { chromium } = require('playwright');

(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const p = await b.newPage({ viewport: { width: 1600, height: 900 } });
  const url = 'file:///home/claude/Consultry_Pitchdeck_v10.html';
  await p.goto(url, { waitUntil: 'networkidle' });
  for (let n = 1; n <= 15; n++) {
    await p.goto(url + '#' + n);
    await p.reload({ waitUntil: 'networkidle' });
    await p.waitForTimeout(500);
    await p.evaluate(() => {
      const sec = document.querySelector('section.slide.active') || document.querySelectorAll('section.slide')[0];
      const els = sec.querySelectorAll('[data-st]');
      let mx = 0;
      els.forEach(e => { mx = Math.max(mx, +e.getAttribute('data-st') || 0); });
      if (mx > 0) sec.setAttribute('data-stage', mx);
      els.forEach(e => e.classList.add('on'));
    });
    await p.waitForTimeout(900);
    await p.screenshot({ path: `/home/claude/shots/deck_f${String(n).padStart(2, '0')}.png` });
    console.log('shot', n);
  }
  await b.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
