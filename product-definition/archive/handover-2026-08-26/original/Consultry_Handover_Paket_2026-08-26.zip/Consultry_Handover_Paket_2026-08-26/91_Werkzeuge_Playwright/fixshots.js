const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  const slides = { 1:1, 4:5, 6:3, 8:3, 9:3, 11:2, 14:1 };
  for (const [n, stages] of Object.entries(slides)) {
    await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#' + n); await p.reload();
    await p.waitForTimeout(650);
    for (let i = 1; i < stages; i++) { await p.keyboard.press('ArrowRight'); await p.waitForTimeout(350); }
    await p.waitForTimeout(850);
    const ov = await p.evaluate(() => {
      const act = document.querySelector('.slide.active');
      const out = [];
      act.querySelectorAll('*').forEach(el => { if (el instanceof SVGElement) return;
        const cs = getComputedStyle(el);
        if (el.scrollWidth > el.clientWidth + 3 && cs.overflowX !== 'hidden' && el.clientWidth > 0)
          out.push((el.className.baseVal || el.className).toString().slice(0,40) + ' sw=' + el.scrollWidth + ' cw=' + el.clientWidth);
      });
      const r = act.getBoundingClientRect();
      return { out: out.slice(0,5), tall: act.scrollHeight > window.innerHeight + 4 };
    });
    console.log('Folie', n, 'overflow:', ov.out.length ? ov.out : 'none', ov.tall ? '· ZU HOCH' : '');
    await p.screenshot({ path: `/home/claude/fix_f${n}.png` });
  }
  await b.close();
})();
