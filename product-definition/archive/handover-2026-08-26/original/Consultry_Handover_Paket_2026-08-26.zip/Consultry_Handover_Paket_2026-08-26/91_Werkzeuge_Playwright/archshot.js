const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1400, height: 1000 } });
  await p.goto('file:///home/claude/Consultry_Datengrenze_Visual.html');
  await p.waitForTimeout(400);
  await p.screenshot({ path: '/home/claude/arch_full.png', fullPage: true });
  // Overflow-Check
  const issues = await p.evaluate(() => {
    const out = [];
    document.querySelectorAll('*').forEach(el => {
      if (el.scrollWidth > el.clientWidth + 2 && getComputedStyle(el).overflowX !== 'hidden')
        out.push(el.className + ' sw=' + el.scrollWidth + ' cw=' + el.clientWidth);
    });
    return out.slice(0, 8);
  });
  console.log('overflow:', issues.length ? issues : 'none');
  await b.close();
})();
