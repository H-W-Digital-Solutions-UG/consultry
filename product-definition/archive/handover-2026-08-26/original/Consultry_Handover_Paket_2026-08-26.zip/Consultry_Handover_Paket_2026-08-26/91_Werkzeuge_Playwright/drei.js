const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const p = await b.newPage({ viewport: { width: 1920, height: 1080 } });
  await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
  await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
  await p.waitForTimeout(2500);
  await p.screenshot({ path: '/home/claude/shots/d_st1.png' });
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(1800);
  await p.screenshot({ path: '/home/claude/shots/d_st2.png' });
  await p.keyboard.press('ArrowRight'); await p.waitForTimeout(1800);
  await p.screenshot({ path: '/home/claude/shots/d_st3.png' });
  await b.close(); console.log('done');
})();
