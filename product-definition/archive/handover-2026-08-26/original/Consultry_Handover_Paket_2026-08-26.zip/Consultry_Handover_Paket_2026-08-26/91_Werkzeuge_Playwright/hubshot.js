const { chromium } = require('playwright');

(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const p = await b.newPage({ viewport: { width: 1400, height: 1000 } });
  const errs = [];
  p.on('pageerror', e => errs.push('PAGEERROR: ' + e.message));
  p.on('console', m => { if (m.type() === 'error') errs.push('CONSOLE: ' + m.text()); });

  await p.goto('file:///home/claude/Consultry_LinkedIn_Hub.html', { waitUntil: 'networkidle' });
  await p.waitForTimeout(600);

  // Overflow check (exclude SVG elements)
  const overflows = await p.evaluate(() => {
    const out = [];
    const dw = document.documentElement.clientWidth;
    document.querySelectorAll('*').forEach(el => {
      if (el instanceof SVGElement) return;
      const r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) return;
      if (r.right > dw + 2 || r.left < -2) {
        out.push(`${el.tagName}.${(el.className || '').toString().slice(0, 40)} L=${Math.round(r.left)} R=${Math.round(r.right)} dw=${dw} txt=${(el.textContent || '').trim().slice(0, 50)}`);
      }
    });
    return out.slice(0, 25);
  });

  // Horizontal scroll check
  const hscroll = await p.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);

  // Page metrics
  const height = await p.evaluate(() => document.body.scrollHeight);

  // Test copy button presence + section anchors
  const checks = await p.evaluate(() => {
    const r = {};
    r.posts = document.querySelectorAll('.post').length;
    r.copyBtns = document.querySelectorAll('.copybtn, button').length;
    r.sections = ['s1', 's2', 's3', 's4'].map(id => !!document.getElementById(id));
    r.navLinks = document.querySelectorAll('nav a, .nav a').length;
    r.tables = document.querySelectorAll('table').length;
    return r;
  });

  // Full page screenshot
  await p.screenshot({ path: '/home/claude/shots/hub_full.png', fullPage: true });

  // Crops: top (header+nav+strategie), calendar, one post card, playbook
  const cropTargets = [
    ['hub_top', 0],
    ['hub_kalender', '#s2'],
    ['hub_posts', '#s3'],
    ['hub_playbook', '#s4'],
  ];
  for (const [name, target] of cropTargets) {
    if (target === 0) {
      await p.evaluate(() => window.scrollTo(0, 0));
    } else {
      await p.evaluate(t => { const el = document.querySelector(t); if (el) el.scrollIntoView(); }, target);
    }
    await p.waitForTimeout(250);
    await p.screenshot({ path: `/home/claude/shots/${name}.png` });
  }

  // Scroll a bit into posts to capture a full post card mid-view
  await p.evaluate(() => { const el = document.querySelector('#s3'); if (el) window.scrollTo(0, el.offsetTop + 900); });
  await p.waitForTimeout(250);
  await p.screenshot({ path: '/home/claude/shots/hub_postcard.png' });

  console.log(JSON.stringify({ errs, overflows, hscroll, height, checks }, null, 1));
  await b.close();
})().catch(e => { console.error('FATAL', e); process.exit(1); });
