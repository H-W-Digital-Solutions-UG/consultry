const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  const vps = [[1920,1080],[1440,810],[1280,720]];
  let fails = 0;
  for (const [W,H] of vps) {
    const page = await browser.newPage({ viewport: { width: W, height: H } });
    await page.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
    await page.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
    await page.waitForTimeout(2600);
    for (let st = 1; st <= 4; st++) {
      if (st > 1) { await page.keyboard.press('ArrowRight'); await page.waitForTimeout(900); }
      const res = await page.evaluate((stage) => {
        const sec = document.querySelector('section[aria-label="Statement"]');
        const out = { probs: [], stageAttr: sec.getAttribute('data-stage') };
        // overflow of viewport
        const de = document.documentElement;
        if (de.scrollWidth > innerWidth + 1 || de.scrollHeight > innerHeight + 1)
          out.probs.push(`doc overflow ${de.scrollWidth}x${de.scrollHeight} vs ${innerWidth}x${innerHeight}`);
        // elements poking outside viewport
        sec.querySelectorAll('.statement,.vcard,.pd.cur,.punch,.msrc,.statbox,.klist li').forEach(el => {
          const r = el.getBoundingClientRect();
          if (r.width && (r.left < -1 || r.right > innerWidth + 1 || r.top < -1 || r.bottom > innerHeight + 1))
            out.probs.push(`outside viewport: ${el.className.split(' ')[0]} ${Math.round(r.left)},${Math.round(r.top)},${Math.round(r.right)},${Math.round(r.bottom)}`);
        });
        // panel opacities
        sec.querySelectorAll('.pd').forEach(pd => {
          const o = parseFloat(getComputedStyle(pd).opacity);
          const st2 = +pd.getAttribute('data-st');
          if (st2 === stage && o < 0.95) out.probs.push(`pd${st2} should be visible, opacity=${o}`);
          if (st2 !== stage && o > 0.05) out.probs.push(`pd${st2} should be hidden, opacity=${o}`);
        });
        // card states
        sec.querySelectorAll('.vcard').forEach(c => {
          const st2 = +c.getAttribute('data-st');
          const isCur = c.classList.contains('cur');
          if ((st2 === stage) !== isCur) out.probs.push(`vcard${st2} cur mismatch`);
          const op = parseFloat(getComputedStyle(c).opacity);
          if (op < 0.9) out.probs.push(`vcard${st2} opacity ${op}`);
        });
        // svg text inside viewBox (current panel only)
        const pd = sec.querySelector(`.pd[data-st="${stage}"]`);
        const svg = pd.querySelector('svg');
        if (svg) {
          const vb = svg.viewBox.baseVal;
          svg.querySelectorAll('text').forEach(t => {
            try {
              const b = t.getBBox();
              if (b.x < vb.x - 1 || b.x + b.width > vb.x + vb.width + 1 || b.y < vb.y - 1 || b.y + b.height > vb.y + vb.height + 1)
                out.probs.push(`svg text clipped: "${t.textContent.slice(0,22)}" bbox ${Math.round(b.x)},${Math.round(b.y)},${Math.round(b.x+b.width)},${Math.round(b.y+b.height)} vb ${vb.x},${vb.y},${vb.x+vb.width},${vb.y+vb.height}`);
            } catch(e){}
          });
        }
        // statement single line?
        const st3 = sec.querySelector('.statement');
        const lh = parseFloat(getComputedStyle(st3).fontSize) * 1.15;
        if (st3.getBoundingClientRect().height > lh * 1.8) out.probs.push(`statement wrapped to 2+ lines (h=${Math.round(st3.getBoundingClientRect().height)})`);
        // punch vs msrc collision
        const p = sec.querySelector('.punch').getBoundingClientRect();
        const m = sec.querySelector('.msrc').getBoundingClientRect();
        if (p.bottom > m.top - 2) out.probs.push(`punch/msrc collide punch.bottom=${Math.round(p.bottom)} msrc.top=${Math.round(m.top)}`);
        return out;
      }, st);
      const tag = `${W}x${H} st${st}`;
      if (res.stageAttr !== String(st)) { console.log(`FAIL ${tag}: data-stage=${res.stageAttr}`); fails++; }
      if (res.probs.length) { fails += res.probs.length; res.probs.forEach(p => console.log(`FAIL ${tag}: ${p}`)); }
      else console.log(`ok   ${tag}`);
      if (W === 1920) await page.screenshot({ path: `/home/claude/shots/s3_st${st}.png` });
      if (W === 1280 && (st === 1 || st === 4)) await page.screenshot({ path: `/home/claude/shots/s3_${W}_st${st}.png` });
    }
    await page.close();
  }
  await browser.close();
  console.log(fails ? `TOTAL FAILS: ${fails}` : 'ALL CLEAN');
})();
