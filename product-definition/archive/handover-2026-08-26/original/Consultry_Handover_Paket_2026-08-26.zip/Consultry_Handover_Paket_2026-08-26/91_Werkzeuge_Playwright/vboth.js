const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  let fails = 0;
  for (const [W,H] of [[1920,1080],[1280,720]]) {
    for (const [hash,stages,label] of [[2,3,'Wandel'],[3,3,'Statement']]) {
      const p = await b.newPage({ viewport: { width: W, height: H } });
      await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
      await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#' + hash);
      await p.waitForTimeout(2400);
      for (let st = 1; st <= stages; st++) {
        if (st > 1) { await p.keyboard.press('ArrowRight'); await p.waitForTimeout(1700); }
        const probs = await p.evaluate((lab) => {
          const out = [];
          const de = document.documentElement;
          if (de.scrollWidth > innerWidth + 1 || de.scrollHeight > innerHeight + 1) out.push('doc overflow');
          const sec = document.querySelector(`section[aria-label="${lab}"]`);
          sec.querySelectorAll('.scene svg').forEach(svg => {
            const vb = svg.viewBox.baseVal;
            svg.querySelectorAll('text').forEach(t => {
              try { const bx = t.getBBox();
                if (bx.x < vb.x-1 || bx.x+bx.width > vb.x+vb.width+1 || bx.y < vb.y-1 || bx.y+bx.height > vb.y+vb.height+1)
                  out.push(`clip "${t.textContent.slice(0,18)}"`);
              } catch(e){}
            });
          });
          return out;
        }, label);
        const tag = `${W}x${H} #${hash} st${st}`;
        if (probs.length) { fails += probs.length; probs.forEach(x => console.log('FAIL ' + tag + ': ' + x)); }
        else console.log('ok   ' + tag);
        if (W === 1920) await p.screenshot({ path: `/home/claude/shots/j_${hash}_st${st}.png` });
      }
      await p.close();
    }
  }
  await b.close();
  console.log(fails ? 'FAILS: ' + fails : 'ALL CLEAN');
})();
