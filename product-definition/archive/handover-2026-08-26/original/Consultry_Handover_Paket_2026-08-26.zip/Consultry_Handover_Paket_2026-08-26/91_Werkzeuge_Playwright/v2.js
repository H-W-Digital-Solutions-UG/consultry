const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium' });
  let fails = 0;
  for (const [W,H] of [[1920,1080],[1440,810],[1280,720]]) {
    const p = await b.newPage({ viewport: { width: W, height: H } });
    await p.route('**/*', r => r.request().url().startsWith('file://') ? r.continue() : r.abort());
    await p.goto('file:///home/claude/Consultry_Pitchdeck_v10.html#3');
    await p.waitForTimeout(2400);
    for (let st = 1; st <= 2; st++) {
      if (st > 1) { await p.keyboard.press('ArrowRight'); await p.waitForTimeout(1700); }
      const r = await p.evaluate((stage) => {
        const sec = document.querySelector('section[aria-label="Statement"]');
        const probs = [];
        const de = document.documentElement;
        if (de.scrollWidth > innerWidth + 1 || de.scrollHeight > innerHeight + 1) probs.push('doc overflow');
        if (sec.getAttribute('data-stage') !== String(stage)) probs.push('stage=' + sec.getAttribute('data-stage'));
        sec.querySelectorAll('.sw[data-st]').forEach(g => {
          const o = parseFloat(getComputedStyle(g).opacity);
          const m = +g.getAttribute('data-st');
          const want = m <= stage ? (g.classList.contains('scap') ? (m === stage ? 1 : 0) : 1) : 0;
          if (Math.abs(o - want) > .1) probs.push(`sw st${m} ${g.tagName}${g.classList.contains('scap')?'.scap':''} opacity ${o} want ${want}`);
        });
        const svg = sec.querySelector('.scene svg');
        const vb = svg.viewBox.baseVal;
        svg.querySelectorAll('text').forEach(t => {
          try { const bx = t.getBBox();
            if (bx.x < vb.x-1 || bx.x+bx.width > vb.x+vb.width+1 || bx.y < vb.y-1 || bx.y+bx.height > vb.y+vb.height+1)
              probs.push(`clip "${t.textContent.slice(0,18)}" ${Math.round(bx.x)},${Math.round(bx.y)},${Math.round(bx.x+bx.width)},${Math.round(bx.y+bx.height)}`);
          } catch(e){}
        });
        const m2 = sec.querySelector('.msrc').getBoundingClientRect();
        const sc = sec.querySelector('.scaps').getBoundingClientRect();
        if (sc.bottom > m2.top - 2) probs.push('scaps/msrc collide');
        return probs;
      }, st);
      const tag = `${W}x${H} st${st}`;
      if (r.length) { fails += r.length; r.forEach(x => console.log('FAIL ' + tag + ': ' + x)); } else console.log('ok   ' + tag);
      if (W === 1920 || (W === 1280 && st === 2)) await p.screenshot({ path: `/home/claude/shots/v2_${W}_st${st}.png` });
    }
    await p.close();
  }
  await b.close();
  console.log(fails ? 'FAILS: ' + fails : 'ALL CLEAN');
})();
