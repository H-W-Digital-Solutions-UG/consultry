const { chromium } = require('/opt/node-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' });
  const pg = await b.newPage({ viewport: { width: 1280, height: 900 } });
  await pg.goto('file:///home/claude/Consultry_Handover_Final.html', { waitUntil: 'domcontentloaded' });
  await pg.waitForTimeout(600);
  await pg.evaluate(() => { document.documentElement.style.scrollBehavior = 'auto'; });
  const over = await pg.evaluate(() => {
    const bad = [];
    document.querySelectorAll('body *').forEach(el => {
      if (el instanceof SVGElement) return;
      const cs = getComputedStyle(el);
      if (el.scrollWidth > el.clientWidth + 2 && cs.overflowX !== 'auto' && cs.overflowX !== 'scroll')
        bad.push(el.tagName + '.' + (el.className || '').toString().slice(0, 28));
    });
    return bad.slice(0, 8);
  });
  const chips = await pg.evaluate(() => [...document.querySelectorAll('.chips a')].every(a => document.querySelector(a.getAttribute('href'))));
  console.log('Overflow:', JSON.stringify(over), '| Chip-Anker ok:', chips);
  await pg.screenshot({ path: '/home/claude/shots/ho_top.png' });
  for (const [id, name] of [['#s2','ho_fakten'],['#s3','ho_inventar'],['#s4','ho_log'],['#s9','ho_regeln']]) {
    await pg.evaluate(sel => document.querySelector(sel).scrollIntoView({ behavior: 'instant' }), id);
    await pg.waitForTimeout(250);
    await pg.screenshot({ path: `/home/claude/shots/${name}.png` });
  }
  await b.close();
  console.log('done');
})();
