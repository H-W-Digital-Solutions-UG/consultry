# Consultry: aktueller Kontext

Stand: 04.09.2026. Einstieg über [INDEX.md](INDEX.md). Herkunft und Gültigkeit: [DECISIONS.md](DECISIONS.md), [SOURCES.md](SOURCES.md).

## Produkt in einem Absatz

Consultry ist der AI-native Arbeitskern für spezialisierte Beratungen. Er verbindet Firmenwissen und Projekterfahrung mit laufender Akquise, Beratungsarbeit und Unternehmensführung. Menschen und Agenten arbeiten an konkreten Zielen und Ergebnissen; Wissen, Entscheidungen und relevante Zusammenhänge bleiben für weitere Arbeit nutzbar. Einfaches Quellen-/Connector-Onboarding, ein standardmäßig integriertes Harness und kontrollierte Daten- und Modellwege gehören zum Kern.

## Aktuelle Richtung, noch keine Lösungsfestlegung

Der Nutzer will die Visionsbildung abschließen und sich in Richtung eines technischen, Backend-getriebenen Starts bewegen. Genannte Interessen sind Security/Privacy, Brain beziehungsweise Graph mit laufender Wissensverknüpfung und konkrete Beratungsarbeit. Codex ist ein mögliches Beispiel für den Zugang, kein ausgewählter Pflichtclient.

Die alte Pflichtreihenfolge `vollständiger Click Dummy → UI-Tests → Three-Slice-Handoff → technischer PoC` wird deshalb nicht länger als unverrückbare Vorgabe weitergetragen. Die Erkenntnisse über Co-Work, Artefakte, Verantwortung und verständliche Interaktion bleiben erhalten. Eine eigene App bleibt im Zielbild, ohne daraus eine aktuelle Startvorbedingung abzuleiten.

Wichtige nachfolgende Nutzerkorrektur: „orientiere dich jedoch nicht zu sehr daran das war explorative“. Deshalb ist die Konsolidierung produktzentriert. Technische Ausprägungen, konkrete Erstfälle und Vorschläge dieses Pakets sind Gesprächsmaterial, keine neu ratifizierten Anforderungen.

## Tatsächlich vorhandener Stand

- Produktvision, sechs fachliche Coverage-Bereiche plus Adoption, Journey-Portfolio und umfangreiche Entscheidungs-/Research-Historie vorhanden.
- 59 lokale Wayfinder-Tickets: 27 geschlossen, 32 offen. Ihre Rohstatus wurden nicht geändert; neue Einordnung in DECISIONS.
- Ein Click Dummy mit mehreren HTML-Seiten und gemeinsamem `sessionStorage`-Zustand ist vorhanden: `Consultry APP UI Mockups/state.js`. Die ältere Aussage „kein verbundener Click Dummy“ ist damit überholt. Vollständige UX-Abnahme oder reale Nutzungsvalidierung sind durch diesen Codebefund nicht belegt.
- Marketing-Website mit Next.js und Waitlist-APIs vorhanden. Sie ist nicht das Consultry-Produkt-Backend.
- In den untersuchten aktiven Quellpfaden kein implementierter Consultry-Backend-Kern, keine Produkt-Datenbankmigrationen und keine produktive Harness-/Graph-Integration gefunden. Die umfangreichen Backend-Texte sind Planungskandidaten.
- Das Handover vom 26.08. enthält ein neueres Investor-Deck als `Consultry_Pitchdeck_vFML_isdas_geiel.html` im Root. Sein Pitch-Stand ist nicht automatisch Architekturfreigabe.

## Belastbarer Produktkern aus dem bisherigen Verlauf

- Zielorganisation ist die Beratung. Deren Klienten, Nutzer, interne Verantwortlichkeiten und technische Agenten sind verschiedene Akteure.
- Boutique und wachsende Spezialberatung bleiben unterstützte Organisationsformen. Das August-Paket erprobt IT/SAP, DACH, 20–200 Berater als engeren Markteinstieg; dieser wird hier nicht als verbindlicher Größenzuschnitt übernommen.
- Nutzen: kollektive Expertise nutzbar machen, bessere und wirtschaftlichere Arbeit, weniger Blind Spots, Synergien und Wiederverwendung. Rollenkompression beschreibt insbesondere in Boutiquen eine Bedarfssituation; sie ist kein primärer Produkt-Outcome.
- Harness by default bezeichnet die Ausführungs- und Arbeitsumgebung. Eine technische Harness-Oberfläche muss nicht jeder Nutzer bedienen.
- Ein Harness kann im Rahmen eingeräumter Ausführungsbefugnisse vorbereiten, ausführen, koordinieren, prüfen, stoppen und menschliche Beiträge einholen. Es besitzt dadurch keine eigene geschäftliche Entscheidungsautorität und ist nicht auf nächste-Schritt-Vorschläge beschränkt.
- Arbeitskontexte sind verbunden. Ob Informationen technisch verknüpft, abgerufen, synchronisiert oder übergeben werden, bleibt Teil des Lösungsentwurfs.
- Sales, sofern vorhanden, und Consultants aus relevanten Projekten wirken zusammen. In Boutiquen kann eine Person mehrere Verantwortlichkeiten tragen.
- Opportunity-to-Project besitzt Bestandskundensignal und Ausschreibung als Einstiege. Es ist ein wichtiger Wertpfad, nicht das gesamte Produkt.
- Reale Artefakterstellung und -verbesserung gehören ebenso zum Wert wie Retrieval. Inhalt, Corporate Design, Verwendungszweck und Rechte gehören zusammen.
- Quellen, Tests und Freigaben gehören in den jeweiligen Arbeitskontext. Es ist kein eigenständiges globales Quellenbestätigungsprodukt beauftragt.

## Begriffe für den nächsten Schritt

| Begriff | Arbeitsbedeutung |
|---|---|
| Consultry Core | Produktkern aus Arbeitskontext, Wissen, fachlichen Objekten, Autorität und Agenten-Anbindung |
| Brain/Firmengedächtnis | Quellenbezogene, zugriffsgerechte Wissens- und Kontextschicht; keine Garantie objektiver Wahrheit |
| Wissensgraph | explizite Beziehungen zwischen fachlichen Objekten, Quellen, Aussagen und Ergebnissen mit Herkunft und Gültigkeit |
| Core Skill Graph | passende, versionierte Skill-Definitionen samt Voraussetzungen und Beziehungen; nicht Bewertung von Mitarbeitenden |
| Execution Graph | Ausführungsschritte, Abhängigkeiten, Ereignisse und Zustände eines Laufs |
| Validation Graph | Beziehungen zwischen Ergebnissen, prüfbaren Kriterien, Evidenz und verbleibender Unsicherheit |
| Model Bridge | kontrollierte Nutzung passender Modelle unter Daten-, Zweck-, Qualitäts- und Budgetgrenzen |
| Harness | kontextgebundene Organisation/Ausführung von Menschen-, Agenten- und Tool-Arbeit |
| Control Plane | in Architekturentwürfen zentrale Betriebs-/Konfigurationsfunktionen; Ausprägung offen, nicht synonym zu Domain Core oder Brain |
| Mandant | die Consultry nutzende Beratung; ihre einzelnen Klienten benötigen zusätzlich eigene Vertraulichkeitsgrenzen |

Diese Graphrollen sind semantische Unterscheidungen. Daraus folgen noch keine vier Datenbanken oder eine bestimmte Laufzeit.

## Nächste zu klärende Frage

Zuerst den Organisationsvorschlag im Paket besprechen und die Trennung zwischen belastbarem Produktkern und Exploration prüfen. Erst danach einen ersten realen technischen Arbeitsfall auswählen. [BACKEND-START.md](BACKEND-START.md) bietet dafür mögliche Prüffragen; es setzt weder Codex noch einen Bestandskundenbrief voraus.

Schritt 5.1 der früheren Mock-Journey wurde bestätigt. Der danach vorgeschlagene zusätzliche dreistufige UX-Ablauf in Schritt 5.2 wurde in diesem Gespräch nicht ratifiziert. Die ältere fachliche Grenze zwischen erkanntem Signal und menschlicher Qualifizierung gilt davon unabhängig.
