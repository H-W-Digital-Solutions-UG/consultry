# Consultry: technische Suchrichtung — noch kein Bauauftrag

Stand: 04.09.2026. Der Nutzer möchte sich Richtung Backend/Security/Brain bewegen und hat zugleich betont, dass die bisherigen Ansätze explorativ waren. Dieses Dokument sichert deshalb eine mögliche Richtung. Es ist weder freigegebene Architektur noch WBS, Scope-Abnahme oder Pflichtprogramm vor dem nächsten Gespräch.

Zuerst gilt das Produktbild in PRODUCT. Codex, MCP, ein Graph Store, Managed In-Tenant und der folgende Beispiel-Job sind getrennte Optionen. Keine dieser Optionen ist durch diese Konsolidierung ausgewählt. Die konkreten Tests unten zeigen, wie man Behauptungen später prüfen könnte; sie sollen den Gesamtumfang nicht auf Quellenvalidierung verengen.

## Ein möglicher erster Arbeitsfall — austauschbares Beispiel

Ein Consultant bearbeitet einen möglichen Folgeauftrag bei einem Bestandskunden über einen geeigneten Client, beispielsweise Codex. Consultry verbindet erlaubte Projektquellen, Firmenmethoden und Referenzen, liefert aufgabenbezogenen Kontext und speichert einen daraus gemeinsam erarbeiteten internen Brief. Ändert sich eine relevante Quelle, zeigt das Backend, welche Aussagen und Ergebnisse betroffen sind. In einer neuen Client-Session bleibt dieser Arbeitsstand nutzbar.

Dies wäre ein technischer Vertikalschnitt innerhalb des Opportunity-to-Project-Pfads. Er ersetzt nicht den gesamten kommerziellen End-to-End-Umfang durch eine Suchfunktion. Ebenso denkbar: eine laufende Projektanalyse mit verändertem Wissensstand oder die Erstellung eines fachlichen Deliverables aus Firmenwissen. Welcher Fall den Kern am besten prüft, ist noch offen; die folgenden Details illustrieren nur den ersten Kandidaten.

## Ergebnis des Beispielkandidaten

Ein kurzer interner **Kundenbedarfs- und Projektbrief** mit:

- beobachtetem Bedarf und genauem Quellenbezug;
- relevanter bisheriger Projektarbeit und nutzbarer Firmenmethode;
- klar markierten Agentenableitungen;
- offenen Fragen und sinnvoll benötigtem Consultant-/Sales-Beitrag;
- möglichen nächsten Schritten als Optionen;
- Versionsstand, Ersteller und verantwortlicher menschlicher Einordnung.

Kein automatisch versendetes Angebot, kein erfundener Deal-Wert und keine verpflichtende zusätzliche Exploration-Objektklasse. Der fachliche Grundsatz menschlicher Opportunity-Qualifizierung bleibt erhalten.

## Erster Datenumfang

Empfehlung: eine fiktive Beratung mit zwei getrennten Klientenkontexten und mindestens zwei Berechtigungsprofilen. Für den Inhalt: Projekt-/Meetingnotiz, Leistungsbeschreibung, Firmenmethode, freigegebene Referenz sowie eine geänderte Quellenversion. Ein zweiter Mandanten-Fixture prüft zusätzlich die Trennung zwischen Consultry-Kunden.

Ein kontrollierter Dateiimport mit Wiederimport/Delta ist der kleinste echte Einstieg. Wenn der konkrete Pilot Microsoft 365 zwingend voraussetzt, kann stattdessen eine begrenzte SharePoint-Quelle gewählt werden. Diese Wahl verändert Authentifizierung und Ingestion-Aufwand und bleibt eine der wenigen offenen Entscheidungen.

## Funktionskette

```text
ausgewählte Quelle + gültiger Zugriff
    → Import und Versionierung
    → Aussagen und fachliche Beziehungen ableiten
    → Herkunft, Rechte und Aktualität führen
    → aufgabenbezogenen Kontext erstellen
    → erlaubten Client-/Modellweg prüfen
    → Consultant + Agent erstellen den Brief
    → Entwurf und Quellenbezug speichern
    → menschliche Einordnung festhalten
    → Quellenänderung erkennen
    → betroffene Ableitungen markieren/erneuern
    → nächsten Abruf auf aktuellem Stand ermöglichen
```

## Vertrauens- und Datengrenzen

1. **Beratung und deren Klienten unterscheiden.** Ein Tenant schützt die Beratung gegenüber anderen Consultry-Kunden. Innerhalb dieser Beratung begrenzen Klienten-, Projekt- und Rollenrechte die Nutzung weiter. Firmenmethoden können gesondert allgemein freigegeben sein.
2. **Autorisierung im Backend erzwingen.** Zugriff gilt für direkte IDs ebenso wie Suche, Graph-Traversierung, Kontextpakete, Artefakte und Exporte. Aus Agentenprompts entstehen keine Rechte.
3. **Abgeleitete Daten bleiben geschützt.** Embeddings, Zusammenfassungen, Relationen, Quellennamen und Metadaten können vertrauliche Inhalte offenlegen; sie benötigen ebenfalls einen erlaubten Verarbeitungspfad.
4. **Die Antwort an Codex ist selbst ein Ausgang.** Ein lokaler MCP-Server verhindert nicht, dass ein Client empfangene Inhalte an sein Modell übermittelt. Tool-Responses müssen für den tatsächlichen Empfänger freigegeben sein. Der serverinterne Model Gateway allein schützt diese Grenze nicht.
5. **Model Bridge prüft Zulässigkeit vor Optimierung.** Datenklasse, Zweck und erlaubter Empfänger begrenzen den Weg; Kosten-/Modellqualität werden nur innerhalb dieses Wegs optimiert. Keine stillen Provider- oder Regions-Fallbacks.
6. **Inhalte sind Daten, keine Anweisungen.** Ein importiertes Dokument darf weder Systemrechte noch Toolzulassung oder verbindliche Skill-/Policy-Definitionen ändern.
7. **Pseudonyme lösen das Rechteproblem nicht.** Auch ohne Namen können Verträge, IP, technische Zusammenhänge und Klientenbezug geschützt bleiben.

Konkrete Konsequenz für den Start: extern modellgestützte Client-Tests zunächst mit synthetischen oder für genau diesen Pfad freigegebenen Daten. Vertrauliche Originaldaten erst nach festgelegter und technisch geprüfter Verarbeitungskette. Das ist eine Startempfehlung aus den identifizierten Datenwegen, keine zusätzliche pauschale Genehmigung für reale Datenübertragung.

Die offizielle [Codex-MCP-Dokumentation](https://developers.openai.com/codex/mcp/) bestätigt MCP als Zugang zu Werkzeugen und Kontext. Daraus folgt keine Zusage über Consultrys konkrete Datenresidenz oder Zugriffsregeln. [MCP Security Best Practices](https://modelcontextprotocol.io/specification/2025-11-25/basic/security_best_practices) sind eine Implementierungsreferenz; tenant-/klientenspezifische Regeln müssen im Produkt nachgewiesen werden.

## Was „live Brain“ im ersten Proof bedeutet

| Verhalten | Nachweis |
|---|---|
| Quellenversionen erkennen | gleicher Import dupliziert nichts; geänderter Inhalt erhält einen neuen Stand |
| Beziehungen mit Herkunft führen | jede wesentliche abgeleitete Verbindung verweist auf ihre Grundlage; Konflikte sind darstellbar |
| Aktualisierung nachvollziehen | der gewählte Delta-/Wiederimport aktualisiert betroffene Ableitungen innerhalb eines vorher festgelegten Testfensters |
| Veraltete Ergebnisse behandeln | abhängiger Brief erhält einen erklärbaren Hinweis; ältere menschliche Entscheidung wird nicht rückwirkend umgeschrieben |
| Rechteänderung behandeln | bei gesperrter/entfernter Quelle wird künftiger Abruf auch aus Ableitungen und Caches entsprechend eingeschränkt |
| Kontext in neuer Session nutzen | aktueller Stand kommt aus dem Backend, nicht aus einem alten Chattranskript |

„Live“ wird für den Proof durch einen messbaren Änderungsfall definiert. Eine universelle Echtzeit- oder „niemals veraltet“-Garantie wird nicht unterstellt. Bereits erlaubte, an einen externen Client ausgelieferte Inhalte lassen sich nicht durch spätere Backend-Sperrung aus dessen Erinnerung zurückholen; diese Grenze gehört in den Datenvertrag.

## Dünner Core statt vollständigem Framework

Für den Beispielkandidaten wären unter anderem diese Begriffe zu prüfen: Beratung/Mandant, Klient/Projekt, Identität/Zugriffsbezug, Quelle/Version, Aussage/Beziehung, Arbeitsauftrag, Run, Artefaktversion und menschliche Einordnung. Das ist keine abgeschlossene Entity-Liste; eine konkrete Datenstruktur wird erst aus dem gewählten Fall abgeleitet.

Ein versionierter Consulting-Skill definiert Ziel, erlaubten Kontext, Tools, Ergebnis und Stop-/Recovery-Verhalten. Eine vorhandene Runtime kann diese Arbeit ausführen. Consultry besitzt seine fachlichen Daten und durchgesetzten Grenzen. Ein umfangreiches eigenes Agent Framework ist dafür nicht erforderlich.

Knowledge-/Skill-/Execution-/Validation-Graph bleiben semantisch getrennt. Für den ersten Proof kann Execution eine kleine nachvollziehbare Run-Spur und Validation ein kompakter Kriteriensatz sein. Die Wahl zwischen relationaler Modellierung, Graph Store oder kombiniertem Retrieval muss sich an Abfragen, Aktualisierung, Zugriff und Betrieb bewähren. GraphRAG ist ein Vergleichs-/Forschungskandidat; seine [Dokumentation](https://microsoft.github.io/graphrag/) beschreibt einen Ansatz, keine bewiesene Passung zum Consultry-Kern.

## Mögliche Reihenfolge, falls dieser Arbeitsfall gewählt wird

| Schritt | Ergebnis | Abhängigkeit |
|---|---|---|
| 1. Testfall und Grenzen fixieren | ein Beratungsfall, erlaubte Daten-/Client-Wege, Akzeptanzfälle | Arbeitsfall gemeinsam ausgewählt |
| 2. Persistenter Quellenkern | Import, Versionen, IDs, Identität und Rechte | 1 |
| 3. Wissensbeziehungen und Aktualisierung | nachvollziehbare Ableitungen, Delta, Konflikt/Veraltet-Status | 2 |
| 4. Dünne Client-Anbindung | scoped Kontext lesen und Entwurf schreiben, etwa über MCP | 2; Vertrag kann parallel zu 3 entwickelt werden |
| 5. Consulting-Skill und Ergebnis | Brief, Quellenbezug, menschliche Einordnung, Neustartfähigkeit | 3 + 4 |
| 6. Nachweis im Betrieb | Tests, Quellenänderung, Review durch Consultant, Vergleich zur einfachen Suche | 5 |

Parallel sinnvoll: synthetisches Testkorpus und Erwartungswerte; Security-/Autorisierungsfälle; später Adapter gegen Fake-Kern. Gemeinsame Domain-/Schnittstellenverträge zuerst klein abstimmen. Kein neues riesiges WBS oder universelles Datenmodell vor dem ersten vertikalen Ergebnis.

## Akzeptanzprüfungen

**Deterministisch zu prüfen:**

- idempotenter Import, neue Version bei Änderung, nachvollziehbare Wiederholung;
- Zugriffstrennung zwischen Beratungen, Klienten und Berechtigungsprofilen, einschließlich direkter Objekt-IDs;
- Quellenrechte und Egress-Regeln gelten auch für Tool-Responses, Caches, Logs, Embeddings und Fallbacks;
- injizierte Dokumentanweisungen verändern keine Rechte oder zulässigen Tools;
- exakte Quellenversionen am Kontext und Ergebnis;
- Invalidierung/Neuableitung für den gewählten Änderungsfall und spätere Rechteänderung;
- persistenter Zustand nach Client-Neustart;
- keine doppelte fachliche Wirkung bei Retry/Abbruch;
- gespeicherte Agentenableitung wird nicht automatisch menschliche Entscheidung oder freigegebene Firmenregel.

**Fachlich zu prüfen:**

- relevante Informationen und echte Lücken im Brief;
- Eignung und Grenzen wiederverwendeter Methoden/Referenzen;
- Aufwand des Consultants für Prüfung und Nacharbeit;
- Nutzen gegenüber einer einfachen Datei-/Vektorsuche mit identischem Korpus und Modell;
- Agentenabbruch/Einholen von Input bei fehlender Grundlage.

Unit- und Mock-Integrationstests prüfen Verträge und Fehlerfälle. Ein echter Integrationstest prüft die vollständige Kette mit Testdaten. Die im bisherigen Handover gewünschte Mutation-Prüfung pro PR wird für geänderte Core-Logik übernommen, insbesondere Autorisierung, Versionierung, Invalidierung und Effekt-Idempotenz. Bei reinen Dokumentationsänderungen ist kein künstlicher Mutation-Lauf nötig. Testabdeckung ist kein Nachweis fachlicher Ergebnisqualität.

## Prüffragen für die spätere Auswahl — kein neuer Pflicht-Grill

| Entscheidung | Empfehlung | Warum jetzt relevant |
|---|---|---|
| **Daten- und Client-Grenze** | erster Codex-/MCP-Test mit freigegebenen/synthetischen Inhalten; realen Kundenpfad separat genau beschreiben | bestimmt, was das Backend an den Client ausgeben darf |
| **Erster Job und Quelle** | interner Bestandskunden-/Projektbrief; zunächst kontrollierter Dateiimport, alternativ konkrete SharePoint-Quelle bei Pilotbedarf | hält die Implementierung klein und consultancy-spezifisch |
| **Automatische Arbeit und verantwortete Wirkung** | Import, quellengebundene Ableitung, Draft und Aktualisierung automatisch; Qualifizierung/Freigabe und externe Wirkung getrennt | vermeidet sowohl Genehmigungsüberlast als auch unkontrollierte Geschäftsaktionen |
| **Nachweis des lebenden Wissens** | eine Quelle und eine Berechtigung ändern; betroffene Kontexte/Artefakte nachvollziehbar aktualisieren; Nutzen gegen einfache Suche messen | entscheidet, ob der Brain-/Graph-Ansatz tatsächlich Mehrwert liefert |

Managed In-Tenant kann als eine im August explorierte Betriebsoption geprüft werden. Cloudanbieter, Betreiberrechte, Region, Schlüssel, Support, Retention und Client-Modellweg sind nicht gewählt. Historische Modellnamen, Hardwarepreise und AWS-/Hermes-Entwürfe entscheiden dies nicht.

## Was den Start nicht blockiert

Vollständige App-IA, alle Screens, ein allgemeiner Agent-Harness-Baukasten, umfassende Graph-Ontologie, mehrere Modellanbieter, automatisches Modelltraining, HR-/Billing-Komplettmodule, Marketplace, vollständige sechs Journey-Familien und das alte Three-Slice-Handoff. Die jeweiligen Produktziele und Quellen bleiben auffindbar.
