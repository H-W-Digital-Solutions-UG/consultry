/* Consultry Click Dummy — geteilter Zustand und Ereignis-Ledger.
   Lebt in sessionStorage, damit Navigation zwischen den Seiten Gedächtnis hat. */
(function () {
  if (window.CW) return;   // Doppelauswertung: bestehende Instanz und ihre Abos behalten
  var KEY = "consultry.demo.v4";   // v4: Namen vereinheitlicht, alte Sitzungen verfallen

  function seed() {
    return {
      org: "boutique",
      // Meine Arbeit: offene Aufmerksamkeit
      queue: {
        "hinweis-w1": { open: true },
        "kritis-los2": { open: true },
        "artefakt-v8": { open: true }
      },
      // Fall B: Widerspruch Abstimmbericht v3 gegen Go-Aussage in v7
      hinweis: {
        id: "HMA-342",
        state: "offen",          // offen | geprueft | widerlegt | bedingt
        disposition: null,        // widerlegt | bedingt | zurueckgestellt
        rationale: "",
        scopeOut: []              // abgewählte Quellen
      },
      // Fall C: Artefakt Entscheidungsgrundlage
      artefakt: {
        id: "HMA-347",
        version: "v7",
        successor: null,          // "v8 Entwurf" nach Übernahme
        draft: "",
        dirty: false,
        claim: "bedingt",         // belegt | bedingt | nicht pruefbar | nicht beobachtbar
        review: "offen"           // offen | in Pruefung | freigegeben
      },
      // Fall A: KRITIS Ausschreibung Los 2
      kritis: {
        id: "KRT-014",
        decision: null,           // bid | no-bid | hold
        answers: {},              // Frage-ID -> Antwort
        planAccepted: [],         // akzeptierte Planschritte
        planEdits: {}             // Planschritt -> menschlicher Text
      },
      // Wirkungen: was nach einer autorisierten Aktion tatsächlich passiert ist
      effects: [],                // {id,label,scope,state,at}
      events: []                  // Ledger: {t,type,text,obj}
    };
  }

  var state = null;
  var subs = [];

  function load() {
    if (state) return state;
    try {
      var raw = sessionStorage.getItem(KEY);
      state = raw ? JSON.parse(raw) : seed();
    } catch (e) { state = seed(); }
    return state;
  }

  function save() {
    try { sessionStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {}
    for (var i = 0; i < subs.length; i++) subs[i](state);
  }

  function stamp() {
    var d = new Date();
    var p = function (n) { return n < 10 ? "0" + n : "" + n; };
    return p(d.getHours()) + ":" + p(d.getMinutes());
  }

  var CW = {
    get: function () { return load(); },

    patch: function (fn) { fn(load()); save(); return state; },

    /* Ereignis ins Ledger schreiben. type: quelle | kandidat | mensch | wirkung */
    event: function (type, text, obj) {
      load();
      state.events.unshift({ t: stamp(), type: type, text: text, obj: obj || null });
      if (state.events.length > 40) state.events.length = 40;
      save();
    },

    /* Wirkung anlegen. Startet als offen, wird über settle() zu erfolgt oder fehlgeschlagen. */
    effect: function (id, label, scope) {
      load();
      state.effects = state.effects.filter(function (e) { return e.id !== id; });
      state.effects.unshift({ id: id, label: label, scope: scope || "", state: "offen", at: stamp() });
      save();
      return id;
    },

    settle: function (id, result) {
      load();
      for (var i = 0; i < state.effects.length; i++) {
        if (state.effects[i].id === id) { state.effects[i].state = result; state.effects[i].at = stamp(); }
      }
      save();
    },

    close: function (key) {
      load();
      if (state.queue[key]) { state.queue[key].open = false; save(); }
    },

    counts: function () {
      var s = load();
      var open = 0;
      for (var k in s.queue) if (s.queue[k].open) open++;
      return {
        arbeit: open,
        kunden: 6,
        projekte: 8,
        wissen: 10,
        menschen: 0,
        commercials: 10,
        operations: s.effects.filter(function (e) { return e.state !== "erfolgt"; }).length + 2
      };
    },

    sub: function (fn) { subs.push(fn); return function () { subs = subs.filter(function (f) { return f !== fn; }); }; },

    reset: function () { state = seed(); save(); }
  };

  /* Logikklassen rufen CW.ready(cb) auf, weil Helmet-Skripte asynchron mounten. */
  CW.ready = function (cb) { cb(CW); };

  window.CW = CW;
})();
