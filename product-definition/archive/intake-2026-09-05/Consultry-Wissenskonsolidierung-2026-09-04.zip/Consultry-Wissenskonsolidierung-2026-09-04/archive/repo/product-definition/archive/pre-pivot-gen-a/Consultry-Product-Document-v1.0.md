# Consultry — Product Document v1.0

> **⚠️ SUPERSEDED ALS PRODUKT-SOURCE-OF-TRUTH (Stand 13.06.2026).** Dieses Dokument (12.04.2026) ist die **älteste Voll-OS-Rahmung** und widerspricht dem MVP an vielen Stellen (Modul-Set, Scope, ICP). **Nicht** als aktuelle Produktwahrheit lesen. Verbindlich: [MVP-Foundation-Decisions](../../latest/Consultry-MVP-Foundation-Decisions-v1.0.md) + [MVP-PRD](../superseded-product-baseline-2026-08/Consultry-MVP-PRD-v1.0.md). **Rolle heute:** historische/H3-Vision-Referenz.

## AI-native Operating System für DACH IT- und Digitalisierungsberatungen

**Status:** ⚠️ Superseded (historische Vision-Referenz) — Working Draft  
**Datum:** 12. April 2026  
**Produkt:** Consultry  
**Ersetzt nicht:** bestehende PRD-Artefakte; dieses Dokument ist ein neuer, schärferer Produkt-Source-of-Truth  
**Basis:** interne PRD-/Refinement-Dokumente plus verifizierte Markt-, Rechts- und Produktquellen

---

## 1. Kurzfassung

Consultry ist kein allgemeines CRM und kein weiteres PSA-Tool.

Consultry ist ein **AI-native Operating System für DACH IT- und Digitalisierungsberatungen**, das fünf bisher getrennte Steuerungsbereiche in einem System zusammenführt:

- Account-Wachstum im Bestand
- Berater- und Kapazitätssteuerung
- wiederverwendbares Beratungswissen und Delivery-Artefakte
- Angebots- und Vertragssteuerung
- Delivery- und Commercial Control

Das Ziel ist nicht, jede Beratungsfunktion gleichzeitig zu digitalisieren.  
Das Ziel ist, die zentrale operative Frage einer Beratung zuverlässig zu beantworten:

`Welches Folgegeschäft ist bei welchem Kunden gerade realistisch, welches Team kann es belastbar liefern, zu welchen kommerziellen Bedingungen, und wie steuern wir das Projekt danach sauber weiter?`

---

## 2. Harte Positionierung

### Produktdefinition in einem Satz

`Consultry ist das AI-native Operating System für DACH IT- und Digitalisierungsberatungen, das Bestandskunden-Chancen, Beraterfähigkeit, Wissen, Angebot, Vertrag, Allocation und kommerzielle Steuerung in einem erklärbaren System verbindet.`

### Was Consultry nicht ist

- kein generisches CRM für beliebige Vertriebsorganisationen
- kein vollwertiges ERP
- kein Payroll-System
- kein generisches Task-Management-Tool
- kein autonomer Rechtsberater
- kein Event-Tool als Primärprodukt

### Warum diese Schärfung notwendig ist

Der Markt ist bereits mit Einzellösungen besetzt:

- CRM und Admin-Suiten wie [Teamleader](https://www.teamleader.eu/), [Scopevisio](https://www.scopevisio.com/en-gb/) oder [MOCO](https://www.mocoapp.com/)
- PSA-/Resource-Management-Suiten wie [Kantata](https://www.kantata.com/psa), [Productive](https://productive.io/), [Scoro](https://www.scoro.com/features/quoting-budgeting/)
- Lead-/Signal-Anbieter wie [Dealfront](https://www.dealfront.com/)

Die realistische Differenzierung liegt nicht in „mehr Features“, sondern in der Verbindung von:

`Bestandskunden-Kontext -> Berater-/Kapazitätslogik -> Proposal/Contract -> Allocation/Delivery -> Commercial Control`

---

## 3. Marktthese und Evidenz

Die folgenden Thesen sind die Grundlage des Produkts.  
Sie sind nicht Marketing-Slogans, sondern die verdichtete Evidenzlage.

### 3.1 Bestandskunden sind im DACH-Consulting der stärkere Wachstumshebel als generisches Net-New

Für deutsche Beratungen stammen laut BDU rund 80 % des Umsatzes aus Bestandskunden; Empfehlungen dominieren die Neukundengewinnung deutlich.  
Das bedeutet: Für den Start ist **Account Expansion** wichtiger als breit angelegtes Prospecting.  
Quellen: [BDU Bestandskunden](https://www.bdu.de/news/consultants-erzielen-80-des-umsatzes-mit-bestandskunden/), [BDU Consultingmarkt 2026](https://www.bdu.de/studien/consulting/)

### 3.2 Wissen ist kein Wiki-Problem, sondern ein Umsatz-, Delivery- und Build-Problem

Beratungswissen geht mit Personen, Projekten und lokalen Dateien verloren. Gleichzeitig wird KI im Consulting heute bereits besonders stark für Wissensmanagement, Recherche und Angebotsarbeit eingesetzt.  
Für IT- und Tech-nahe Beratungen besteht dieses Wissen nicht nur aus Folien und Texten, sondern auch aus Reports, Analyse-Setups, Skripten, kleinen Tools, Runbooks, Repository-Templates sowie kundenähnlichen Demo-/Test-Umgebungen für Vorbereitung, QA und Troubleshooting.  
Quellen: [BDU KI im Consulting](https://www.bdu.de/news/ki-in-consultingunternehmen-schwerpunkt-auf-kundenprojekten/), [CONSULTING.de Know-how bewahren](https://www.consulting.de/artikel/wie-knowhow-im-unternehmen-bewahrt-werden-kann-und-warum/)

### 3.3 Auslastung, Forecasting, Pricing und Akquisekosten sind Kernökonomie

BDU-KPIs zeigen: Profitabilität, Auslastung, Overhead, Vertriebsaufwand und Akquisekosten sind keine Backoffice-Größen, sondern Steuerungsgrößen der Beratung.  
Quellen: [BDU KPI-Studie](https://www.bdu.de/studien/kpi/), [BDU Honorare](https://www.bdu.de/studien/honorare/)

### 3.4 Preis- und Vertragsdruck steigen

Im Markt gibt es Preisdruck, heterogene Vertragsmodelle und uneinheitliche Behandlung von Reise- und Nebenkosten. Damit werden Angebotslogik, Vertragslogik und Billing Prep zum Kern des Betriebsmodells.  
Quellen: [BDU Honorare 2025](https://www.bdu.de/news/studie-honorare-im-consulting-2025-tagessaetze-leicht-ruecklaeufig/), [CONSULTING.de Tooling im Consulting](https://www.consulting.de/artikel/2in1-consulting-trifft-tool/)

### 3.5 Fachkräftemangel und Skill-Verschiebungen bleiben strukturell

Der IT-Fachkräftemangel bleibt hoch; zugleich verschieben sich Skill-Nachfragen durch Cloud, Automatisierung und AI. Daraus folgen Recruiting-Druck, Onboarding-Bedarf und interne Skill-Entwicklung.  
Quellen: [Bitkom IT-Fachkräfte 2025](https://www.bitkom.org/Presse/Presseinformation/Deutschland-fehlen-IT-Fachkraefte), [BDU Consultingmarkt 2026](https://www.bdu.de/studien/consulting/)

### 3.6 DACH-Compliance ist Produktlogik, nicht nur Legal-Appendix

People Analytics, Mitarbeiterprofiling, AI-gestützte Planung, Vertragsunterstützung, Ausschreibungen, Zeit-/Spesenbezug und Rechnungslogik berühren in DACH unmittelbar Rechts- und Mitbestimmungsthemen.  
Quellen: [AI Act](https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX%3A32024R1689), [GDPR](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng), [BetrVG §87](https://www.gesetze-im-internet.de/betrvg/__87.html), [BetrVG §94](https://www.gesetze-im-internet.de/betrvg/__94.html), [BDSG §26](https://www.gesetze-im-internet.de/bdsg_2018/__26.html)

---

## 4. Zielkunde und Marktstart

### Primärer ICP

**DACH IT- und Digitalisierungsberatungen mit ca. 30 bis 200 Beratern**

Warum genau dieses Segment:

- genug Prozesskomplexität für echten Schmerz
- genug wirtschaftlicher Hebel für Budget
- noch nicht so viel Enterprise-Schwere wie bei sehr großen Beratungen
- typischerweise heterogene Tool-Landschaft und hohe Excel-/E-Mail-Abhängigkeit

### Typische Subsegmente

- IT-Transformationsberatungen
- Cloud- und Plattformberatungen
- SAP- und ERP-Beratungen
- Data/AI/Automation-Beratungen
- Digital-Operations- und Prozessberatungen

### Sekundäre Segmente

- Public-Sector-nahe Beratungen mit relevantem Ausschreibungsgeschäft
- kleinere Boutique-Beratungen mit hohem Angebots- und Staffing-Druck

### Nicht primär zum Start

- sehr kleine Einzelfirmen mit wenig Strukturbedarf
- sehr große globale Beratungen mit schwerem Multi-Entity- und Governance-Overhead
- Kanzleien und fachfremde Professional Services ohne IT-/Transformationsschwerpunkt

---

## 5. Wirtschaftlicher Käufer und operative Nutzer

### Wirtschaftliche Käufer

- **Managing Partner / Geschäftsführung**
- **COO / Operations / Controlling / Finance**

Diese Rollen kaufen nicht wegen „AI“, sondern wegen:

- besserer Auslastung
- belastbarerem Forecast
- schnelleren, besseren Angeboten
- saubererem Contracting und Billing Prep
- weniger Wissensverlust

### Funktionale Sponsoren

- Practice Leads
- Service-Line Leads
- BD-/Account-Leads

### Tägliche Hauptnutzer

- BD / Account Management
- Practice Leads
- Projekt- und Engagement-Leads
- Senior Consultants
- PMO / Backoffice / Finance

### Sekundäre Nutzer

- Consultants im Profil- und Knowledge-Kontext
- HR/Talent bei Recruiting-/Skill-Themen
- Kunden im späteren Portal-/Feedback-Kontext

---

## 6. Kernprobleme, die Consultry lösen soll

### 6.1 Demand bleibt im Bestand untergenutzt

Beratungen sehen oft zu spät:

- welche Trigger bei Bestandskunden entstehen
- welche White-Space-Chancen offen sind
- welche Warm Paths wirklich belastbar sind

### 6.2 Beraterfähigkeit ist nicht sauber strukturiert

Skills, Zertifikate, Projekterfahrung, Availability und Leadership liegen verstreut in CVs, Dokumenten, Kalendern und Köpfen.

### 6.3 Wissen wird nicht systematisch wiederverwendet

Angebote, Ausschreibungen, Projektvorbereitung und Onboarding starten zu oft fast von vorn.

### 6.4 AI-native Arbeitsweisen sind nicht operationalisiert

Selbst techniknahe Beratungen haben selten eine saubere Verwaltung von wiederverwendbaren AI-Skills, Workflow-Rezepten, Prompt-/Canvas-Blueprints und persönlichen Arbeitsmustern. Vieles bleibt in Einzelchats, privaten Notizen oder lokalen Setups hängen.

### 6.5 Angebots- und Vertragsarbeit ist zu langsam und zu personenabhängig

Die Brücke von Kundenkontext zu Team, Proposal, Pricing und Contract ist oft manuell, inkonsistent und schlecht nachvollziehbar.

### 6.6 Allocation und Delivery werden zu spät korrigiert

Konflikte, Leerstände, Doppelbelegungen, Scope-Risiken und kommerzielle Abweichungen werden oft erst erkannt, wenn Marge oder Vertrauen schon gelitten haben.

### 6.7 Commercial Control ist operativ zu schwach angebunden

Zeit, Spesen, Fremdleistungen, Vertragsbezug, Rebilling und Invoice Prep hängen oft an separaten Tools und Medienbrüchen.

---

## 7. Produktprinzipien

### 7.1 Erklärbar statt Black Box

Jede AI-Empfehlung in:

- Staffing
- Forecasting
- Allocation
- Skill-Entwicklung
- Angebots- und Vertragsarbeit

muss standardmäßig nachvollziehbar sein.

Default:

- Empfehlung
- Begründung

### 7.2 Skills als steuerbare Arbeitsbausteine

Consultry sollte `Skill` nicht nur als Beraterqualifikation verstehen, sondern auch als wiederverwendbare AI-native Arbeitsfähigkeit.

Dazu gehören zum Beispiel:

- Proposal-Prep-Skills
- Discovery-/Research-Skills
- Workshop-Prep-Skills
- Troubleshooting-/Runbook-Skills
- Delivery-/QA-Skills
- kunden- oder themenspezifische Workflow-Blueprints

Diese Skills dürfen nicht als unkontrollierter Prompt-Zoo enden.  
Sie müssen versionierbar, zuordenbar, wiederverwendbar und mit Kontext, Artefakten und Verantwortlichen verknüpft sein.

Default:

- menschliche Freigabe
- Audit Trail

### 7.3 Project-Level statt Task-Engine

Consultry plant und steuert auf:

- Projekt-Ebene
- optional Workstream-Ebene
- Zeitanteilen
- Milestones

Nicht auf atomarer Task-Ebene als generisches Work-Management-System.

### 7.4 Bestandskundenausbau vor generischem Prospecting

Das Startprodukt optimiert zuerst:

- Bestandskunden
- Folgeprojekte
- Cross-Sell
- Trigger
- Warm Paths

Net-New-Discovery bleibt wichtig, ist aber nicht das primäre Kernnarrativ.

### 7.5 Commercial Control statt ERP

Consultry steuert kommerzielle Relevanz, ersetzt aber nicht:

- Buchhaltung
- Steuerlogik
- Payroll

DATEV und ELSTER bleiben Endsysteme für steuer- und buchhaltungsrelevante Verarbeitung.

### 7.6 Native + integrierte Daten, aber mit klarer Führungslogik

Consultry darf bestimmte Daten nativ führen, andere integrieren, aber nie ohne klare Regeln.

Es muss explizit festgelegt werden:

- welche Quelle primär ist
- was Vorschlag ist
- was verbindlicher Datensatz ist
- was abrechnungsrelevant ist

---

## 8. Langfristiges Zielbild

Die langfristige Ambition bleibt:

`AI-native Operating System für DACH IT- und Digitalisierungsberatungen`

Für **pre-product** ist dieses Zielbild aber zu breit.  
Es beschreibt die Firma, die ihr bauen wollt, noch besser als das erste Produkt, das ein Kunde kurzfristig kauft.

Darum wird das Zielbild für den aktuellen Stand in zwei Ebenen getrennt:

- **Langfristige Plattformthese**: Consultry verbindet Account-Wachstum, Beraterfähigkeit, Wissen, Angebot, Vertrag, Delivery und kommerzielle Steuerung.
- **Kaufbarer Einstieg**: Consultry löst zuerst einen klaren Hochwert-Workflow, statt sofort das gesamte Operating System zu bauen.

---

## 9. Kaufbare Einstiegsthesen

Es gibt nicht nur einen sinnvollen Einstieg.  
Es gibt mehrere **kaufbare Wedge-Kandidaten**, die ihr berücksichtigen solltet.

Die Wedge-Frage ist deshalb nicht:

- `Welcher Bereich ist interessant?`

sondern:

- `Welcher Einstieg ist zuerst kaufbar, testbar und datenrealistisch?`

---

## 10. Wedge-Landschaft

### 10.1 Bestandskunden-Expansion & Proposal

`Bestandskunde -> Signal/Trigger -> qualifizierte Opportunity -> Teamvorschlag -> Proposal/CVs -> Pricing/Contract-Draft -> Send-Ready`

Warum stark:

- nah am Umsatz
- klarer externer Kaufgrund
- passt zur DACH-Marktrealität von Bestandskunden, Empfehlungen und Angebotsdruck

Typischer Output:

- qualifizierte Opportunity
- Teamvorschlag
- Proposal-Draft
- CV-Paket
- Pricing-/Commercial-Draft

### 10.2 Wissenstransfer, Reuse & Readiness

`Projektwissen + Delivery-Artefakte + wiederverwendbare Repositories -> verdichtete Referenzen/Methoden/Learnings/Blueprints -> schnellere Proposal-, Onboarding- und Projektvorbereitung`

Warum stark:

- realer Schmerz im Beratungsalltag mit wenig Zeit für saubere Dokumentation
- hoher Hebel auf Proposal-Qualität, Onboarding und Projektvorbereitung
- gute AI-Fit-Zone für Capture, Verdichtung, Wiederverwendung und Quellenbindung

Warum als Verstärker-Wedge interessant:

- macht vorhandene Erfahrung schneller nutzbar, statt nur neues Wissen zu sammeln
- erhöht die Qualität des Primär-Wedges direkt über bessere Referenzen, CVs und Methodenbausteine
- kann in 30 bis 90 Tagen mit echten Projekten und realen Wissensartefakten sichtbar getestet werden

Typischer Output:

- wiederverwendbare Referenzbausteine
- auffindbare Methodenbausteine
- projektbezogene Learnings
- Onboarding Foundations
- wiederverwendbare AI-Skills und Workflow-Rezepte für typische Beratungsarbeit
- wiederverwendbare Reports, Skripte und kleine Tool-Bausteine
- wiederverwendbare Repository-Templates und Starter-Kits
- Runbooks und Troubleshooting-Patterns
- kundennahe Demo-/Test-Blueprints für interne Validierung ohne Eingriff in Kunden-Produktionsumgebungen
- bessere CV-/Proposal-Readiness

Was diesen Wedge kaufbar macht:

- kürzere Proposal-Vorbereitung
- schnelleres Onboarding in Themen, Kunden und Projektkontexte
- weniger Wissensverlust bei Projektwechseln und Abgängen
- weniger Wiederholung in typischen Consultant-Workflows durch wiederverwendbare AI-Skills statt Einzelchats
- schnellere Demo-, QA- und Troubleshooting-Vorbereitung mit wiederverwendbaren Assets statt Neuanfang pro Projekt
- schnelleres Aufsetzen von PoCs, Demos und internen Testumgebungen über vorhandene Starter-Repositories und Blueprints

Was ihn noch nicht zum besten Primär-Wedge macht:

- klingt isoliert schnell nach Wiki oder Knowledge Management
- verkauft sich stärker, wenn er direkt mit Proposal, Projektvorbereitung und Staffing-Readiness verbunden wird

### 10.3 Intelligentes Staffing, Matching & Forecasting

`Pipeline + Kundenkontext + Beraterprofil + Skill + Zertifikate + Projekterfahrung + Availability + persönliche Arbeits- und Delivery-Präferenzen -> belastbarerer Team- und Forecast-Vorschlag`

Warum stark:

- sehr nah am realen Beratungsbetrieb
- verbessert Staffing, Matching und Angebotsglaubwürdigkeit
- hilft, Überlastung, Leerlauf und Skill-Lücken früher sichtbar zu machen
- gut mit Proposal-Wedge kombinierbar

Warum als Verstärker-Wedge interessant:

- beantwortet eine der härtesten internen Fragen jeder Beratung: `Können wir das glaubwürdig liefern?`
- stärkt den Primär-Wedge direkt über belastbarere Teamvorschläge
- gibt Practice Leads und Sales ein gemeinsames Bild auf Verfügbarkeit, Eignung und Risiko

Typischer Output:

- belastbarere Teamvorschläge
- plausiblere Matching-Alternativen
- sichtbarere Forecast-, Skill- und Kapazitätslücken
- bessere Zuordnung von passenden AI-Skills und Workflow-Blueprints zu Beratern, Teams und Projektsituationen
- bessere Zuordnung von Delivery-Artefakten, Topic Ownership und passenden Repository-/Tool-Bausteinen
- schnelleres internes Staffing

Was diesen Wedge kaufbar macht:

- weniger manuelles Suchen nach passenden Beratern
- höhere Sicherheit vor Angebotsabgabe
- frühere Sichtbarkeit von Bench-, Überlastungs- und Skill-Risiken
- bessere Passung zwischen Kundenkontext, Beraterskill, Arbeitsweise und verfügbaren Build-/Delivery-Artefakten

Was ihn noch nicht zum besten Primär-Wedge macht:

- braucht bessere Datenqualität als der Primär-Wedge
- ist im DACH-Kontext governance- und compliance-sensibler
- kann schnell nach internem Ressourcenmanagement statt nach externem Geschäftswert klingen
- darf nicht in verstecktes Mitarbeiter-Scoring oder Verhaltensüberwachung kippen

### 10.4 Commercial Readiness Light

`Angebot/Vertrag/Leistungslogik -> kommerziell plausibler Draft für interne Weiterbearbeitung`

Warum stark:

- echter wirtschaftlicher Schmerz
- hilft bei Pricing, Vertragsfit und Angebotsglaubwürdigkeit

Warum noch nicht als alleiniger Primärwedge ideal:

- zieht schnell in Finance-/ERP-/Steuer-Komplexität

### 10.5 Tender-Readiness für ausgewählte Segmente

`Ausschreibung/vergabenahe Chance -> qualifizierte Bewertung -> wiederverwendbare Antwortbausteine`

Warum relevant:

- für Public-Sector-nahe oder vergabelastige Beratungen real

Warum nicht universell:

- segmentabhängig
- nicht für den gesamten ICP gleich stark

---

## 11. Empfohlene Priorisierung

Alle Wedges sollen **mitgedacht** werden.  
Aber sie sollten nicht alle gleichzeitig die primäre Go-to-Market-Story sein.

### Primärer Wedge

**Bestandskunden-Expansion & Proposal**

Das ist der stärkste erste Kaufgrund.

### Verstärker-Wedges

- **Wissenstransfer, Reuse & Readiness**
- **Intelligentes Staffing, Matching & Forecasting**

Diese beiden stärken den primären Wedge direkt. Sie sind nicht bloß Enabler, sondern eigenständige, testbare Problemgeschichten mit starkem Verstärker-Effekt auf Proposal und Delivery-Confidence.

### Spätere Ausbau-Wedges

- **Commercial Readiness Light** in größerer Tiefe
- **Tender-Readiness** für passende Segmente

### Entscheidungsraster für die Wedges

| Wedge | Schmerz | Kaufnähe | Datenverfügbarkeit | Demo-Fähigkeit | Compliance-Risiko | Time-to-Value | Vorläufiges Urteil |
|---|---|---|---|---|---|---|---|
| **Bestandskunden-Expansion & Proposal** | hoch | hoch | mittel | hoch | mittel | hoch | **primärer Wedge** |
| **Wissenstransfer, Reuse & Readiness** | hoch | mittel | mittel bis hoch | mittel | niedrig bis mittel | mittel bis hoch | **starker Verstärker-Wedge** |
| **Intelligentes Staffing, Matching & Forecasting** | hoch | mittel | mittel | mittel | mittel bis hoch | mittel | **starker Verstärker-Wedge mit höherem Risiko** |
| **Commercial Readiness Light** | hoch | mittel bis hoch | mittel | mittel | mittel | mittel | **späterer Ausbau, selektiv testbar** |
| **Tender-Readiness** | segmentabhängig hoch | segmentabhängig mittel bis hoch | mittel | mittel | mittel | mittel | **nur für passende Segmente** |

**Wie die Matrix zu lesen ist**

- `Schmerz` bewertet, wie real und häufig das Problem im Alltag der Zielberatungen ist
- `Kaufnähe` bewertet, wie direkt sich daraus Budget und Sponsoring ableiten lassen
- `Datenverfügbarkeit` bewertet, ob typische Beratungen die nötigen Daten real vorliegen haben
- `Demo-Fähigkeit` bewertet, wie gut der Wedge mit realen oder pilotfähigen Daten gezeigt werden kann
- `Compliance-Risiko` bewertet People-, Contract-, Tender- oder Finance-nahe Reibung im DACH-Kontext
- `Time-to-Value` bewertet, wie schnell ein Design Partner nach Start einen Vorher/Nachher-Effekt sehen kann

**Vorläufige Schlussfolgerung**

- `Bestandskunden-Expansion & Proposal` gewinnt, weil es die beste Kombination aus Kaufnähe, Demo-Fähigkeit und Time-to-Value hat.
- `Wissenstransfer, Reuse & Readiness` ist kein Nebenthema, sondern ein echter Verstärker für Proposal, Onboarding und Projektvorbereitung.
- `Intelligentes Staffing, Matching & Forecasting` ist stark, aber daten- und governance-intensiver.
- Beide Verstärker-Wedges sollten als direkte Verstärkung des Primär-Wedges gestaltet werden, nicht als separate Backoffice-Suiten.
- `Commercial Readiness Light` bleibt wertvoll, sollte aber den Erstverkauf nicht in Finance-/ERP-Komplexität ziehen.
- `Tender-Readiness` sollte bewusst als vertikaler Wedge behandelt werden, nicht als universeller Einstieg.

---

## 12. Was die Wedges gemeinsam brauchen

Die Wedges sind verschieden, teilen aber wenige gemeinsame Enabler:

- Bestandskundenkontext
- strukturierte Beraterprofile
- gepflegte Skill-, Zertifikats- und Arbeitsprofil-Daten statt nur CV-Freifeld
- auffindbares und wiederverwendbares Wissen
- verwaltete AI-Skills, Workflow-Rezepte und Canvas-/Prompt-Blueprints für wiederkehrende Consultant-Prozesse
- wiederverwendbare Delivery-Artefakte wie Reports, Skripte, kleine Tools und Runbooks
- Repository-Anbindung für GitHub/GitLab als Quelle und Ziel für wiederverwendbare technische Assets
- Teamvorschläge mit nachvollziehbarer Begründung
- Proposal-/CV-Drafting
- sichere, vom Kunden-Produktivsystem getrennte Demo-/Test-Setups für Validierung und Troubleshooting
- leichte Commercial-/Contract-Readiness
- assistive, nicht überautomatisierte Folgeaktionen

Diese Enabler sind wichtig.  
Sie sind aber **Unterstützung für die Wedges**, nicht schon das volle Produktziel.

---

## 13. Was bewusst noch nicht der Produktkern ist

- Vollständige Delivery-Steuerung
- vollständige Commercial-Control-Tiefe
- Finance-Ops-Design in voller Breite
- tiefes Allocation-Operating-Model
- breite Integrationstiefe
- vollwertige DevOps-/Platform-Engineering-Suite für beliebige Kundenumgebungen
- generisches Git-Hosting oder vollständiger Ersatz für GitHub/GitLab
- offener Prompt-Marktplatz ohne Governance und Qualitätslogik
- AT/CH-Sonderlogik
- Event-/Messe-Betrieb
- Public-Tender-Vollabdeckung
- generisches Net-New-Prospecting
- People-Scoring oder Persönlichkeitslogik

Diese Themen können später relevant sein.  
Sie dürfen aber gerade nicht den ersten Kaufgrund verwässern.

---

## 14. Was wir vorerst nicht weiter ausdetaillieren

Für pre-product werden bewusst zurückgestellt:

- Allocation State Machine
- Proposal Approval Matrix
- Finance-Ops-Objektmatrix
- feine Rollen- und Statuslogiken
- breite Integrations- und Spezialfalllogik

Wenn diese Dinge jetzt weiter vertieft werden, optimiert ihr bereits das Zielsystem, bevor die relevanten Wedges validiert sind.

---

## 15. Pre-Product-Hypothesen

Die entscheidenden Hypothesen sind nicht technisch, sondern produktstrategisch:

1. **Primary-Wedge-Hypothese**  
   Bestandskunden-Expansion & Proposal ist der stärkste erste Kaufgrund.

2. **Wissensreuse-Hypothese**  
   Wissenstransfer wird nicht als „Knowledge Management“, sondern als Reuse-, Proposal- und Onboarding-Readiness gekauft.

3. **Staffing-/Forecast-Hypothese**  
   Intelligentes Staffing, Matching und Consultant Forecasting erhöhen die Glaubwürdigkeit des primären Wedges messbar.

4. **Commercial-Hypothese**  
   Ein Commercial-/Contract-Draft ist im ersten Schritt wertvoll, auch ohne tiefe Finance-Ops-Logik.

5. **Datenhypothese**  
   CVs, Referenzen, Projekterfahrung, Kundenkontext und Angebotsbausteine sind zugänglich genug, um mehrere Wedges mit realen Daten zu testen.

---

## 16. Design-Partner-Lernagenda

Die nächsten Fragen sind wichtiger als weitere Systemarchitektur:

1. Für welchen Wedge zahlen potenzielle Design Partner tatsächlich zuerst?
2. Wer spürt den Schmerz am stärksten: Managing Partner, Practice Lead, Account Lead oder Operations?
3. Welcher Einstieg resoniert am stärksten: `Bestandskunden-Expansion`, `Wissensreuse`, `intelligentes Staffing/Forecasting`, `Commercial Readiness` oder `Ausschreibungsqualifizierung`?
4. Welche Daten liegen real vor, und in welcher Qualität?
5. Wie viel Commercial-/Contract-Tiefe braucht ein Design Partner wirklich im ersten Schritt?
6. Reicht `assistive Outreach`, oder muss Versand schon aus dem Produkt heraus möglich sein?
7. Welche Artefakte müssen im ersten Schritt wirklich sendefähig sein: Proposal, CVs, Pricing, Vertrag?
8. Was wäre für einen Design Partner ein klarer Vorher/Nachher-Beweis nach 30 bis 90 Tagen?

---

## 17. Vorläufige Produktdefinition für pre-product

Für den aktuellen Stand ist die präzisere Beschreibung:

`Consultry ist die AI-native Bestandskunden-Expansion- und Proposal-Engine für DACH IT- und Digitalisierungsberatungen, verstärkt durch Wissensreuse sowie intelligentes Staffing, Matching und Forecasting.`

Langfristig kann daraus ein Operating System werden.  
Heute sollte es noch nicht so verkauft werden, als wäre diese Breite schon das Produkt.

---

## 18. Erfolgssignale in der pre-product-Phase

Nicht PMF, sondern erste Beweise:

- Design Partner verstehen den Wedge in wenigen Minuten
- der Kaufgrund ist ohne lange Erklärung klar
- reale Kundenfälle lassen sich mit echten Daten durchspielen
- Teamvorschläge werden als plausibel wahrgenommen
- Proposal/CV-Drafts sparen sichtbar Zeit
- Wissensbausteine verkürzen Proposal- und Onboarding-Vorbereitung messbar
- Staffing- und Forecast-Vorschläge werden als brauchbare Entscheidungshilfe akzeptiert
- Commercial Drafts sind brauchbar genug, um intern weiterbearbeitet zu werden
- Bestandskundenchancen werden früher oder strukturierter sichtbar

---

## 19. Harte offene Fragen für pre-product

1. Welcher Wedge ist wirklich primär kaufbar und welcher nur intern attraktiv?
2. Welcher erste Output ist je Wedge am stärksten: `qualifizierte Opportunity`, `Teamvorschlag`, `sendefähiges Proposal`, `wiederverwendbares Wissensasset`?
3. Welcher Design-Partner-Typ reagiert auf welchen Wedge am stärksten: Cloud, SAP, Data/AI, Digital Operations, Public-Sector-nah?
4. Wie viel Contract-/Pricing-Tiefe braucht der Expansion-/Proposal-Wedge minimal, um glaubwürdig zu sein?
5. Wie viel Knowledge-Tiefe braucht der Wissensreuse-Wedge minimal, um nicht wie „nur ein Wiki“ zu wirken?
6. Wie viel Profil-, Availability- und Forecast-Tiefe braucht der Staffing-Wedge minimal, um nicht wie „nur eine Skill-Liste“ zu wirken?
7. Welche Delivery-Artefakte müssen im Pilot schon als First-Class-Assets behandelbar sein: Reports, Skripte, kleine Tools, Runbooks, Repository-Templates oder Demo-/Test-Blueprints?
8. Reicht im Pilot GitHub/GitLab als Quelle für technische Reuse-Artefakte, oder muss Consultry schon Repository-Erstellung aus Blueprints anstoßen können?
9. Welche Beraterprofil-Daten sind für persönliches Skill- und Arbeitsprofil wirklich nützlich, ohne in Monitoring zu kippen?
10. Welche AI-Skills und Workflow-Rezepte sind im Pilot first-class: Proposal Prep, Research, Workshop Prep, Troubleshooting, Delivery QA oder Kunden-Demo-Aufbau?
11. Welche Datenquellen reichen für Pilot und Demo wirklich aus, ohne breite Integrationsarbeit?
12. Reicht `Germany-first` als Start klar aus, oder erwarten frühe Kunden schon AT/CH-Tiefe?

---

## 20. Quellen

### Markt und Consulting-Praxis

- [BDU Facts & Figures zum Consultingmarkt 2026](https://www.bdu.de/studien/consulting/) — Marktentwicklung, Druck auf kleine Beratungen, Bedeutung von IT-/Transformationsberatung, 2026
- [BDU: KI in Consultingunternehmen](https://www.bdu.de/news/ki-in-consultingunternehmen-schwerpunkt-auf-kundenprojekten/) — KI-Nutzung im Consulting, mit Schwerpunkten u. a. Wissensmanagement und Angebote, 14.07.2025
- [BDU: Honorare im Consulting](https://www.bdu.de/studien/honorare/) — Preis-/Vertragsrealität und Honorarmodelle, 2025
- [BDU: Tagessätze leicht rückläufig](https://www.bdu.de/news/studie-honorare-im-consulting-2025-tagessaetze-leicht-ruecklaeufig/) — Preis- und Nebenkostenrealität, 15.12.2025
- [BDU KPI-Studie](https://www.bdu.de/studien/kpi/) — Profitabilität, Auslastung, Overhead, Akquisekosten
- [BDU: 80 % Umsatz mit Bestandskunden](https://www.bdu.de/news/consultants-erzielen-80-des-umsatzes-mit-bestandskunden/) — Bestandskunden und Empfehlungen als dominanter Hebel, 02.03.2021
- [Bitkom: In Deutschland fehlen weiterhin mehr als 100.000 IT-Fachkräfte](https://www.bitkom.org/Presse/Presseinformation/Deutschland-fehlen-IT-Fachkraefte) — IT-Fachkräftemangel, 07.08.2025
- [CONSULTING.de: Know-how bewahren](https://www.consulting.de/artikel/wie-knowhow-im-unternehmen-bewahrt-werden-kann-und-warum/) — Wissensverlust in Beratungen
- [CONSULTING.de: 2in1 – Consulting trifft Tool](https://www.consulting.de/artikel/2in1-consulting-trifft-tool/) — Projektplanung, Aufwände und Abrechnung als Zeitfresser
- [CONSULTING.de: Digitalisierung, KI und Automatisierung als Game Changer](https://www.consulting.de/artikel/digitalisierung-ki-und-automatisierung-als-game-changer-fuer-die-consulting-branche/) — interne Prozessdigitalisierung, 25.04.2025

### Rechts- und Betriebsgrenzen

- [GDPR / DSGVO](https://eur-lex.europa.eu/eli/reg/2016/679/oj/eng)
- [EU AI Act 2024/1689](https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX%3A32024R1689)
- [BetrVG §87](https://www.gesetze-im-internet.de/betrvg/__87.html)
- [BetrVG §94](https://www.gesetze-im-internet.de/betrvg/__94.html)
- [BDSG §26](https://www.gesetze-im-internet.de/bdsg_2018/__26.html)
- [RDG §2](https://www.gesetze-im-internet.de/rdg/__2.html)
- [HGB §257](https://www.gesetze-im-internet.de/hgb/__257.html)
- [BMF zur E-Rechnung](https://www.bundesfinanzministerium.de/Content/DE/Downloads/BMF_Schreiben/Steuerarten/Umsatzsteuer/2024-10-15-einfuehrung-e-rechnung.pdf?__blob=publicationFile&v=4)
- [TED eForms](https://ted.europa.eu/en/simap/eforms)
- [service.bund.de Ausschreibungsinfos](https://service.bund.de/Content/DE/Service/Ausschreibungsinfos/ausschreibungsinfos_node.html)

### Produktlandschaft / Kategorien

- [Kantata PSA](https://www.kantata.com/psa)
- [Productive](https://productive.io/)
- [Scoro Quoting & Budgeting](https://www.scoro.com/features/quoting-budgeting/)
- [MOCO](https://www.mocoapp.com/)
- [Teamleader](https://www.teamleader.eu/)
- [Scopevisio](https://www.scopevisio.com/en-gb/)
- [Dealfront](https://www.dealfront.com/)

### AI-native Interaktionsmuster

- [OpenAI Canvas](https://help.openai.com/en/articles/9930697) — editierbare Arbeitsfläche mit Version History und gezieltem Überarbeiten, Stand April 2026
- [OpenAI Deep research](https://help.openai.com/en/articles/10500283-deep-research-faq) — reviewbarer Research-Plan, Quellenwahl und zitierbare Reports, Stand April 2026
- [OpenAI Projects in ChatGPT](https://help.openai.com/en/articles/10169521) — projektgebundene Kontexte und wiederverwendbare Arbeitsräume, Stand April 2026
- [OpenAI Structured Outputs](https://openai.com/index/introducing-structured-outputs-in-the-api/) — AI-Ausgaben als strukturierte, workflow-fähige Datensätze, 06.08.2024
- [Anthropic Citations](https://docs.anthropic.com/en/docs/build-with-claude/citations) — claim-nahe Quellenbindung in Modellantworten, Stand April 2026
- [Anthropic Projects](https://support.claude.com/en/articles/9517075-what-are-projects) — abgegrenzte Arbeitsräume mit eigenem Kontext, Stand April 2026
- [NotebookLM Chat](https://support.google.com/notebooklm/answer/16179559?hl=en&ref_topic=16164070) — quellennaher Notebook-Ansatz für wissensgebundene Arbeit, Stand April 2026
- [Microsoft Context IQ](https://support.microsoft.com/en-us/topic/using-context-iq-to-refer-to-specific-files-people-and-more-in-microsoft-365-copilot-and-copilot-chat-272ac2c1-c5f7-49c9-8a42-2a8a87846fa0) — kontextuelle Vorschläge für Dateien, Personen, Meetings und E-Mails, aktualisiert Februar 2026

---

## 21. Endurteil

Consultry sollte in der pre-product-Phase nicht mehr als „AI-native Consultancy CRM“ beschrieben werden.

Die aktuell präzisere und belastbarere Beschreibung ist:

`AI-native Bestandskunden-Expansion- und Proposal-Engine für DACH IT- und Digitalisierungsberatungen.`

Gleichzeitig sollten weitere Wedges bewusst mitgedacht werden:

- Wissenstransfer, Reuse & Readiness
- Intelligentes Staffing, Matching & Forecasting
- Commercial Readiness Light
- segmentabhängig Tender-Readiness

Das langfristige Ziel kann weiter ein Operating System sein.  
Aber die erste glaubwürdige Go-to-Market-Story ist heute schmaler:

`Bestandskunde -> Opportunity -> Team -> Proposal -> Commercial Draft`

Genau dadurch wird die Produktthese testbar.
