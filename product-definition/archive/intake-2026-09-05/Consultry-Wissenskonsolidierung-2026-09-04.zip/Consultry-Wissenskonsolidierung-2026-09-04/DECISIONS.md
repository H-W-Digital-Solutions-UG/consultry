# Consultry: Entscheidungen, verworfene Ideen und Lehren

Stand: 04.09.2026. Dieses Register ordnet Aussagen ein; es ändert keine historischen Ticket-Bodies. Quellenkürzel und konkrete Einstiege stehen in [SOURCES.md](SOURCES.md).

## Statusregeln

- **Akzeptiert:** im vorliegenden Gespräch explizit bestätigt oder in einer einschlägigen Wayfinder-Resolution dokumentiert, ohne spätere Ablösung.
- **Aktuelle Richtung:** vom Nutzer gewünschte Priorisierung; nachfolgend ausdrücklich explorativ eingegrenzt. Keine pauschale Implementierungsfreigabe.
- **Berichtet:** im Handover einer anderen Session als beschlossen dokumentiert; Herkunft wird beibehalten, keine unabhängige Tatsachenbestätigung.
- **Verworfen:** ausdrücklich zurückgewiesene Formulierung oder Produktannahme.
- **Ersetzt:** vormals gültige Richtung, die durch eine neuere Entscheidung geändert wurde.
- **Verschoben:** bewusst nicht für den aktuellen Schritt; nicht mit Verwerfen gleichsetzen.
- **Offen/Vorschlag:** weder Frage noch Empfehlung gilt allein durch ihre Dokumentation als ratifiziert.

Die jüngste Nutzerkorrektur („das war explorative“) hat Vorrang vor einer zu starken Lesart der Entwürfe. Wiederholung, ein Dateiname mit „Final“ oder die Übernahme durch einen Assistenten sind keine zusätzlichen Abstimmungen. „Nicht übernommen“ und „Audit-Kritik“ unten bezeichnen meine Einordnung, nicht nachträglich erfundene Ablehnungen des Nutzers.

## Produkt und Arbeitsweise

| Entscheidung / Idee | Heutiger Status | Gültige Aussage und Lehre | Herkunft |
|---|---|---|---|
| Consultry Core als Arbeitskern der Beratung | Akzeptiert | Whole Product verbindet Wissen, reale Arbeit und Verantwortung; ein Verkaufs- oder Demo-Einstieg begrenzt es nicht | WF: Product and Platform Destination; Chat Schritte 1–4 |
| Opportunity-to-Concept als Endpunkt | Erweitert | Opportunity-to-Project ist ein wichtiger vollständiger Wertpfad; Konzept/Angebot ist Zwischenresultat. Die Verengung des Whole Product auf einen einzigen Wedge wurde gesondert zurückgewiesen | WF: Problem and Outcome Hierarchy; Proposal Lifecycle; Chat |
| Operating Continuity bei Rollenkompression als primärer Outcome | Verworfen | Expertise wird handlungswirksam; Effizienz, Qualität, Blind-Spot-Abdeckung und Synergien sind Wirkungen. Rollenkompression ist eine Kontextbedingung | WF: Problem and Outcome Hierarchy; direkte Nutzerkorrektur |
| Kleine Beratungen pauschal als SMB ausschließen | Verworfen | Boutique und Growing Specialist Consultancy bleiben gültig; Organisationsform und tatsächliche Jobs zählen | WF: First Consultancy Operating Archetypes; Chat |
| Beratungsunternehmen und dessen Klient gleichsetzen | Verworfen | Consultry-Kunde ist die Beratung; Klientenorganisationen bilden darunter eigene Kontexte und Grenzen | WF: Problem and Outcome Hierarchy |
| Sechs Coverage-Bereiche als Module/Abteilungen/technische Grenzen | Verworfen | Die Karte prüft die Breite des Beratungsbetriebs, nicht die spätere Softwarezerlegung | WF: Canonical Responsibility and Job Families; Coverage Ledger |
| Feste zusätzliche Rollen-/Gatekeeper-Taxonomie | Zurückgenommen | Person, Verantwortung, Teilnahme und Autorität unterscheiden, aber nur konkret benötigte Modellierung hinzufügen | WF: Product Actors, Role Compression, Jobs and Authority |
| Zwei Menschen müssen jedes Ergebnis validieren | Verworfen | Eine Person darf mit Agentenhilfe verantworten; Mehr-Augen-Regeln nur bei tatsächlicher Anforderung | WF: Case Participation/Authority; Consultant Daily Work |
| Agentenprüfung und menschliche Verantwortung | Akzeptierte Grenze | Agentenbeitrag, fachliche Entscheidung und technische Autorisierung bleiben unterscheidbar; Agentenprüfung ist kein zusätzlicher menschlicher Reviewer | dieselben WF-Tickets |
| Chat-only-Produkt | Verworfen | Arbeit, Kontext und Ergebnisse bleiben produktprägend; ein technischer Erstclient kann dialogbasiert bedient werden | WF: Reject a Chat-only Product; Chat Schritt 4; Nutzer 04.09. |
| Harness ist nur optionaler Zusatz | Präzisiert/teilweise ersetzt | Harness by default; eine separate technische Oberfläche bleibt optional. Produkt-Harness und Client-Oberfläche unterscheiden | WF: Harness Integration Boundary; Chat Schritt 1 |
| Harness schlägt ausschließlich nächsten Arbeitsschritt vor | Verworfen | Es kann innerhalb eingeräumter Autorität ausführen, koordinieren, parallelisieren, prüfen und Menschen gezielt einbeziehen | Chat Schritt 4, korrigiert und explizit ratifiziert |
| Alle Arbeitsbereiche sind nur Views identischer Datenobjekte | Verworfen | Verbundene Arbeitskontexte; physische Verknüpfung, Synchronisierung, Kopie oder Übergabe ist noch zu lösen | Chat Schritt 4, korrigiert und explizit ratifiziert |
| Einfaches Connector-/Quellen-Onboarding | Akzeptierte Produktausrichtung | Einfaches Anbinden gehört zum Kern; Umfang des ersten echten Connectors bleibt offen. Eine explizite Ablehnung jedes späteren Integrationsprojekts ist nicht belegt | direkte Nutzerergänzung „einfaches onboarding … Harness by default“ |
| Sales–Consultant-Zusammenarbeit | Akzeptiert | Consultant aus relevantem Projekt bringt Kontext; Sales, falls vorhanden, kommerzielle Arbeit. Gleiche Person darf mehrere Funktionen tragen | Chat Schritt 2 ergänzt und bestätigt |
| Bestandskundensignal und neue Ausschreibung | Akzeptiert | Zwei verschiedene Einstiege in Opportunity-to-Project erhalten | WF Proposal Lifecycle; Chat Schritte 2–3 |
| Opportunity-to-Project-Paket | Akzeptiert | Opportunity-Entscheidung, kundentaugliches Angebot/Ausschreibungsantwort und Project Activation Brief | Chat Schritt 3 |
| Signal wird automatisch qualifizierte Opportunity | Fachlich verworfen | Menschlich verantwortete Pursue/Bid-Qualifizierung bleibt nötig | WF Proposal Lifecycle, Session note 03.08. |
| Drei zusätzliche UI-Stufen in Schritt 5.2 | Offen | „Signal → Opportunity-Kandidat → angenommene Exploration“ wurde nur vorgeschlagen; keine Pflicht zu drei Objekten/Gates ableiten | letzter unbestätigter Grill-Vorschlag im Chat |
| Separates obligatorisches Internal Externalization Gate | Entfernt | Kein zusätzlicher universeller Gate-Begriff; benötigte Rechte-/Freigabegrenzen bleiben im jeweiligen Vorgang | Chat; WF Proposal Lifecycle |
| Fortschritt allein als Definition von Arbeit | Verworfen | Consulting Work, Work Result und Client Progress zusammen betrachten | WF Active Client Work Anatomy, Working Decisions 1–2 |
| Agentenziel über Outcomes statt nur erledigte Schritte bewerten | Präzisiert und bestätigt | Ergebnisbezogene Tests und fachliche Bewertung; später beobachtbare Wirkung getrennt führen | dasselbe Ticket, Working Decisions 3–5 |
| Unterschiedliche Testbarkeit von Outcomes | Präzisiert und bestätigt | Testbarkeit, Evidenzstand, Zeithorizont und Attribution unterscheiden; Urteil bleibt bei offenen Qualitätsfragen notwendig | dieselben Teilentscheidungen; direkte Nutzerergänzung |
| Quellenprüfung als eigenständiger globaler Bereich | Verworfen | Quellen, Evidenz und Prüfungen als Child im assoziierten Flow | Chat; Systemic Click Dummy Experience Contract |
| Corporate Alignment | Akzeptiert | Wissensbasis, fachlicher Inhalt, Corporate Design und Verwendung/Freigabe gelten auch für erzeugte und synchronisierte Artefakte | WF Corporate Artifact Alignment; Chat |
| Consultants pflegen ständig manuell Patterns | Verworfen | Überschneidungen und frühere Lösungswege aus zugelassenen Daten erkennen; Menschen entscheiden über koordinierte Arbeit oder Blueprint | Chat; WF Consultant Daily Work, Duplicate-work branch |
| Ähnlichkeit = automatisch wiederverwendbares Asset | Verworfen | Fachliche Eignung, Klientengrenzen und Rechte behalten; leichte Wiederverwendung und formale Produktisierung trennen | WF Reusable Asset Boundary; Reuse-Referenz |
| Jede Freigabe macht eine Aussage allgemein wahr | Nicht übernommen; Audit-Kritik | Freigabe eines Artefakts, Wissensübernahme, Asset Release und Modelltraining sind verschiedene Vorgänge | WF Reuse und Corporate Alignment; Audit des August-Pakets, keine eigene Nutzerabstimmung dazu |
| Dynamische Diagramme, Fragen, Few Shots und Artefaktflächen | Akzeptierte Experience-Richtung | Aufgabenpassende Interaktion und progressive Disclosure; keine festgeschriebene Screenarchitektur | WF UX Grammar; Chat |
| Vollständiger visueller PoC als Pflicht vor technischem Start | Aktuelle Richtung geändert | Technischen Kern priorisieren; Codex ist ein Beispiel. Keine konkrete neue Route ratifiziert, UI-Erkenntnisse bleiben nutzbar | Nutzer 04.09.2026 einschließlich nachfolgender Explorations-Korrektur |
| Security/Privacy und laufende Wissensverknüpfung | Aktuelle Suchrichtung | Wichtig für den nächsten technischen Schritt; noch keine Freigabe alter Gateway-, Graph-, Vault- oder Deployment-Entwürfe | Nutzer 04.09. einschließlich Explorations-Korrektur |
| Allgemeines Harness Framework als erstes Produkt | Verworfen für den Start | Kleine Consultry-spezifische Integration vorhandener Laufzeiten bevorzugen; Build-vs-Buy konkret prüfen | WF Harness Integration Boundary; ausdrücklicher Chat |

## Graph, Brain und Modellbetrieb

| Thema | Status | Was erhalten bleibt / was noch offen ist |
|---|---|---|
| Core Skill Graph | Fachliche Bedeutung akzeptiert | Versionierte passende AI-Skill-Definitionen und Beziehungen; kein Mitarbeiter-Skill-Ranking |
| Context/Knowledge, Skills, Execution, Validation und Authority | Semantische Trennung erhalten | Kein Beweis, dass dafür getrennte Datenbanken oder große Engines nötig sind |
| Graph-Datenbank | Technisch offen; früher verschoben | Auswahl nach erforderlichen Beziehungen, Aktualisierung, Berechtigungen und Vergleichstest |
| Bitemporalität | Früher technisch beschlossen, später zur Revalidierung gestellt | Herkunft und Historie erhalten; konkrete Speicherung ist offen |
| Eigene Runtime als zwingende Core-IP | Unbestätigter Architekturvorschlag | Kein stilles Überschreiben der OSS-orientierten Harness-Integration |
| AWS/Aurora, Terraform, Fastify/Kysely, Hermes-Fork | Historische technische Kandidaten | Keine Beschaffung oder Implementierungsfreigabe durch innere Accepted-Tabellen älterer Dokumente |
| „Kein persistierter State ohne Approval“ | Audit: als Universalregel zu weit | Empfehlung: automatisches Ingest, Zwischenergebnisse und gekennzeichnete Ableitungen ermöglichen; fachliche Freigabe getrennt |
| „Kein produktiver Graph ändert sich aus einem Run“ | Audit: für Wissensdaten zu weit | Empfehlung: Wissensdaten quellengebunden aktualisieren; Skills, Policies und Berechtigungen dadurch nicht selbst verändern |
| Pseudonymisierung senkt automatisch Schutzklasse | Audit: nicht übernommen | Ersetzte Namen begründen allein keinen erlaubten Daten-/Modellweg |
| Rechte nur am Prompt oder Frontend prüfen | Audit: unzureichender Entwurf | Empfehlung: technische Durchsetzung bei Abruf, Ableitungen und Ausgängen prüfen |
| GNN, Manifold Steering, parametric memory, universelle Agency-Theorie | Exploratives Quellenmaterial | Relevanz fallbezogen prüfen; keine aktuelle Startanforderung |

Quellen: Kernel Data Model §§2.1,10,15–18; Virtual Harness Refinement; Privacy Egress Gateway §§3,5; Architektur-Track im August-ZIP; `papers/KnowledgeSources.md`. Die Einordnung „zu weit/unzureichend“ ist Audit-Ergebnis und technische Empfehlung, keine behauptete historische Nutzerabstimmung.

## Explorierte Pitch-/Business-Stände mit Herkunft

Quelle: das als „final“ bezeichnete Handover 26.08. §§1–4 und dessen HTML-Deck. Diese Werte sind im Paket berichteter Stand, keine aktuelle Ratifikation. Die Nutzerkorrektur zum explorativen Charakter ist ausdrücklich zu beachten. Verträge, Bankunterlagen oder neue Kundengespräche wurden nicht zur unabhängigen Bestätigung herangezogen.

| Thema | Neuester dokumentierter Stand | Grenze |
|---|---|---|
| Investor-Narrativ | ein Produkt; Gewinnen, Liefern, Steuern; Firmengedächtnis | die drei Kreisläufe sind Kommunikationsverdichtung, nicht gesamte technische Architektur |
| Beachhead | IT/SAP, DACH, 20–200 Berater | Zahlenbasis im Deck verwendet andere Firmen-/Mitarbeitergrenzen; separat abgleichen |
| Betriebsmodell | Managed In-Tenant | explorierte Betriebsoption mit offenen Betreiber-/Client-/Modellgrenzen |
| Ask | 500.000 € für 17,5 % | ältere 200k-/250k-Stände historisch; keine neue Renditeempfehlung |
| All-in-Sitz | 149 € Standard / 189 € EU; Plattform 500 €/Monat als Annahme | Pricing ist nicht WTP-Validierung |
| Kapazitätswert | 2.275 €/Berater/Monat als Zielannahme | 3,5 h × 4 Wochen × 162,50 €; keine gemessene Einsparung |
| Markt/Plan | 14.500 Firmen, 1,63 Mrd. € EU-SAM; Jahr 3 13 Mio. € im jüngeren Pitch | Definitionen, Rohdaten und Finanzmodell bleiben zu prüfen |
| Krallmann | LOI unterschrieben laut Handover; bezahlter Pilot folgt | unterzeichneter Nachweis nicht im Paket; „LOI-Status fixieren“ ebenfalls offen |
| H&W | seit 18.08. aus Live-Pitch-Materialien genommen | historische Records bleiben erhalten |
| Compliance-Wording | keine pauschalen Compliance-Versprechen | Daten- und Modellweg konkret beschreiben |

## Lehren, die künftige Arbeit steuern sollten

1. **Jede Aussage hat Herkunft, Geltungsbereich und Status; jedes lebende Thema einen führenden Ablageort.** Mehrere Belege sind erwünscht. Pitch-Zahlen, Produktentscheidungen, Forschungsbelege und Implementierungen haben verschiedene Zuständigkeiten.
2. **Status gilt für Aussagen.** Ein offenes Ticket kann bereits ratifizierte Teilentscheidungen enthalten; ein geschlossenes Ticket kann nur eine Verschiebung dokumentieren.
3. **Breite bewahren, Tiefe verdienen.** Whole-Product-Abdeckung bleibt sichtbar. Details werden erst verbindlich, wenn sie einen realen Arbeitsfall, ein Ergebnis oder eine Grenze verändern.
4. **Erkenntnisse ins Arbeiten bringen.** Mehr Kontext oder mehr Graphknoten sind kein Kundennutzen. Ein Consultant muss ein besseres Ergebnis mit vertretbarer Nacharbeit erzeugen.
5. **Automation und Autorität trennen.** Viele technische Schritte können automatisch laufen, ohne eine kommerzielle Entscheidung oder fremde Zugriffsrechte zu erfinden.
6. **Bequemlichkeit benötigt keinen Genehmigungswald.** Proportionalität bewahren; Quellen-, Klienten- und Egress-Grenzen für die tatsächlich verarbeiteten Daten trotzdem durchsetzen.
7. **Graphnutzen messen.** Provenienz, Widersprüche und Aktualisierungen sind sinnvolle Hypothesen; eine Graph-Datenbank ist dafür noch kein Wirksamkeitsbeleg.
8. **Zustimmung ist keine Allgemeingültigkeit.** Menschen können irren; akzeptierte Ergebnisse bleiben zeit-, zweck- und quellenbezogen.
9. **Forschungswirkung ist keine Consultry-Wirkung.** BCG-/Anbieterbefunde unterstützen Hypothesen. Sie beweisen weder unsere Ersparnis noch eine Produktivitätsuntergrenze.
10. **Benutzbare Software schlägt weitere hypothetische Präzision.** Ein echter technischer Arbeitsfall kann die nächsten offenen Fragen besser schärfen als weitere hypothetische Details. Den Fall selbst wählen wir noch gemeinsam.
11. **Exploration bleibt reversibel.** Eine interessante Architektur, ein Pitch-Narrativ oder ein mehrfach wiederholtes Szenario darf den Produktkern nicht still verengen. Auch diese Konsolidierung muss ihre Empfehlungen als Empfehlungen ausweisen.

## Offene Arbeit für die neue Route bündeln

Die 32 offenen Tickets werden nicht als 32 Startblocker weitergetragen. Vorgeschlagene Einordnung, vollständige Rohdaten in [review/WAYFINDER_TICKETS.csv](review/WAYFINDER_TICKETS.csv):

| Gruppe | Anzahl | Behandlung |
|---|---:|---|
| Core, Record Authority, Knowledge, Model Bridge, Task/Skill, Execution/Validation, Oversight, Outcomes, MVP Boundary | 9 | nur am ersten Backend-Proof konkretisieren |
| Invariants, Core/Module/Surface, Domain/Lifecycle, Handoff/Recovery, Operating Grammar | 5 | minimal in denselben Proof-Vertrag integrieren |
| Adoption/Implementation Experience | 1 | auf die erste Quellenfamilie begrenzen |
| Paid ICP, Rollenverteilung und Persona-Reconciliation | 3 | kommerzielle Validierung parallel |
| Active Work, Corporate Alignment, Attention, Tender, Existing-Client Sensing, Reuse, residuale Journeys | 7 | Referenz; vertiefen, wenn der nächste Fall es benötigt |
| Coverage Skeleton, Traceability, Canon Reconciliation, Product Handoff | 4 | durch diese Konsolidierung verkürzen; Restumfang prüfen |
| Click Dummy, Three-Slice Contract, Three-Slice Handoff | 3 | alte Route durch aktuellen Backend-Start ersetzen |

Keine Tickets wurden in dieser Konsolidierung geschlossen. BACKEND-START enthält mögliche spätere Prüffragen, keinen verpflichtenden Vier-Entscheidungen-Grill. Die Fragen aus den alten Tickets bleiben durch das archivierte Original und das Inventar auffindbar.
