# Consultry: Quellen und gezielter Kontextzugriff

Stand: 04.09.2026. Quellen sind Belege oder Denkwerkzeuge, keine impliziten Arbeitsaufträge. Zuerst [INDEX](INDEX.md), dann das zuständige lebende Dokument lesen. Nur für eine konkrete offene Aussage die passende Quelle nachladen.

## Welche Quelle darf was belegen?

| Quellenart | Belegt | Belegt nicht automatisch |
|---|---|---|
| direkte Nutzerkorrektur / eindeutig zuordenbare Bestätigung | gewünschte Richtung oder Entscheidung zur betreffenden Frage | alle Details im benachbarten Entwurf |
| fachliche Wayfinder-Resolution | dokumentierter damaliger Entscheidungsstand | unveränderte Gültigkeit, Implementierung oder Wirkung |
| Pitch / Handover | Narrativ, Zahlenannahmen, dort berichtete Beschlüsse | neue Ratifikation, Marktbeweis oder sichere Architektur |
| Research-Notiz | recherchierter Zusammenhang und damalige Interpretation | aktuelle Primärquelle oder Consultry-Wirksamkeit |
| Code / Tests / Laufbeobachtung | tatsächlich auffindbare Umsetzung / getestetes Verhalten | vollständiges Produkt oder nicht durchgeführte Tests |
| Architekturentwurf | mögliche Lösung und ihre Argumente | bereits getroffene Anbieter- oder Technologieentscheidung |

Die später ergänzte Nutzerkorrektur zum explorativen Charakter verhindert eine automatische Höherstufung des August-Pakets oder der hier vorgeschlagenen technischen Richtung. Wiederholte Aussagen sind keine unabhängigen Belege.

## Interne Quellenkarte

Alle folgenden Links zeigen auf unveränderte Kopien im Paket. Der ursprüngliche Repo-Pfad ergibt sich aus dem Teil hinter `archive/repo/`.

| Kürzel / Thema | Quelle | Gezielt verwenden für |
|---|---|---|
| PV | [Product Vision](archive/repo/product-definition/latest/Consultry-Product-Vision-v1.0.md) | Whole Product und Nutzen; mit späteren Korrekturen abgleichen |
| COV | [Whole Consultancy Coverage Ledger](archive/repo/product-definition/latest/Consultry-Whole-Consultancy-Coverage-Ledger-v0.1.md) | fachliche Breite, keine technische Modulgrenze |
| JP | [Canonical User Journey Portfolio](archive/repo/product-definition/latest/Consultry-Canonical-User-Journey-Portfolio-v0.1.md) | Probleme, Ergebnisse und Handoffs; keine festgelegte Screenfolge |
| WF | [Wayfinder-Map](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/map.md), [Ticketinventar](review/WAYFINDER_TICKETS.csv) | ursprüngliche Entscheidungen und offene Fragen; Map ist historisch |
| KD | [Platform Kernel Data Model](archive/repo/product-definition/latest/Consultry-Platform-Kernel-Data-Model-Concept-v0.1.md) | Begriffe, Graphrollen, Provenienz; besonders §§2.1, 10, 15–18; kein komplettes Startschema |
| HR | [Virtual Harness / Second Brain](archive/repo/product-definition/latest/Consultry-MVP-Virtual-Harness-Second-Brain-Refinement-v1.0.md) | Kontextpakete, Arbeitsausführung, Aktualität und Ergebnisprüfung |
| PR | [Privacy Egress Gateway](archive/repo/product-definition/latest/Consultry-Privacy-Egress-Gateway-v0.1.md) | Datenwege und Ableitungen; Priorität und konkrete Lösung neu prüfen |
| UX | [Systemic Click Dummy Experience Contract](archive/repo/product-definition/latest/Consultry-Systemic-Platform-Click-Dummy-Experience-Contract-v0.1.md) | Co-Work, dynamische Interaktion, kontextuelle Child-Elemente |
| O2P | [Opportunity-to-Project-Referenz](archive/repo/product-definition/latest/Consultry-Opportunity-to-Project-Representative-Business-Thread-v0.1.md) | damalige fachliche Entscheidungen; Szenario bleibt Beispiel |
| REUSE | [Knowledge Reuse / Corporate Alignment](archive/repo/product-definition/latest/Consultry-Knowledge-Reuse-and-Corporate-Artifact-Alignment-Reference-Thread-v0.1.md) | fachliche Wiederverwendung, CD und Artefaktgrenzen |
| RD | [Research-Quellenregister](archive/repo/product-definition/latest/research/wayfinder-deep-audit-2026-08/source-register.md) | S-E-Quellen samt Studiendesign und Übertragungsgrenzen |
| LOGIC | [Fact–Logic–Decision Graph](archive/repo/product-definition/latest/research/wayfinder-deep-audit-2026-08/fact-logic-decision-graph.yaml), [Relationship Maps](archive/repo/product-definition/latest/research/wayfinder-deep-audit-2026-08/relationship-maps.md) | historische Argumentketten nachvollziehen; kein aktueller Produktgraph |
| QUESTIONS | [Deep Grill Question Bank](archive/repo/product-definition/latest/research/wayfinder-deep-audit-2026-08/deep-grill-question-bank.md) | alte Fragen finden, nicht vollständig erneut abarbeiten |
| SS | [Strictness Dial](archive/repo/product-definition/latest/research/v1-strictness-dial-2026-08.md) | ausdrücklich „Decision proposal. Ratifies nothing.“; keine beschlossene Lockerung aller Grenzen |
| PAPERS | [KnowledgeSources](archive/repo/papers/KnowledgeSources.md) | explorative technische Ideen; quellen- und fallbezogen prüfen |
| CODE | [Mock-Zustand](<archive/repo/Consultry APP UI Mockups/state.js>), [Website-Paket](archive/repo/marketing-site/package.json) | Mock mit Session-State vorhanden; Website ist eigener Track |

### Direkte Wayfinder-Einstiege für die wichtigsten Entscheidungen

- Produktkern: [Destination](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-the-consultry-product-and-platform-destination.md), [Problem-/Outcome-Hierarchie](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/ratify-the-product-problem-and-outcome-hierarchy.md), [Archetypen](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-the-first-consultancy-operating-archetypes.md).
- Arbeit und Verantwortung: [Job Families](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-canonical-responsibility-and-job-families.md), [Actors](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-product-actors-role-compression-jobs-and-authority.md), [Participation/Authority](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-case-participation-authority-delegation-and-separation-of-duties.md), [Daily Work/Delivery](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/specify-consultant-daily-work-and-project-delivery-journeys.md).
- Harness: [nicht Chat-only](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/reject-a-chat-only-product-and-make-the-harness-optional.md), [Integrationsgrenze](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-the-harness-framework-product-boundary.md). Der ältere Titel „optional“ ist durch die spätere direkte Nutzerergänzung „Harness by default“ präzisiert.
- Ergebnisse: [Proposal Lifecycle](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/confirm-the-proposal-aggregate-lifecycle.md), [Active Work Anatomy mit fünf Teilentscheidungen](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/define-the-active-client-work-journey-anatomy-and-ux-mode-coverage.md), [Reusable Asset](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/confirm-the-reusable-asset-boundary.md).
- Core/UX: [Skill Graph](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/separate-the-core-skill-graph-from-capability-evidence.md), [Consulting Work Grammar](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/ratify-the-consulting-work-primitive-and-composable-ux-grammar.md), [alte Mock-first-Route](archive/repo/product-definition/latest/wayfinder/consultry-product-platform-baseline/tickets/place-the-three-slice-mock-ui-demo-gate-before-the-technical-poc.md).

Kurze „ja“-Nachrichten aus dem Gespräch ohne vollständig zuordenbaren Vorschlag werden nicht allein als Beleg für zusätzliche Detailentscheidungen verwendet. Die hier erhaltenen Gesprächsbezüge sind eine Zusammenfassung, kein vollständiges exportiertes Chatprotokoll.

## Pitch und August-Handover

- [Handover 26.08.](archive/handover-2026-08-26/00_START_HIER/Consultry_Handover_Final.md): dokumentiert den damaligen Stand und enthält selbst offene Punkte.
- [HTML-Deck im Paket](archive/handover-2026-08-26/01_Deck_fuehrend/Consultry_Pitchdeck_v10.html): jüngste in diesem Audit gefundene inhaltliche Pitch-Basis; Versionsnummer allein ist nicht ausschlaggebend.
- [Neu extrahierter Decktext](review/PITCH_TEXT_NEU_EXTRAHIERT.txt): für Suche; sichtbare Texte und vorhandene Sprecher-Notizen getrennt. Kein Ersatz für eine visuelle Deckprüfung.
- [Datengrenzen-Architektur](archive/handover-2026-08-26/05_Grundlagen_Architektur_Markt/Consultry_Datengrenze_Architektur.md), [Datengrenzen-Handover](archive/handover-2026-08-26/05_Grundlagen_Architektur_Markt/Consultry_Handover_Datengrenze.md), [Bauplan/Preisüberschlag](archive/handover-2026-08-26/05_Grundlagen_Architektur_Markt/Consultry_Bauplan_und_Preisueberschlag.md): explorative Optionen, keine Architekturfreigabe.
- [Vollständiges Original-ZIP](archive/input/Consultry_Handover_Paket_2026-08-26.zip): unverändert erhalten, inklusive nicht separat extrahierter Binärdateien.

Der alte Root-Pitch und frühere Handover bleiben als Entwicklungsgeschichte erhalten. Mitgelieferte Textauszüge können dem HTML hinterherlaufen. Für einen konkreten Pitch-Claim deshalb im HTML gegenprüfen.

### Spannungen, die nicht durch Konsolidierung „gelöst“ werden dürfen

| Aussage / Spannungsfeld im Material | Umgang |
|---|---|
| „Wir hosten nichts“ gegenüber zentraler Control Plane | konkret nach Inhalt, Telemetrie, Betrieb und Support unterscheiden; kein pauschales Versprechen übernehmen |
| „Kein Modellanbieter sieht Daten“ gegenüber Cloud-Inferenz | tatsächlichen Modell-/Client-Datenweg erst nachweisen |
| In-Tenant / lokal / On-Prem / EU-GPU | verschiedene Betriebsformen, nicht als Synonyme verwenden |
| Betreiber ohne Leserechte, aber mit Deployment-/Identitätsrechten | effektive Zugriffsmöglichkeiten prüfen; technische Empfehlung, keine bereits geprüfte Zusage |
| Pseudonymisierung als automatische Schutzklassenabsenkung | ausgetauschte Namen allein reichen als Begründung nicht; keine juristische Freigabe aus dem Entwurf ableiten |
| „Kein Kontext älter als die Quelle“ | gewünschte Aktualität später messbar beschreiben, keine universelle Echtzeitgarantie behaupten |
| 2.275 € monatlich pro Berater | Ziel-Kapazitätswert: 3,5 h × 4 × 162,50 €; keine gemessene Kostenersparnis |
| weitere BCG-Effekte plus Kapazitätswert addieren | mögliche Überlappung, Übertragbarkeit und Nenner prüfen; keine gesicherte Untergrenze |
| Krallmann-LOI als unterschrieben berichtet, Statusfixierung zugleich offen | kein unterschriebenes Dokument im geprüften Paket gefunden; berichteten Status nicht als unabhängigen Nachweis führen |
| neue Modellnamen, Hostingpreise, Margen und Marktgrößen | damalige Annahmen; vor operativer oder externer Verwendung Primärquellen und Kalkulation aktualisieren |

## Externe Quellen gezielt nachladen

Das [URL-Inventar](review/EXTERNE_QUELLEN_INVENTAR.csv) enthält 376 aus den Textquellen extrahierte unterschiedliche URLs samt Fundstellen. Es ist **kein** Register von 376 erneut verifizierten Behauptungen. Auch eine seriöse Quelle beweist nicht automatisch die Übertragbarkeit auf Consultry.

| Forschungsfrage | Einstieg in das vorhandene Quellenregister | Einordnung |
|---|---|---|
| reale Consulting-Arbeit und Wissensnutzung | RD S-E01–10, S-E27–33; Research-Dateien zu Work Primitives und IT/Process Consulting | Domäne, Studiendesign und Größenklasse beachten |
| menschliche Expertise plus AI | RD S-E11–16, S-E34–35 | Wirkung abhängig von Aufgabe und Expertise; keine Consultry-ROI-Garantie |
| Agentenloops, Graphen, Reliability | RD S-E17–22, S-E36–39 | technische Forschung/Benchmarks, keine Produkt- oder Store-Auswahl |
| Validation, Authority und Oversight | RD S-E23–26, S-E40–43 | Standards, Guidance und Analogien unterscheiden |
| Modellrouting | RD S-E44–46 | Qualitäts-/Kostenrouting ist nicht dasselbe wie zulässige Datenverarbeitung |

### Am 04.09.2026 eng begrenzt online gegengeprüft

| Primärquelle | Konkreter Befund | Konsequenz, nicht Produktbeschluss |
|---|---|---|
| [OpenAI: Codex und MCP](https://developers.openai.com/codex/mcp/) | Dokumentation beschreibt die Anbindung von Werkzeugen und Kontext über MCP | Codex ist ein möglicher Zugang; kein Beleg einer bestimmten Consultry-Datenresidenz |
| [MCP Security Best Practices](https://modelcontextprotocol.io/docs/2025-11-25/tutorials/security/security_best_practices) | behandelt u. a. Confused Deputy, Token Passthrough und Session-/Scope-Grenzen; Token Passthrough wird ausdrücklich abgelehnt | bei Wahl von MCP sichere Autorisierung umsetzen; Protokollanbindung ersetzt keine fachlichen Rechte |
| [Microsoft Graph: Selected Permissions](https://learn.microsoft.com/en-us/graph/permissions-selected-overview) | Anwendung benötigt passende Einwilligung, explizite Ressourcenzuweisung und ein entsprechend berechtigtes Token | begrenztes SharePoint-Onboarding ist eine dokumentierte Option; tatsächliche Connector-Implementierung offen |
| [Microsoft GraphRAG](https://microsoft.github.io/graphrag/) | dokumentierter Ansatz für graphgestützte Verarbeitung und Abfrage | möglicher Vergleichskandidat; keine nachgewiesene Passung für laufende Rechte-/Quellenänderungen in Consultry |

Keine neue umfassende Markt-, Rechts-, Modellpreis- oder Paper-Validierung durchgeführt. Vor einem solchen Claim gezielt die aktuelle Originalquelle prüfen und Ergebnis, Datum sowie Anwendungsgrenze hier ergänzen. Nicht neue Research-Sammeldokumente erzeugen, wenn ein Eintrag im Quellenregister genügt.
