# Consultry: Produktbild und Funktionsumfang

Stand: 04.09.2026. Konsolidiertes Zielbild, keine Behauptung bereits implementierter Funktionen oder eines vollständig ratifizierten Feature-Backlogs. Die Beispiele bewahren die Breite der bisherigen Arbeit; sie sind weder starre Module noch Startanforderungen. Status: [DECISIONS.md](DECISIONS.md). Explorative technische Orientierung: [BACKEND-START.md](BACKEND-START.md).

## Zielkunde, Nutzer und Nutzen

Consultry wird von einer spezialisierten Beratung eingeführt. Partner, Consultants, Projektverantwortliche, Sales und operative Funktionen nutzen das System im Kontext ihrer realen Arbeit. Ihre Klienten sind eigene Organisationen mit eigenen Vertraulichkeits-, Vertrags- und Zugriffsgrenzen.

Boutiquen erhalten Zugang zu Wissen und spezialisierten Arbeitsabläufen auch dort, wo eine Person mehrere Funktionen trägt. Wachsende Beratungen verbinden getrennte Beiträge und Verantwortlichkeiten. Das Produktziel ist bessere Beratungsarbeit und wirtschaftlichere Leistungserbringung durch zugängliche Expertise, stärkere Ergebnisse, frühere Blind-Spot-Erkennung und projektübergreifende Synergien.

Das August-Paket erprobt IT-/SAP-Beratungen in DACH mit 20–200 Beratern als engeren Markteinstieg. Diese Zuspitzung ist nicht gleichbedeutend mit einer hier bestätigten Produktgrenze. Exakte Größenuntergrenzen, Erstkäufer und Zahlungsbereitschaft sind weiterhin kommerziell zu validieren.

## Gemeinsamer Kern

| Fähigkeit | Konkreter Nutzen und Verhalten | Mögliche Gewichtung beim technischen Einstieg, noch offen |
|---|---|---|
| Quellen und Systeme anschließen | Dokumente, relevante Kommunikations-/Projekt-/CRM-Quellen progressiv anbinden; Herkunft und zulässigen Zugriff erhalten | eine echte, begrenzte Quellenfamilie im ersten Proof |
| Wissen verknüpfen | Klienten, Projekte, Anforderungen, Aussagen, Entscheidungen, Expertenwissen und Artefakte zusammenführen | Schwerpunkt |
| Wissen aktuell halten | Änderungen erkennen; betroffene Ableitungen, Indexe und Kontextpakete aktualisieren oder als veraltet kennzeichnen | Schwerpunkt |
| Arbeitskontext bilden | für eine konkrete Aufgabe passende Informationen und Lücken bereitstellen | Schwerpunkt |
| Menschen und Agenten koordinieren | Ziel, Plan, Inputs, Verantwortungen, Ausführung, Ergebnis und Fortsetzung verbinden | kleiner vollständiger Arbeitsfall |
| Arbeitsergebnisse erzeugen | Analysen, Konzepte, Angebote, Pläne, Präsentationen und weitere Deliverables erstellen und überarbeiten | ein benutzbares Ergebnisformat im ersten Proof |
| Ergebnisse prüfen | deterministisch Prüffähiges testen; fachliche Bewertung und später beobachtbare Wirkung unterscheiden | proportionale Tests im ersten Proof |
| Informationen schützen | Zugriff nach Beratung, Klient, Projekt, Person, Agent und Zweck; erlaubte Verarbeitung und Ausgänge kontrollieren | Schwerpunkt |
| Modelle kontrolliert nutzen | Modellwahl zunächst durch Datenweg begrenzen, dann nach Qualität und Aufwand auswählen | ein nachgewiesener Pfad vor breiter Optimierung |

## Fachlicher Gesamtumfang

Die sechs Bereiche unten sind eine Abdeckungskarte des Beratungsbetriebs. Sie legen weder sechs technische Module noch sechs Menüpunkte oder sechs Pflichtabteilungen fest.

### 1. Kunden gewinnen und Zusagen verantworten

- Signale aus bestehenden Projekten, Gesprächen, Dokumenten und Kundenbeziehungen erkennen und einordnen.
- Neue Ausschreibungen und ausdrückliche Kundenbedarfe erfassen; Kriterien und offene Fragen verstehen.
- Relevante Referenzen, frühere Lösungsarbeit und passende Expertise finden.
- Consultants, Sales und Experten an Bedarf, Machbarkeit und Angebot zusammenbringen.
- Pursue/Bid, No Bid, Hold und weitere Bearbeitung verantworten; geschätzte Werte als Schätzungen behandeln.
- Konzepte, Angebote, Ausschreibungsantworten, Leistungsbeschreibungen und Kalkulationsgrundlagen erarbeiten.
- Zusagen, Annahmen, offene Punkte, Vertragsgrundlage und Delivery-Readiness in den Projektstart überführen.

Für den damaligen Opportunity-to-Project-Referenzkorridor wurden Opportunity-Entscheidung, Kundenartefakt und Project Activation Brief als Ergebnispaket festgehalten. Das schreibt nicht jedem Fall dieselben Formate oder Schritte vor. Kommerzielles Commitment, interne Bereitschaft und tatsächlicher Projektstart bleiben unterscheidbar.

### 2. Projekte durchführen und Ergebnisse verbessern

- Arbeitsziele, Anforderungen, Pläne und konkrete Aufgaben im Projektkontext bearbeiten.
- Fachanalysen, Prozess-/IT-Konzepte, Entscheidungsgrundlagen, Roadmaps, Berichte und Präsentationen erstellen.
- Agenten für passende Teilaufgaben einsetzen und ihre Beiträge mit menschlichem Fachwissen verbinden.
- Fehlende Perspektiven, widersprüchliche Annahmen und relevante neue Quellen früh sichtbar machen.
- Rebuttal-/Challenge-Simulation einsetzen, wenn sie das konkrete Ergebnis verbessert.
- Artefakte und Pläne gezielt revidieren; Risiken, Änderungen und Recovery unterstützen.
- Projektabschluss, Abnahme, Restverpflichtungen und Übergaben an Folgearbeit nachvollziehbar vorbereiten.

Blind-Spot-Erkennung ist eine Fähigkeit innerhalb dieser Arbeit. Sie ersetzt nicht die gesamte Delivery-Definition.

### 3. Expertise nutzen, lernen und wiederverwenden

- Aus vorhandenem Wissen Antworten und verwendbare Beiträge zur aktuellen Arbeit gewinnen.
- Experten und begründete frühere Entscheidungen finden; Kontext und Grenzen ihrer Übertragbarkeit zeigen.
- Ähnliche Problemstellungen oder Lösungswege zwischen Projekten erkennen und betroffene Consultants beziehungsweise Management informieren.
- Gemeinsame Diskussion und bei Bedarf eine Blueprint-Lösung ermöglichen.
- Quellen und wiederkehrende Arbeit analysieren, statt Consultants zur permanenten manuellen Pattern-Pflege zu verpflichten.
- Lernen aus Ergebnissen und menschlichen Korrekturen sichern.
- Wiederverwendbare Methoden, Skills, Assets und Angebotsbausteine dort entstehen lassen, wo Rechte, Qualität und Zweck passen.

Ein akzeptiertes Kundenartefakt wird nicht automatisch zum allgemeinen Firmenwissen. Zugriffsberechtigung auf ein Dokument allein ist kein Freibrief zur Veröffentlichung oder klientenübergreifenden Wiederverwendung.

### 4. Menschen und Fähigkeiten zusammenbringen

- benötigte Fachkompetenz, Rollen und Kapazität einer Aufgabe mit zulässigen Erfahrungsnachweisen verbinden;
- passende interne Beiträge oder Expertenanfragen vorbereiten;
- Besetzungs-, Entwicklungs-, Partner- und Kapazitätslücken sichtbar machen;
- Menschen bei Allocate/Reassign/Develop/Partner/Hire/Defer-Entscheidungen unterstützen.

Keine verdeckte individuelle Leistungsbewertung oder autonome Personalauswahl ableiten. Vollständige Staffing-/HR-Funktionalität gehört nicht in den ersten Backend-Proof.

### 5. Den Beratungsbetrieb unterstützen

- Arbeits-, Zeit-, Kosten-, Auslagen- und Leistungsnachweise aus vorhandenen Systemen zusammenführen;
- fehlende oder widersprüchliche Grundlagen für Abrechnung und operative Vorgänge erkennen;
- Abrechnungsunterlagen, Rechnungsentwürfe und Ausnahmebearbeitung vorbereiten;
- passende Übergaben zwischen Delivery, Commercials und Backoffice unterstützen;
- Anbieter-, Lizenz- und Verlängerungskontext einbeziehen, soweit ein realer Job dies erfordert.

Führende Finanz-, ERP- und PSA-Systeme behalten ihre jeweilige Rolle. Kein vollständiger Ersatz dieser Systeme ist für den Start beschlossen.

### 6. Die Beratung und ihr Portfolio steuern

- kunden-, projekt-, kapazitäts- und wirtschaftsübergreifende Zusammenhänge für Managemententscheidungen sichtbar machen;
- Engpässe, Überschneidungen, Risiken, Folgechancen und Synergien aufzeigen;
- Szenarien und Alternativen mit nachvollziehbarer Grundlage vorbereiten;
- Priorisierung, Investition, Fortsetzung, Reallokation und Eskalation unterstützen;
- beschlossene Folgearbeit und beobachtbare Wirkung zurückverfolgen.

Aggregierte Information ist Entscheidungsgrundlage; Managementurteil und Quellenfakten bleiben unterscheidbar.

## Einführung und Entwicklung von Consultry

Einfaches Onboarding ist Teil des Produktkerns: Quellenumfang wählen, Zugriff herstellen, passende Arbeitsgrundlagen übernehmen und einen echten ersten Anwendungsfall bearbeiten. Der Korpus darf unvollständig beginnen, muss seine Lücken aber erkennen lassen.

Spätere Änderungen an Firmenbegriffen, Templates, Corporate Design, Methoden, Skills, Datenwegen und Konfiguration brauchen eine nachvollziehbare Version und gezielte Behandlung betroffener Arbeit. Der erste Backend-Proof soll hiervon genau die für seine Quellen und Aufgaben notwendigen Eigenschaften nachweisen.

## Co-Work und Artefakte als durchgängiges Verhalten

- Harness by default; zugängliche App und andere geeignete Clients können denselben Produktkern konsumieren.
- Adaptive Arbeit statt eines universellen Formular-Wizards: Ziele, Pläne, Zwischenresultate und Fragen richten sich nach der Aufgabe.
- Dynamische Diagramme, Vergleiche, Auswahlfragen mit Freitext und Few-Shot-Vorschläge bleiben im UX-Zielbild erhalten.
- Retrieval und Output verstärken sich: relevantes Wissen muss in die reale Analyse, Entscheidung oder das Artefakt einfließen.
- Corporate Alignment umfasst Wissensbasis, inhaltliche Regeln, Marke/Corporate Design und erlaubten Verwendungszweck.
- Eine Person kann ein Ergebnis mit Agentenunterstützung verantworten, wenn keine konkrete Regel eine weitere Person verlangt.
- Quellenvergleich, Prüfung und Freigabe bleiben am jeweiligen Ergebnis oder Arbeitsschritt angesiedelt.
- Ein technischer Client als Erstzugang macht Consultry nicht zu einem dauerhaft Chat-only definierten Produkt.

## Spätere Produktoptionen

Zusätzliche spezialisierte Solutions, vertikale Module, ein separat vermarktbares Governance-/Model-Bridge-Modul und breiter wiederverwendbare Kernbausteine bleiben als Horizont erhalten. Der jetzige Auftrag fokussiert die Beratung. Ein allgemeines AI-OS-Framework, Marketplace oder eigenständiges Agent Framework ist keine Startanforderung.

## Einschätzung zum Abschluss der Vision

Meine Einschätzung: Zielkunde, Arbeitsnutzen, Kernverhalten und Whole-Product-Abdeckung sind ausreichend beschrieben, um einen ersten realen technischen Lernschritt auszuwählen. Dafür müssen nicht erst alle explorierten Funktionen spezifiziert werden. Ob dieses konsolidierte Zielbild die Vision hinreichend trifft, prüfen wir gemeinsam; es ist keine formale Abnahme, kein Nachweis von Product-Market-Fit und noch kein finaler MVP-Scope.
