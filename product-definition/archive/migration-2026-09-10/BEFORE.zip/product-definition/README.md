# Consultry Product Definition

Dieser Parent-Ordner trennt den aktuell relevanten Arbeitsstand von historischer Produktdokumentation.

**Aktualisierung 05.09.2026:** Aktueller Fokus ist der graphbasierte Wissenskern mit einfacher UI-Wissensintegration, rollenbasierter API-/Harness-Nutzung und zulässiger sensibler AI-Verarbeitung. Die [Agenten-Ledger-Integration](./latest/Consultry-Agent-Knowledge-Ledger-Integration-v0.1.md) ergänzt diese Richtung als technischer Kandidat. Der [Abgleich der neuen Pakete](./archive/intake-2026-09-05/RECONCILIATION.md) erhält die jüngeren Nutzerpräzisierungen; die Ablösung von `latest/` durch sechs führende Dokumente bleibt ein noch nicht ausgeführter Organisationsvorschlag.

## Einstieg

1. [`latest/README.md`](./latest/README.md) — kuratierter Einstieg in die aktuelle Product Definition.
2. [`latest/_CONTEXT-AND-MEMORY.md`](./latest/_CONTEXT-AND-MEMORY.md) — persistenter Kontext- und Entscheidungsanker.
3. [`latest/wayfinder/consultry-product-platform-baseline/map.md`](./latest/wayfinder/consultry-product-platform-baseline/map.md) — laufende Product-/Business-Domain-Entscheidungsfolge.
4. [`latest/MANIFEST.yaml`](./latest/MANIFEST.yaml) — maschinenlesbare Autoritäts- und Statusklassifikation.

## Struktur

| Ordner | Bedeutung |
|---|---|
| [`latest/`](./latest/) | Gesamter derzeit relevante Arbeitsstand: Canon, aktive Product Inputs, Research/UX-Evidenz und klar abgegrenzter Technical Handoff. `latest` ist beweglich und noch kein vollständig ratifizierter Product Baseline Release. |
| [`archive/`](./archive/) | Genau ein historischer Archivbaum für superseded Entscheidungen, PRDs, Personas, Feature-Specs und alte Analysen. Nie Quelle für aktuellen Scope. |

## Autoritätsregel

Ein neueres Änderungsdatum macht ein Dokument nicht automatisch zum Canon. Direkte aktuelle Nutzerentscheidungen haben für die von ihnen geänderte Frage Vorrang; sie stehen im Kontextanker. Im Übrigen gelten der im Manifest ausgewiesene Status und einschlägige ratifizierte Wayfinder-Entscheidungen. Bei Konflikten wird die Abweichung explizit reconciliiert; es gibt keine stille Übernahme aus aktiven Kandidaten, technischen Entwürfen oder dem Archiv.
